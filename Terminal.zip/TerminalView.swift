import UIKit

class TerminalView: UIView {
    private var buffer: TerminalBuffer!
    private var parser: ANSIParser!
    let cellWidth: CGFloat = 8.0
    let cellHeight: CGFloat = 16.0
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .black
        buffer = TerminalBuffer(rows: 24, cols: 80)
        parser = ANSIParser()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        backgroundColor = .black
        buffer = TerminalBuffer(rows: 24, cols: 80)
        parser = ANSIParser()
    }
    
    func setDimensions(rows: UInt16, cols: UInt16) {
    }
    
    func feed(data: Data) {
        for byte in data {
            parser.parse(byte: byte, buffer: buffer)
        }
        setNeedsDisplay()
    }
    
    func feed(text: String) {
        if let data = text.data(using: .utf8) {
            feed(data: data)
        }
    }
    
    override func draw(_ rect: CGRect) {
        guard let context = UIGraphicsGetCurrentContext() else { return }
        context.setFillColor(UIColor.black.cgColor)
        context.fill(rect)
        
        let lines = buffer.getLines()
        let attrs: [NSAttributedString.Key: Any] = [
            .font: UIFont(name: "Menlo", size: 12.0) ?? UIFont.monospacedSystemFont(ofSize: 12.0, weight: .regular)
        ]
        
        for (y, line) in lines.enumerated() {
            for (x, cell) in line.enumerated() {
                let fgColor = ansiColor(code: cell.foreground, isBold: cell.bold)
                let bgColor = ansiColor(code: cell.background, isBold: false)
                
                let drawRect = CGRect(x: CGFloat(x) * cellWidth, y: CGFloat(y) * cellHeight, width: cellWidth, height: cellHeight)
                context.setFillColor(bgColor.cgColor)
                context.fill(drawRect)
                
                if cell.character != " " {
                    let str = String(cell.character)
                    let attrString = NSAttributedString(string: str, attributes: [
                        .font: attrs[.font] as Any,
                        .foregroundColor: fgColor
                    ])
                    attrString.draw(in: drawRect)
                }
            }
        }
        
        let cursorRect = CGRect(x: CGFloat(buffer.cursorX) * cellWidth, y: CGFloat(buffer.cursorY) * cellHeight, width: cellWidth, height: cellHeight)
        context.setStrokeColor(UIColor.green.cgColor)
        context.setLineWidth(1.0)
        context.stroke(cursorRect)
    }
    
    private func ansiColor(code: UInt8, isBold: Bool) -> UIColor {
        let colors: [UIColor] = [
            UIColor.black, UIColor.red, UIColor.green, UIColor.yellow,
            UIColor.blue, UIColor.magenta, UIColor.cyan, UIColor.white
        ]
        if Int(code) < colors.count {
            return colors[Int(code)]
        }
        return UIColor.white
    }
}
