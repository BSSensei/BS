import UIKit

class TerminalViewController: UIViewController, UITextViewDelegate {
    private var terminalView: TerminalView!
    private var session: PTYSession!
    private var inputField: UITextView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .black
        
        terminalView = TerminalView(frame: view.bounds)
        terminalView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        view.addSubview(terminalView)
        
        inputField = UITextView(frame: CGRect(x: 0, y: 0, width: 0, height: 0))
        inputField.delegate = self
        inputField.autocapitalizationType = .none
        inputField.autocorrectionType = .no
        view.addSubview(inputField)
        
        session = PTYSession()
        session.onDataReceived = { [weak self] data in
            DispatchQueue.main.async {
                self?.terminalView.feed(data: data)
            }
        }
        session.onExit = { [weak self] in
            DispatchQueue.main.async {
                self?.terminalView.feed(text: "\r\n[进程已结束]\r\n")
            }
        }
        
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(focusInput))
        terminalView.addGestureRecognizer(tapGesture)
        
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow), name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide), name: UIResponder.keyboardWillHideNotification, object: nil)
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        let rows = UInt16(terminalView.bounds.height / terminalView.cellHeight)
        let cols = UInt16(terminalView.bounds.width / terminalView.cellWidth)
        if rows > 0 && cols > 0 {
            session.resize(rows: rows, cols: cols)
            terminalView.setDimensions(rows: rows, cols: cols)
        }
    }
    
    @objc private func focusInput() {
        inputField.becomeFirstResponder()
    }
    
    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
        if let data = text.data(using: .utf8) {
            session.write(data: data)
        }
        return false
    }
    
    @objc private func keyboardWillShow(_ notification: Notification) {
        if let keyboardFrame = notification.userInfo?[UIResponder.keyboardFrameEndUserInfoKey] as? CGRect {
            terminalView.frame.size.height = view.bounds.height - keyboardFrame.height
        }
    }
    
    @objc private func keyboardWillHide(_ notification: Notification) {
        terminalView.frame.size.height = view.bounds.height
    }
}
