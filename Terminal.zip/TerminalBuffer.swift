import Foundation

struct TerminalCell {
    var character: Character = " "
    var foreground: UInt8 = 7
    var background: UInt8 = 0
    var bold: Bool = false
}

class TerminalBuffer {
    private var lines: [[TerminalCell]] = []
    private var scrollback: [[TerminalCell]] = []
    var cursorX: Int = 0
    var cursorY: Int = 0
    let rows: Int
    let cols: Int
    
    init(rows: Int, cols: Int) {
        self.rows = rows
        self.cols = cols
        for _ in 0..<rows {
            lines.append(Array(repeating: TerminalCell(), count: cols))
        }
    }
    
    func putChar(_ char: Character, fg: UInt8, bg: UInt8, bold: Bool) {
        if char == "\r" {
            cursorX = 0
            return
        }
        if char == "\n" {
            if cursorY >= rows - 1 {
                scrollUp()
            } else {
                cursorY += 1
            }
            return
        }
        if char == "\u{08}" {
            if cursorX > 0 { cursorX -= 1 }
            return
        }
        
        if cursorX >= cols {
            cursorX = 0
            if cursorY >= rows - 1 {
                scrollUp()
            } else {
                cursorY += 1
            }
        }
        
        var cell = TerminalCell()
        cell.character = char
        cell.foreground = fg
        cell.background = bg
        cell.bold = bold
        lines[cursorY][cursorX] = cell
        cursorX += 1
    }
    
    private func scrollUp() {
        scrollback.append(lines.removeFirst())
        lines.append(Array(repeating: TerminalCell(), count: cols))
    }
    
    func clearScreen() {
        for i in 0..<rows {
            for j in 0..<cols {
                lines[i][j] = TerminalCell()
            }
        }
        cursorX = 0
        cursorY = 0
    }
    
    func setCursor(x: Int, y: Int) {
        cursorX = max(0, min(x, cols - 1))
        cursorY = max(0, min(y, rows - 1))
    }
    
    func getLines() -> [[TerminalCell]] {
        return lines
    }
}
