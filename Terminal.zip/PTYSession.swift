import Foundation

class PTYSession {
    private var masterFD: Int32 = -1
    private var readSource: DispatchSourceRead?
    private var writeQueue = DispatchQueue(label: "com.newterm.pty.write")
    var onDataReceived: ((Data) -> Void)?
    var onExit: (() -> Void)?
    
    init() {
        setupPTY()
    }
    
    private func setupPTY() {
        let master = posix_openpt(O_RDWR | O_NOCTTY)
        guard master >= 0 else { return }
        
        guard grantpt(master) == 0, unlockpt(master) == 0 else {
            close(master)
            return
        }
        
        guard let slaveNameC = ptsname(master) else {
            close(master)
            return
        }
        let slaveName = String(cString: slaveNameC)
        let slave = open(slaveName, O_RDWR | O_NOCTTY)
        guard slave >= 0 else {
            close(master)
            return
        }
        
        var winSize = winsize(ws_row: 24, ws_col: 80, ws_xpixel: 0, ws_ypixel: 0)
        ioctl(master, TIOCSWINSZ, &winSize)
        
        self.masterFD = master
        
        guard let helperPath = RootHelperManager.shared.prepareHelper() else {
            close(slave)
            close(master)
            return
        }
        
        var fileActions: posix_spawn_file_actions_t?
        posix_spawn_file_actions_init(&fileActions)
        posix_spawn_file_actions_adddup2(&fileActions, slave, 0)
        posix_spawn_file_actions_adddup2(&fileActions, slave, 1)
        posix_spawn_file_actions_adddup2(&fileActions, slave, 2)
        posix_spawn_file_actions_addclose(&fileActions, master)
        
        var pid: pid_t = 0
        let args = [helperPath, "-s", nil]
        let argv = args.compactMap { $0 }.map { strdup($0) }
        defer { argv.forEach { free($0) } }
        
        let documentsPath = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!.path
        let customBinPath = documentsPath + "/bin"
        
        let env = [
            "TERM=xterm-256color",
            "PATH=" + customBinPath + ":/usr/bin:/bin:/usr/sbin:/sbin:/usr/local/bin",
            "HOME=/var/mobile",
            "USER=root",
            "LANG=en_US.UTF-8"
        ]
        let envp = env.map { strdup($0) }
        defer { envp.forEach { free($0) } }
        
        let status = posix_spawn(&pid, helperPath, &fileActions, nil, argv, envp)
        posix_spawn_file_actions_destroy(&fileActions)
        close(slave)
        
        if status != 0 {
            close(master)
            return
        }
        
        setupReadSource()
    }
    
    private func setupReadSource() {
        let queue = DispatchQueue(label: "com.newterm.pty.read")
        readSource = DispatchSource.makeReadSource(fileDescriptor: masterFD, queue: queue)
        readSource?.setEventHandler { [weak self] in
            guard let self = self else { return }
            var buffer = [UInt8](repeating: 0, count: 4096)
            let bytesRead = read(self.masterFD, &buffer, buffer.count)
            if bytesRead > 0 {
                let data = Data(buffer[0..<bytesRead])
                self.onDataReceived?(data)
            } else if bytesRead <= 0 {
                self.readSource?.cancel()
                self.onExit?()
            }
        }
        readSource?.resume()
    }
    
    func write(data: Data) {
        writeQueue.async { [weak self] in
            guard let self = self, self.masterFD >= 0 else { return }
            data.withUnsafeBytes { ptr in
                guard let baseAddress = ptr.baseAddress else { return }
                write(self.masterFD, baseAddress, data.count)
            }
        }
    }
    
    func resize(rows: UInt16, cols: UInt16) {
        var winSize = winsize(ws_row: rows, ws_col: cols, ws_xpixel: 0, ws_ypixel: 0)
        ioctl(masterFD, TIOCSWINSZ, &winSize)
    }
    
    deinit {
        readSource?.cancel()
        if masterFD >= 0 {
            close(masterFD)
        }
    }
}
