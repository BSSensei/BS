import Foundation

class ANSIParser {
    enum State {
        case normal
        case escape
        case bracket
        case osc
    }
    
    private var state: State = .normal
    private var params: String = ""
    var foreground: UInt8 = 7
    var background: UInt8 = 0
    var bold: Bool = false
    
    func parse(byte: UInt8, buffer: TerminalBuffer) {
        let char = Character(UnicodeScalar(byte))
        
        switch state {
        case .normal:
            if byte == 0x1B {
                state = .escape
            } else {
                buffer.putChar(char, fg: foreground, bg: background, bold: bold)
            }
        case .escape:
            if char == "[" {
                state = .bracket
                params = ""
            } else if char == "]" {
                state = .osc
                params = ""
            } else {
                state = .normal
            }
        case .bracket:
            if char.isLetter || char == "~" {
                handleCSI(command: char, buffer: buffer)
                state = .normal
            } else {
                params.append(char)
            }
        case .osc:
            if byte == 0x07 || (byte == 0x1B) {
                state = .normal
            }
        }
    }
    
    private func handleCSI(command: Character, buffer: TerminalBuffer) {
        let args = params.split(separator: ";").compactMap { Int($0) }
        switch command {
        case "m":
            handleSGR(args: args)
        case "H", "f":
            let y = (args.count > 0 ? args[0] : 1) - 1
            let x = (args.count > 1 ? args[1] : 1) - 1
            buffer.setCursor(x: x, y: y)
        case "J":
            if args.first == 2 {
                buffer.clearScreen()
            }
        case "K":
            break
        default:
            break
        }
    }
    
    private func handleSGR(args: [Int]) {
        var i = 0
        while i < args.count {
            let code = args[i]
            if code == 0 {
                foreground = 7
                background = 0
                bold = false
            } else if code == 1 {
                bold = true
            } else if code >= 30 && code <= 37 {
                foreground = UInt8(code - 30)
            } else if code == 39 {
                foreground = 7
            } else if code >= 40 && code <= 47 {
                background = UInt8(code - 40)
            } else if code == 49 {
                background = 0
            } else if code == 38 && i + 2 < args.count && args[i+1] == 5 {
                foreground = UInt8(args[i+2])
                i += 2
            } else if code == 48 && i + 2 < args.count && args[i+1] == 5 {
                background = UInt8(args[i+2])
                i += 2
            }
            i += 1
        }
    }
}
