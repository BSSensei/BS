import Foundation

class ToolDownloader {
    static let shared = ToolDownloader()
    private let binDirectory: URL
    
    private init() {
        let fileManager = FileManager.default
        let documents = fileManager.urls(for: .documentDirectory, in: .userDomainMask).first!
        binDirectory = documents.appendingPathComponent("bin", isDirectory: true)
        try? fileManager.createDirectory(at: binDirectory, withIntermediateDirectories: true, attributes: nil)
    }
    
    func downloadTool(from urlString: String, name: String, completion: @escaping (Bool, String) -> Void) {
        guard let url = URL(string: urlString) else {
            completion(false, "无效的 URL")
            return
        }
        
        let destinationURL = binDirectory.appendingPathComponent(name)
        
        let task = URLSession.shared.downloadTask(with: url) { localURL, response, error in
            if let error = error {
                completion(false, "下载失败: " + error.localizedDescription)
                return
            }
            guard let localURL = localURL else {
                completion(false, "本地文件 URL 为空")
                return
            }
            
            do {
                if FileManager.default.fileExists(atPath: destinationURL.path) {
                    try FileManager.default.removeItem(at: destinationURL)
                }
                try FileManager.default.moveItem(at: localURL, to: destinationURL)
                try FileManager.default.setAttributes([.posixPermissions: 0o755], ofItemAtPath: destinationURL.path)
                completion(true, "安装成功: " + destinationURL.path)
            } catch {
                completion(false, "文件处理失败: " + error.localizedDescription)
            }
        }
        task.resume()
    }
    
    func getEnvExportCommand() -> String {
        return "export PATH=\"" + binDirectory.path + ":$PATH\""
    }
}
