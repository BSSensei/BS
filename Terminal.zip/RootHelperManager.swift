import Foundation

class RootHelperManager {
    static let shared = RootHelperManager()
    private let helperName = "RootHelper"
    
    func prepareHelper() -> String? {
        guard let bundlePath = Bundle.main.path(forResource: helperName, ofType: nil) else {
            return nil
        }
        let tmpPath = FileManager.default.temporaryDirectory.appendingPathComponent(helperName).path
        let fileManager = FileManager.default
        if fileManager.fileExists(atPath: tmpPath) {
            try? fileManager.removeItem(atPath: tmpPath)
        }
        do {
            try fileManager.copyItem(atPath: bundlePath, toPath: tmpPath)
            try fileManager.setAttributes([.posixPermissions: 0o755], ofItemAtPath: tmpPath)
            return tmpPath
        } catch {
            return nil
        }
    }
}
