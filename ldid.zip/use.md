LDID 使用说明

一、基本格式

基本调用格式：

ldid [选项] 文件…

例如：

ldid -a MyApp

也可以一次处理多个文件：

ldid -a App1 App2 App3

二、版本信息

查看版本：

ldid -v

或：

ldid –version

三、签名功能

1. Ad-hoc 签名

使用：

ldid -a MyApp

例如：

ldid -a MyApp.app/MyApp

作用：

* 创建 CodeDirectory
* 计算代码页 Hash
* 创建 Mach-O embedded signature
* 写入 Entitlements
* 写入 Requirements
* 处理 FAT Mach-O
* 默认使用 SHA-256 CodeDirectory
* 设置 Ad-hoc 签名标志

2. 使用 Entitlements 签名

使用：

ldid -S entitlements.xml MyApp

也可以：

ldid -Sentitlements.xml MyApp

例如：

ldid -S MyApp.entitlements MyApp.app/MyApp

作用：

使用指定的 Entitlements 重新签名目标。

3. 保留原有 Entitlements 重新签名

使用：

ldid -s MyApp

作用：

重新签名，同时尝试保留原有签名中的 Entitlements。

4. 合并 Entitlements

使用：

ldid -M MyApp

作用：

进入 Entitlements merge / re-sign 流程。

当前 CLI 的 -M 会：

* 保留已有 Entitlements
* 保留已有 Identifier
* 保留已有 Team ID
* 保留已有 Requirements
* 重新生成签名

注意：

当前 CLI 的 -M 没有额外的 XML 文件参数。

如果需要指定新的 Entitlements 文件进行完整 merge，需要使用 C++ API 中的 merge_entitlements 功能。

5. 使用 P12 证书签名

使用：

ldid -K certificate.p12 MyApp

如果 P12 有密码：

ldid -K certificate.p12 -U password MyApp

其中：

-K
指定 PKCS#12/P12 证书。

-U
指定 P12 密码。

该模式用于生成带证书的 CMS 签名，而不是简单的 Ad-hoc 签名。

6. True Sign

使用：

ldid –true-sign …

作用：

启用真实证书/CMS 签名模式。

典型使用：

ldid –true-sign -K developer.p12 -U password MyApp

该模式会生成 CMS/PKCS#7 签名，并将 CodeDirectory 与 CMS 结构关联。

四、解除签名

使用：

ldid -r MyApp

例如：

ldid -r MyApp.app/MyApp

作用：

移除 Mach-O 中的 embedded code signature。

五、验证签名

使用：

ldid –verify MyApp

成功：

MyApp: valid

失败：

MyApp: invalid

并输出验证错误。

当前普通 –verify 的主要目标是：

* CodeDirectory 结构
* CodeDirectory Hash
* Special Slots
* Code Hash
* Entitlements
* Requirements
* CMS 数学签名
* embedded signature 完整性

普通验证不会要求完整 Apple 证书链信任。

因此：

Ad-hoc 签名
自签名
开发环境签名

也可以进行数学/结构验证。

六、查看签名信息

1. 默认显示

直接：

ldid MyApp

当前默认显示签名信息。

等价于：

ldid -d MyApp

2. -d

使用：

ldid -d MyApp

用于查看：

* Identifier
* Team ID
* CodeDirectory
* CodeDirectory Version
* Hash Type
* CodeDirectory Flags
* Code Slots
* Special Slots
* CDHash
* Entitlements
* Requirements
* CMS 等信息。

七、查看 Entitlements

使用：

ldid -e MyApp

例如：

ldid -e MyApp.app/MyApp

用于提取/显示 embedded Entitlements。

八、查看 Requirements

使用：

ldid -q MyApp

或者：

ldid -D MyApp

当前版本中：

-q
-D

实际进入相同的 Requirements 显示逻辑。

例如：

ldid -D MyApp

可以查看：

identifier
anchor
cdhash
certificate
entitlement
info
and
or
not

等 Requirements 内容。

九、查看 CDHash

使用：

ldid -h MyApp

例如：

ldid -h MyApp.app/MyApp

用于输出 CodeDirectory Hash，也就是常用的 CDHash。

当前实现的 canonical CDHash 长度为：

20 bytes

即：

160 bit

注意：

即使 CodeDirectory 使用 SHA-256 或 SHA-384，
canonical CDHash 仍然截取为 20 bytes。

十、Identifier

使用：

ldid -I com.example.app MyApp

也可以：

ldid -Icom.example.app MyApp

作用：

指定 CodeDirectory Identifier。

例如：

ldid -a -I com.example.test MyApp

最终 Identifier：

com.example.test

十一、Team ID

使用：

ldid -t ABCDE12345 MyApp

或者：

ldid -tABCDE12345 MyApp

例如：

ldid -a -I com.example.app -t ABCDE12345 MyApp

作用：

设置 CodeDirectory TeamIdentifier。

十二、Requirements

1. 指定 Requirements 文件

使用：

ldid -Q requirements.txt MyApp

或者：

ldid -Qrequirements.txt MyApp

当前 -N 也可以：

ldid -N requirements.txt MyApp

当前版本中：

-Q
-N

最终都设置 requirements_path。

2. Requirements 支持的表达式

当前实现支持：

true

false

anchor apple

anchor apple generic

identifier “com.example.app”

cdhash 00112233445566778899aabbccddeeff00112233

info[“key”]

entitlement[“key”]

certificate leaf[“field”]

certificate root[“field”]

certificate 0[“field”]

not (…)

(…) and (…)

(…) or (…)

3. 示例

简单 Identifier：

identifier “com.example.app”

Identifier + Apple Anchor：

(identifier “com.example.app”) and (anchor apple generic)

OR：

(identifier “com.example.app”) or (not (cdhash 00112233445566778899aabbccddeeff00112233))

复杂表达式可以嵌套：

(identifier “com.example.app”) and
((anchor apple generic) or (cdhash 00112233445566778899aabbccddeeff00112233))

十三、CodeDirectory Flags

使用：

ldid -C FLAG MyApp

例如：

ldid -a -Chard MyApp

多个 Flag：

ldid -a -Chard,kill,runtime MyApp

支持的 Flag：

host
CS_VALID

adhoc
CS_ADHOC

hard
CS_HARD

kill
CS_KILL

expires
CS_CHECK_EXPIRATION

check-expiration
CS_CHECK_EXPIRATION

restrict
CS_RESTRICT

enforcement
CS_ENFORCEMENT

library-validation
CS_REQUIRE_LV

runtime
CS_RUNTIME

linker-signed
CS_LINKER_SIGNED

取消 Flag：

ldid -a -Cno-runtime MyApp

例如：

ldid -a -Cruntime,no-library-validation MyApp

十四、Hash 类型

使用：

ldid -H sha1 MyApp

或者：

ldid -Hsha1 MyApp

SHA-256：

ldid -H sha256 MyApp

数字形式：

ldid -H1 MyApp

ldid -H2 MyApp

当前默认：

SHA-256

当前内部实现还支持：

SHA1
SHA256
SHA256_TRUNCATED
SHA384

但是需要注意：

当前 CLI parser 暴露的 Hash 参数主要是：

sha1
sha256
1
2

因此不能直接假设：

ldid -H sha384

在当前 CLI 中已经可用。

十五、Architecture

使用：

ldid -A arm64 MyApp

支持：

arm64
arm64e
arm64_32
arm
x86
i386
x86_64
x86_64h
ppc
ppc64

也可以指定：

CPU_TYPE:CPU_SUBTYPE

例如：

ldid -A 16777228:2 MyApp

十六、FAT / Universal Mach-O

使用：

ldid -arch arm64 MyApp

或者：

ldid –arch=arm64 MyApp

作用：

指定 Universal/FAT Mach-O 中需要处理的 architecture。

例如：

ldid -a -arch arm64 MyApp

表示选择 arm64 slice。

十七、Platform

使用：

ldid -P 2 MyApp

或者：

ldid -P2 MyApp

平台编号：

1  = macOS
2  = iOS
3  = tvOS
4  = watchOS
5  = bridgeOS
6  = Mac Catalyst
7  = iOS Simulator
8  = tvOS Simulator
9  = watchOS Simulator
10 = DriverKit

iOS 示例：

ldid -a -P2 MyApp

十八、Timestamp

当前 CLI 的 -T 使用整数时间戳。

例如：

ldid -a -T1720000000 MyApp

参数会通过：

std::stoll()

解析。

因此当前 CLI 的 -T 主要表示 Unix timestamp。

注意：

如果使用的是已经加入 RFC3161 TSA URL 支持的源码版本，
则 TSA URL 是另外的功能，不能与当前这个简单的整数 timestamp 参数混淆。

十九、Deep Sign

使用：

ldid –deep MyApp.app

作用：

递归处理 Bundle 内部的可签名 Mach-O / Bundle。

主要用于：

.app
.framework
.xpc
.appex
.kext
.plugin

等结构。

典型：

ldid –deep -a MyApp.app

二十、Super Deep Sign

使用：

ldid –super-deep MyApp.app

作用：

比普通 deep signing 更彻底地处理 Bundle 中的嵌套代码结构。

典型：

ldid –super-deep -a MyApp.app

二十一、Bundle 签名

C++ API 支持：

Signer::sign_bundle()

例如概念上：

Signer::sign_bundle(
“MyApp.app”,
options
);

Bundle 签名过程主要包括：

1. 查找嵌套 Bundle
2. 递归签名嵌套代码
3. 查找 Bundle executable
4. 签名 Mach-O
5. 生成 CodeResources
6. 生成 Bundle signature
7. 处理 Entitlements
8. 处理 nested bundle cdhash

二十二、CodeResources

Bundle 签名时会生成：

MyApp.app/
_CodeSignature/
CodeResources

当前实现的 CodeResources 包括：

files
files2
rules
rules2

其中：

files2

同时包含：

SHA-1 hash
SHA-256 hash

验证时会检查：

* Bundle 文件是否存在
* 文件 hash 是否匹配
* Symlink
* nested bundle
* _CodeSignature
* Info.plist
* PkgInfo
* .DS_Store

等情况。

二十三、IPA 签名

C++ API 支持：

Signer::sign_ipa()

例如概念调用：

Signer::sign_ipa(
“MyApp.ipa”,
“MyApp-signed.ipa”,
options
);

流程：

IPA
↓
解压
↓
找到 Payload/*.app
↓
处理 Bundle
↓
签名 Mach-O
↓
生成 CodeResources
↓
重新打包 IPA

二十四、Archive 签名

C++ API：

Signer::sign_archive()

例如：

Signer::sign_archive(
“input.zip”,
“output.zip”,
options
);

用于对 Archive 内的可签名内容进行处理。

二十五、Archive Engine

ArchiveEngine 提供：

create_archive()
create_ipa()
create_zip()
create_tar()

extract_ipa()
repack_ipa()

find_app_bundle()
find_executable_in_bundle()

stream_sign()

1. 创建 IPA

ArchiveEngine::create_ipa(
directory,
output
);

2. 创建 ZIP

ArchiveEngine::create_zip(
directory,
output
);

3. 创建 TAR

ArchiveEngine::create_tar(
directory,
output
);

4. 解压 IPA

ArchiveEngine::extract_ipa(
ipa,
directory
);

5. 重新打包 IPA

ArchiveEngine::repack_ipa(
directory,
output
);

6. 查找 App

ArchiveEngine::find_app_bundle(
directory
);

7. 查找 Bundle executable

ArchiveEngine::find_executable_in_bundle(
bundle
);

8. 流式签名

ArchiveEngine::stream_sign(
input,
output,
options
);

二十六、Memory API

除了文件签名，Signer 还支持直接对内存中的 Mach-O 操作。

1. Memory Sign

Signer::sign_memory(
data,
options
);

返回：

std::vector<uint8_t>

2. Memory Unsign

Signer::unsign_memory(
data
);

返回：

std::vector<uint8_t>

适合：

* 动态处理 Mach-O
* 不落盘签名
* 注入/构建工具
* 自己的 loader
* 上层程序集成

二十七、C++ Signer API

主要接口：

Signer::sign()

普通文件签名。

Signer::sign_memory()

内存 Mach-O 签名。

Signer::unsign()

文件解除签名。

Signer::unsign_memory()

内存解除签名。

Signer::deep_sign()

Deep 签名。

Signer::super_deep_sign()

Super Deep 签名。

Signer::merge_entitlements()

合并 Entitlements。

Signer::sign_ipa()

IPA 签名。

Signer::sign_archive()

Archive 签名。

Signer::sign_bundle()

Bundle 签名。

Signer::sign_plan()

执行预先建立的 ArchiveSignPlan。

二十八、Verifier API

C++：

Verifier::verify(path)

返回：

VerificationResult

可以检查：

result.ok

以及：

result.errors

例如：

if (result.ok) {
// 签名有效
} else {
// 签名无效
for (const auto& error : result.errors) {
…
}
}

二十九、签名参数 SignOptions

核心签名配置集中在：

SignOptions

主要控制：

* adhoc
* true_sign
* deep
* super_deep
* identifier
* team_id
* entitlements_path
* requirements_path
* preserve_entitlements
* p12_path
* key_password
* cd_flags
* hash_type
* platform
* arch
* timestamp
* merge_only
* no_overwrite
* write_copy
* output_stdout

因此如果作为 C++ 库使用，推荐直接构造：

SignOptions options;

然后设置：

options.adhoc = true;
options.identifier = “com.example.app”;
options.team_id = “ABCDE12345”;
options.hash_type = HashType::SHA256;

最后：

Signer::sign(path, options);

三十、典型使用场景

场景 1：最简单 Ad-hoc

ldid -a MyApp

场景 2：指定 Bundle Identifier

ldid -a -I com.example.app MyApp

场景 3：指定 Team ID

ldid -a -I com.example.app -t ABCDE12345 MyApp

场景 4：使用 Entitlements

ldid -a -S entitlements.plist MyApp

场景 5：保留已有 Entitlements

ldid -s MyApp

场景 6：指定 Requirements

ldid -a -Q requirements.txt MyApp

场景 7：指定 Runtime

ldid -a -Cruntime MyApp

场景 8：指定 iOS Platform

ldid -a -P2 MyApp

场景 9：指定 arm64

ldid -a -arch arm64 MyApp

场景 10：查看签名

ldid -d MyApp

场景 11：查看 Entitlements

ldid -e MyApp

场景 12：查看 Requirements

ldid -D MyApp

场景 13：查看 CDHash

ldid -h MyApp

场景 14：验证

ldid –verify MyApp

场景 15：解除签名

ldid -r MyApp

场景 16：Deep 签名

ldid –deep -a MyApp.app

场景 17：Super Deep 签名

ldid –super-deep -a MyApp.app

场景 18：P12 证书签名

ldid –true-sign -K developer.p12 -U password MyApp

三十一、推荐的完整 App 签名命令

最简单：

ldid -a MyApp.app/MyApp

带 Entitlements：

ldid -a -S MyApp.entitlements MyApp.app/MyApp

带 Identifier：

ldid -a 
-I com.example.app 
-S MyApp.entitlements 
MyApp.app/MyApp

带 Team ID：

ldid -a 
-I com.example.app 
-t ABCDE12345 
-S MyApp.entitlements 
MyApp.app/MyApp

完整 Bundle：

ldid –deep 
-a 
-I com.example.app 
-t ABCDE12345 
-S MyApp.entitlements 
MyApp.app

三十二、推荐的检查流程

签名前：

ldid -d MyApp

查看：

* Identifier
* Team ID
* Hash
* Flags
* CodeDirectory

签名：

ldid -a -S entitlements.plist MyApp

签名后：

ldid -d MyApp

查看 Entitlements：

ldid -e MyApp

查看 Requirements：

ldid -D MyApp

查看 CDHash：

ldid -h MyApp

最后验证：

ldid –verify MyApp

完整流程：

ldid -d MyApp
ldid -a -S entitlements.plist MyApp
ldid -d MyApp
ldid -e MyApp
ldid -D MyApp
ldid -h MyApp
ldid –verify MyApp

三十三、功能分类总表

查看类：

-v / –version
查看版本

-d
查看签名详细信息

-e
查看 Entitlements

-D / -q
查看 Requirements

-h
查看 CDHash

签名类：

-a
Ad-hoc 签名

-S
指定 Entitlements

-s
保留 Entitlements 重新签名

-M
Merge Entitlements / 重新签名

-K
指定 P12

-U
P12 密码

–true-sign
CMS/证书签名

-I
Identifier

-t
Team ID

-Q / -N
Requirements

-C
CodeDirectory Flags

-H
Hash 类型

-P
Platform

-A
Architecture

-arch / –arch
FAT Architecture

递归签名：

–deep
Deep Sign

–super-deep
Super Deep Sign

验证/删除：

–verify
验证签名

-r
删除签名

其他：

-T
Timestamp

-w
Write Copy

-O
输出到 stdout

-n
不覆盖原文件

三十四、最常用命令速查

签名：

ldid -a App

指定 Entitlements：

ldid -a -S entitlements.plist App

保留 Entitlements：

ldid -s App

指定 Identifier：

ldid -a -I com.example.app App

指定 Team：

ldid -a -t ABCDE12345 App

查看信息：

ldid -d App

查看 Entitlements：

ldid -e App

查看 Requirements：

ldid -D App

查看 CDHash：

ldid -h App

验证：

ldid –verify App

解除签名：

ldid -r App

Deep：

ldid –deep -a App.app

Super Deep：

ldid –super-deep -a App.app

P12：

ldid –true-sign -K developer.p12 -U password App

三十五、实际工作中推荐流程

对于普通越狱开发 / Ad-hoc：

1. 准备 App
2. 准备 Entitlements
3. 使用 -a 签名
4. 使用 -d 检查 CodeDirectory
5. 使用 -e 检查 Entitlements
6. 使用 -D 检查 Requirements
7. 使用 -h 获取 CDHash
8. 使用 –verify 做最终验证

例如：

ldid -a 
-S entitlements.plist 
-I com.example.test 
MyApp.app/MyApp

ldid -d MyApp.app/MyApp

ldid -e MyApp.app/MyApp

ldid -D MyApp.app/MyApp

ldid -h MyApp.app/MyApp

ldid –verify MyApp.app/MyApp

对于完整 App Bundle：

ldid –deep 
-a 
-S entitlements.plist 
MyApp.app

然后：

ldid –verify MyApp.app

对于正式证书/CMS：

ldid –deep 
–true-sign 
-K developer.p12 
-U “password” 
MyApp.app

然后：

ldid -d MyApp.app

ldid -e MyApp.app

ldid -D MyApp.app

ldid -h MyApp.app

ldid –verify MyApp.app

三十六、当前版本需要特别注意的地方

1. 普通 –verify 不等于 Apple 系统信任验证。
2. -D 和 -q 当前 CLI 实际进入相同的 Requirements 显示逻辑。
3. -Q 和 -N 当前都设置 requirements_path。
4. -M 当前 CLI 没有独立的 XML 参数。
5. -H 的 CLI 支持范围与内部 HashType 枚举并不完全一致。
6. -T 当前 CLI 解析的是整数时间戳。
7. –deep 和 –super-deep 都会进入签名流程。
8. FAT Mach-O 会按照 architecture slice 进行处理。
9. CDHash 的 canonical 输出长度是 20 bytes。
10. CodeResources 属于 Bundle 签名的一部分，不是单独的 Mach-O CodeDirectory。
11. P12/CMS 签名与 Ad-hoc 签名属于两套不同的签名路径。
12. 如果只是对单个 Mach-O 做 Ad-hoc 签名，最简单的命令就是：

ldid -a MyApp

13. 如果是完整 .app，通常应该使用：

ldid –deep -a MyApp.app

14. 如果需要 Entitlements：

ldid –deep -a -S entitlements.plist MyApp.app

15. 最终一定建议执行：

ldid –verify MyApp.app
::