#ifndef LDID_HPP
#define LDID_HPP

#include <cstdint>
#include <cstddef>
#include <string>
#include <vector>
#include <memory>
#include <functional>
#include <unordered_map>
#include <optional>
#include <variant>
#include <filesystem>
#include <mutex>
#include <openssl/evp.h>
#include <openssl/x509.h>
#include <openssl/pkcs12.h>
#include <openssl/pkcs7.h>
#include <openssl/bio.h>
#include <openssl/err.h>
#include <openssl/asn1.h>
#include <openssl/asn1t.h>
#include <openssl/objects.h>
#include <openssl/provider.h>
#include <openssl/stack.h>
#include <plist/plist.h>
#include <archive.h>
#include <archive_entry.h>

namespace ldid {

enum class CPUType : uint32_t {
    ANY = 0xFFFFFFFF,
    I386 = 7,
    X86_64 = 0x01000007,
    ARM = 12,
    ARM64 = 0x0100000C,
    ARM64_32 = 0x0200000C,
    POWERPC = 18,
    POWERPC64 = 0x01000012
};

enum class FileType : uint32_t {
    OBJECT = 0x1,
    EXECUTE = 0x2,
    DYLIB = 0x6,
    BUNDLE = 0x8,
    DSYM = 0xA
};

enum class HashType : uint8_t {
    SHA1 = 1,
    SHA256 = 2
};

enum class Platform : uint8_t {
    MACOS = 1,
    IOS = 2,
    TVOS = 3
};

enum class CodeDirectoryFlag : uint32_t {
    NONE = 0,
    HOST = 0x0001,
    ADHOC = 0x0002,
    FORCE_HARD = 0x0100,
    FORCE_KILL = 0x0200,
    FORCE_EXPIRATION = 0x0400,
    RESTRICT = 0x0800,
    ENFORCEMENT = 0x1000,
    LIBRARY_VALIDATION = 0x2000,
    RUNTIME = 0x10000,
    LINKER_SIGNED = 0x20000
};

enum class ArchiveFormat : uint8_t {
    ZIP,
    TAR,
    TAR_GZ,
    TAR_BZ2,
    TAR_XZ,
    CPIO,
    SEVEN_ZIP,
    ISO9660,
    AUTO
};

struct Slice {
    uint64_t offset;
    uint64_t size;
    CPUType cpu_type;
    uint32_t cpu_subtype;
    uint32_t align;
};

struct SignatureInfo {
    std::string identifier;
    std::string team_id;
    uint32_t flags;
    Platform platform;
    std::vector<uint8_t> cd_hash_sha1;
    std::vector<uint8_t> cd_hash_sha256;
    std::string entitlements_xml;
    std::vector<uint8_t> requirements_blob;
    bool is_adhoc;
};

struct SignOptions {
    std::string identifier;
    std::string team_id;
    std::string entitlements_path;
    std::string requirements_path;
    std::string key_path;
    std::string cert_path;
    std::string password;
    uint32_t flags;
    Platform platform;
    bool merge_entitlements;
    bool adhoc;
    bool true_sign;
    uint8_t page_shift;
    std::vector<HashType> hash_types;
};

struct ArchiveEntryInfo {
    std::string pathname;
    uint64_t size;
    uint32_t filetype;
    bool is_dir;
    bool is_symlink;
    std::string symlink_target;
    uint32_t permissions;
    int64_t mtime;
};

struct ArchiveSignPlan {
    std::vector<std::string> executable_paths;
    std::vector<std::string> bundle_paths;
    std::vector<std::string> framework_paths;
    std::vector<std::string> dylib_paths;
    std::string app_bundle_root;
    std::string main_executable;
};

class KeychainManager {
public:
    static KeychainManager& instance();
    bool add_identity(const std::string& label, const std::vector<uint8_t>& p12_data, const std::string& password);
    std::optional<std::pair<EVP_PKEY*, X509*>> find_identity(const std::string& query);
    std::vector<std::string> list_identities();
    void clear();

private:
    KeychainManager() = default;
    ~KeychainManager() = default;
    KeychainManager(const KeychainManager&) = delete;
    KeychainManager& operator=(const KeychainManager&) = delete;

    struct IdentityEntry {
        std::string label;
        std::vector<uint8_t> p12_data;
        std::string password;
        std::string common_name;
        std::string sha1_hash;
        std::string team_id;
    };

    std::vector<IdentityEntry> identities_;
    std::mutex mutex_;
    std::string compute_cert_hash(X509* cert);
    std::string extract_common_name(X509* cert);
    std::string extract_team_id(X509* cert);
};

class CryptoEngine {
public:
    static std::vector<uint8_t> sha1(const void* data, size_t len);
    static std::vector<uint8_t> sha256(const void* data, size_t len);
    static std::vector<uint8_t> sign_pkcs7(EVP_PKEY* pkey, X509* cert, STACK_OF(X509)* ca, const std::vector<uint8_t>& payload, bool include_cdhash_attrs);
    static std::vector<std::vector<uint8_t>> extract_certs_from_pkcs7(const std::vector<uint8_t>& pkcs7_data);
    static bool verify_pkcs7(const std::vector<uint8_t>& pkcs7_data, const std::vector<uint8_t>& payload);
};

class MachOParser {
public:
    static std::vector<Slice> parse_slices(const std::vector<uint8_t>& data);
    static std::vector<uint8_t> read_slice(const std::vector<uint8_t>& data, const Slice& slice);
    static bool is_fat(const std::vector<uint8_t>& data);
    static bool is_macho(const std::vector<uint8_t>& data);
    static FileType get_file_type(const std::vector<uint8_t>& data, const Slice& slice);
    static std::tuple<uint64_t, uint64_t> get_exec_seg_info(const std::vector<uint8_t>& data, const Slice& slice);
    static std::optional<SignatureInfo> get_signature_info(const std::vector<uint8_t>& data, const Slice& slice);
};

class BlobBuilder {
public:
    static std::vector<uint8_t> make_blob(uint32_t magic, const std::vector<uint8_t>& payload);
    static std::vector<uint8_t> build_superblob(uint32_t magic, const std::vector<std::pair<uint32_t, std::vector<uint8_t>>>& items);
    static std::vector<uint8_t> build_code_directory(
        const std::string& identifier,
        const std::string& team_id,
        uint64_t code_limit,
        const std::vector<std::vector<uint8_t>>& page_hashes,
        const std::unordered_map<uint32_t, std::vector<uint8_t>>& special_hashes,
        HashType hash_type,
        uint32_t flags,
        Platform platform,
        uint8_t page_shift,
        uint64_t exec_seg_base,
        uint64_t exec_seg_limit,
        uint64_t exec_seg_flags
    );
    static std::vector<uint8_t> build_entitlements_blob(const std::string& xml);
    static std::vector<uint8_t> build_der_entitlements_blob(plist_t plist);
    static std::vector<uint8_t> build_requirements_blob(const std::vector<uint8_t>& raw_req);
};

class ArchiveEngine {
public:
    static std::vector<ArchiveEntryInfo> list(const std::filesystem::path& archive_path);
    static bool extract(const std::filesystem::path& archive_path, const std::filesystem::path& dest_dir);
    static bool extract_file(const std::filesystem::path& archive_path, const std::string& entry_path, std::vector<uint8_t>& out_data);
    static bool create_archive(const std::filesystem::path& source_dir, const std::filesystem::path& output_path, ArchiveFormat format);
    static bool create_ipa(const std::filesystem::path& app_bundle_path, const std::filesystem::path& output_ipa);
    static bool extract_ipa(const std::filesystem::path& ipa_path, const std::filesystem::path& dest_dir);
    static bool repack_ipa(const std::filesystem::path& extracted_dir, const std::filesystem::path& output_ipa);
    static bool create_zip(const std::filesystem::path& source_dir, const std::filesystem::path& output_zip);
    static bool create_tar(const std::filesystem::path& source_dir, const std::filesystem::path& output_tar, ArchiveFormat format);
    static std::optional<std::string> find_app_bundle(const std::filesystem::path& dir);
    static std::optional<std::string> find_executable_in_bundle(const std::filesystem::path& bundle_path);
    static ArchiveSignPlan scan_for_signables(const std::filesystem::path& root);
    static bool is_archive(const std::filesystem::path& path);
    static ArchiveFormat detect_format(const std::filesystem::path& path);

private:
    static bool add_directory_recursive(struct archive* a, const std::filesystem::path& dir, const std::string& prefix);
    static bool add_file_to_archive(struct archive* a, const std::filesystem::path& file_path, const std::string& entry_name);
    static void configure_write_format(struct archive* a, ArchiveFormat format);
};

class Verifier {
public:
    enum class Result {
        VALID,
        INVALID_SIGNATURE,
        INVALID_FORMAT,
        NOT_SIGNED,
        IO_ERROR
    };

    static Result verify(const std::filesystem::path& path);
    static Result verify_memory(const std::vector<uint8_t>& data);
    static bool verify_with_system(const std::filesystem::path& path);

private:
    static bool verify_slice(const std::vector<uint8_t>& data, const Slice& slice);
};

class Signer {
public:
    static bool sign(const std::filesystem::path& path, const SignOptions& options);
    static bool sign_memory(std::vector<uint8_t>& data, const SignOptions& options);
    static bool unsign(const std::filesystem::path& path);
    static bool unsign_memory(std::vector<uint8_t>& data);
    static bool deep_sign(const std::filesystem::path& bundle_path, const SignOptions& options);
    static bool sign_ipa(const std::filesystem::path& ipa_path, const SignOptions& options, const std::filesystem::path& output_ipa);
    static bool sign_archive(const std::filesystem::path& archive_path, const SignOptions& options, const std::filesystem::path& output_path);
    static bool sign_bundle(const std::filesystem::path& bundle_path, const SignOptions& options);

private:
    static bool sign_single_slice(std::vector<uint8_t>& slice_data, const SignOptions& options, EVP_PKEY* pkey, X509* cert, STACK_OF(X509)* ca);
    static std::vector<uint8_t> generate_code_resources(const std::filesystem::path& bundle_path);
    static std::string merge_entitlements(const std::string& existing_xml, const std::string& new_xml);
    static bool sign_all_executables(const std::filesystem::path& root, const SignOptions& options, EVP_PKEY* pkey, X509* cert, STACK_OF(X509)* ca);
    static bool sign_plan(const ArchiveSignPlan& plan, const SignOptions& options, EVP_PKEY* pkey, X509* cert, STACK_OF(X509)* ca);
};

static bool sign_single_slice_impl(std::vector<uint8_t>& slice_data, const SignOptions& options, EVP_PKEY* pkey, X509* cert, STACK_OF(X509)* ca, const std::vector<uint8_t>* res_sha1, const std::vector<uint8_t>* res_sha256);
static bool sign_single_slice_from_path(const std::filesystem::path& path, const SignOptions& options, EVP_PKEY* pkey, X509* cert, STACK_OF(X509)* ca, const std::vector<uint8_t>* res_sha1, const std::vector<uint8_t>* res_sha256);

class Display {
public:
    static void display_signature(const std::filesystem::path& path);
    static void display_entitlements(const std::filesystem::path& path);
    static void display_requirements(const std::filesystem::path& path);
    static void display_certificates(const std::filesystem::path& path);
    static void print_cdhash(const std::filesystem::path& path);
    static void display_archive_contents(const std::filesystem::path& path);
};

std::vector<uint8_t> read_file(const std::filesystem::path& path);
bool write_file(const std::filesystem::path& path, const std::vector<uint8_t>& data);

}

#endif
