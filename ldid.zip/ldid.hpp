#ifndef LDID_HPP
#define LDID_HPP

#include <cstdint>
#include <cstring>
#include <string>
#include <vector>
#include <map>
#include <set>
#include <memory>
#include <functional>
#include <filesystem>
#include <optional>
#include <variant>
#include <stdexcept>
#include <iostream>
#include <fstream>
#include <sstream>
#include <algorithm>
#include <numeric>

#include <openssl/evp.h>
#include <openssl/x509.h>
#include <openssl/pkcs7.h>
#include <openssl/pkcs12.h>
#include <openssl/bio.h>
#include <openssl/err.h>

#include <plist/plist.h>

#include <archive.h>
#include <archive_entry.h>

namespace ldid {

enum class CPUType : uint32_t {
    ANY = 0xFFFFFFFF,
    X86 = 7,
    X86_64 = 0x01000007,
    ARM = 12,
    ARM64 = 0x0100000C,
    ARM64_32 = 0x0200000C,
    POWERPC = 18,
    POWERPC64 = 0x01000012
};

enum class FileType : uint32_t {
    OBJECT = 1,
    EXECUTE = 2,
    FVMLIB = 3,
    CORE = 4,
    PRELOAD = 5,
    DYLIB = 6,
    DYLINKER = 7,
    BUNDLE = 8,
    DYLIB_STUB = 9,
    DSYM = 10,
    KEXT_BUNDLE = 11
};

enum class HashType : uint32_t {
    ANY = 0,
    SHA1 = 1,
    SHA256 = 2,
    SHA256_TRUNCATED = 3,
    SHA384 = 4
};

enum class Platform : uint32_t {
    UNKNOWN = 0,
    MACOS = 1,
    IOS = 2,
    TVOS = 3,
    WATCHOS = 4,
    BRIDGEOS = 5,
    MACCATALYST = 6,
    IOSSIMULATOR = 7,
    TVOSSIMULATOR = 8,
    WATCHOSSIMULATOR = 9,
    DRIVERKIT = 10
};

enum class CodeDirectoryFlag : uint32_t {
    NONE = 0,
    VALID = 1,
    ADHOC = 2,
    HARD = 0x100,
    KILL = 0x200,
    CHECK_EXPIRATION = 0x400,
    RESTRICT = 0x800,
    ENFORCEMENT = 0x1000,
    GET_TASK_ALLOW = 0x2000,
    LIBRARY_VALIDATION = 0x4000,
    FOR_TESTING = 0x8000,
    RUNTIME = 0x10000,
    LINKER_SIGNED = 0x20000
};

enum class ArchiveFormat {
    UNKNOWN,
    ZIP,
    TAR,
    IPA
};

enum class BlobMagic : uint32_t {
    CSMAGIC_REQUIREMENT = 0xfade0c00,
    CSMAGIC_REQUIREMENTS = 0xfade0c01,
    CSMAGIC_CODEDIRECTORY = 0xfade0c02,
    CSMAGIC_EMBEDDED_SIGNATURE = 0xfade0cc0,
    CSMAGIC_DETACHED_SIGNATURE = 0xfade0cc1,
    CSMAGIC_BLOBWRAPPER = 0xfade0b01,
    CSMAGIC_EMBEDDED_ENTITLEMENTS = 0xfade7171,
    CSMAGIC_EMBEDDED_DER_ENTITLEMENTS = 0xfade7172
};

enum class CodeSignSlot : uint32_t {
    CODEDIRECTORY = 0,
    INFOSLOT = 1,
    REQUIREMENTS = 2,
    RESOURCESLOT = 3,
    APPLICATION = 4,
    ENTITLEMENTS = 5,
    REPSPECIFIC = 6,
    DER_ENTITLEMENTS = 7,
    ALTERNATE_BASE = 0x1000,
    CMS_SIGNATURE = 0x10000
};

struct Slice {
    uint64_t offset = 0;
    uint64_t size = 0;
    CPUType cpu_type = CPUType::ANY;
    uint32_t cpu_subtype = 0;
    uint64_t align = 0;
    bool fat64_container = false;
    bool fat_cigam_container = false;
};

struct SignatureInfo {
    std::string identifier;
    std::string team_id;
    std::vector<uint8_t> cd_hash;
    HashType hash_type = HashType::SHA256;
    std::vector<uint8_t> cms_signature;
    std::string entitlements_xml;
    std::vector<uint8_t> entitlements_der;
    std::vector<uint8_t> requirements_blob;
    bool adhoc = false;
    bool true_sign = false;
    uint32_t flags = 0;
    uint32_t version = 0;
};

struct SignOptions {
    std::string input_path;
    std::string output_path;
    std::string identifier;
    std::string team_id;
    std::string certificate_path;
    std::string private_key_path;
    std::string p12_path;
    std::string key_password;
    std::string entitlements_path;
    std::string merge_entitlements_path;
    std::string requirements_path;
    std::string requirements_xml;
    std::string arch;
    std::string timestamp_url;
    std::string timestamp_policy;
    HashType hash_type = HashType::SHA256;
    Platform platform = Platform::UNKNOWN;
    uint32_t min_os_version = 0;
    uint32_t sdk_version = 0;
    uint32_t cd_flags = 0;
    int64_t timestamp = 0;
    bool adhoc = false;
    bool true_sign = false;
    bool deep = false;
    bool super_deep = false;
    bool force = false;
    bool write_copy = false;
    bool no_overwrite = false;
    bool output_stdout = false;
    bool preserve_entitlements = false;
    bool merge_only = false;
    bool sign_executables_only = false;
    bool library_validation = false;
    bool runtime = false;
    bool linker_signed = false;
    bool emit_signing_time = true;
    bool timestamp_enabled = false;
    bool timestamp_required = false;
};

struct ArchiveEntryInfo {
    std::string path;
    uint64_t size = 0;
    bool is_directory = false;
    bool is_executable = false;
    bool is_symlink = false;
    bool is_signable = false;
};

struct ArchiveSignPlan {
    std::vector<std::string> macho_paths;
    std::vector<std::string> bundle_paths;
    std::vector<std::string> nested_bundle_paths;
    std::vector<std::string> framework_paths;
    std::string root_dir;
    bool requires_code_resources = false;
};

struct VerificationResult {
    bool ok = false;
    std::string message;
    std::vector<std::string> errors;
    explicit operator bool() const {
        return ok;
    }
};

struct StreamingSignContext {
    enum class Mode {
        FULL_EXTRACT,
        PASSTHROUGH,
        INPLACE
    };
    Mode mode = Mode::FULL_EXTRACT;
    std::filesystem::path work_dir;
    ArchiveSignPlan plan;
    SignOptions options;
};

std::vector<uint8_t> read_file(const std::filesystem::path& path);
bool write_file(const std::filesystem::path& path, const std::vector<uint8_t>& data);
std::string read_text(const std::filesystem::path& path);
bool write_text(const std::filesystem::path& path, const std::string& text);
std::string to_hex(const std::vector<uint8_t>& data);
std::vector<uint8_t> from_hex(const std::string& hex);
std::string default_identifier_from_path(const std::filesystem::path& path);

class CryptoEngine {
public:
    static std::vector<uint8_t> sha1(const std::vector<uint8_t>& data);
    static std::vector<uint8_t> sha256(const std::vector<uint8_t>& data);
    static std::vector<uint8_t> hash(HashType type, const std::vector<uint8_t>& data);
    static std::vector<uint8_t> sign_pkcs7(const std::vector<uint8_t>& data, const std::string& cert_path, const std::string& key_path, const std::string& password);
    static bool verify_pkcs7(const std::vector<uint8_t>& data, const std::vector<uint8_t>& signature);
    static std::vector<uint8_t> build_apple_cdhash_attr(const std::vector<uint8_t>& cd_hash, HashType hash_type);
    static std::vector<std::vector<uint8_t>> extract_certs_raw(const std::string& cert_path);
};

class KeychainManager {
public:
    static bool load_p12(const std::string& path, const std::string& password, std::vector<uint8_t>& cert_der, std::vector<uint8_t>& key_der);
    static std::string extract_team_id_from_certificate_file(const std::string& cert_path);
    static std::string extract_team_id_from_p12(const std::string& p12_path, const std::string& password);
    static std::vector<uint8_t> get_public_key_hash(const std::string& cert_path);
};

class MachOParser {
public:
    static bool is_macho(const std::vector<uint8_t>& data);
    static std::vector<Slice> parse_slices(const std::vector<uint8_t>& data);
    static std::vector<uint8_t> select_slice(const std::vector<uint8_t>& data, const std::string& arch);
    static SignatureInfo get_signature_info(const std::vector<uint8_t>& data);
    static std::vector<uint8_t> strip_signature(const std::vector<uint8_t>& data);
    static std::vector<uint8_t> embed_signature(const std::vector<uint8_t>& data, const std::vector<uint8_t>& signature);
    static std::vector<uint8_t> rebuild_fat(const std::vector<std::vector<uint8_t>>& slices);
};

class BlobBuilder {
public:
    static std::vector<uint8_t> make_blob(BlobMagic magic, const std::vector<uint8_t>& data);
    static std::vector<uint8_t> build_superblob(const std::map<uint32_t, std::vector<uint8_t>>& blobs);
    static std::vector<uint8_t> build_code_directory(const std::vector<uint8_t>& code, const std::string& identifier, const std::string& team_id, HashType hash_type, uint32_t flags);
    static std::vector<uint8_t> build_cd_versioned(const std::vector<uint8_t>& code, const std::string& identifier, const std::string& team_id, HashType hash_type, uint32_t flags, uint32_t version);
    static std::vector<uint8_t> build_entitlements_blob(const std::string& xml);
    static std::vector<uint8_t> build_der_entitlements_blob(const std::string& xml);
    static std::vector<uint8_t> build_requirements_blob(const std::string& identifier, const std::string& team_id);
    static std::vector<uint8_t> build_dr(const std::string& identifier, const std::string& team_id);
    static std::vector<uint8_t> compile_requirements(const std::string& xml);
    static std::vector<uint8_t> der_encode_plist_xml(const std::string& xml);
};

class ArchiveEngine {
public:
    static bool is_archive(const std::filesystem::path& path);
    static ArchiveFormat detect_format(const std::filesystem::path& path);
    static std::vector<ArchiveEntryInfo> list_contents(const std::filesystem::path& path);
    static std::vector<ArchiveEntryInfo> scan_for_signables(const std::filesystem::path& dir);
    static void extract_archive(const std::filesystem::path& archive_path, const std::filesystem::path& out_dir);
    static void create_archive(const std::filesystem::path& dir, const std::filesystem::path& out, ArchiveFormat format);
    static void create_ipa(const std::filesystem::path& dir, const std::filesystem::path& out);
    static void create_zip(const std::filesystem::path& dir, const std::filesystem::path& out);
    static void create_tar(const std::filesystem::path& dir, const std::filesystem::path& out);
    static void extract_ipa(const std::filesystem::path& ipa, const std::filesystem::path& dir);
    static void repack_ipa(const std::filesystem::path& dir, const std::filesystem::path& out);
    static std::filesystem::path find_app_bundle(const std::filesystem::path& dir);
    static std::filesystem::path find_executable_in_bundle(const std::filesystem::path& bundle);
    static void stream_sign(const std::filesystem::path& in, const std::filesystem::path& out, const SignOptions& options);
};

class Signer {
public:
    static void sign(const std::filesystem::path& path, const SignOptions& options);
    static std::vector<uint8_t> sign_memory(const std::vector<uint8_t>& data, const SignOptions& options);
    static void unsign(const std::filesystem::path& path);
    static std::vector<uint8_t> unsign_memory(const std::vector<uint8_t>& data);
    static void reset_cryptid(const std::filesystem::path& path);
    static void deep_sign(const std::filesystem::path& path, const SignOptions& options);
    static void super_deep_sign(const std::filesystem::path& path, const SignOptions& options);
    static void merge_entitlements(const std::filesystem::path& path, const SignOptions& options);
    static void sign_ipa(const std::filesystem::path& ipa, const std::filesystem::path& out, const SignOptions& options);
    static void sign_archive(const std::filesystem::path& archive, const std::filesystem::path& out, const SignOptions& options);
    static void sign_bundle(const std::filesystem::path& bundle, const SignOptions& options);
    static void sign_plan(const ArchiveSignPlan& plan, const SignOptions& options);
};

class Verifier {
public:
    static VerificationResult verify(const std::filesystem::path& path);
    static VerificationResult verify_memory(const std::vector<uint8_t>& data);
    static VerificationResult verify_with_system(const std::filesystem::path& path);
    static VerificationResult verify_bundle(const std::filesystem::path& bundle);
    static VerificationResult verify_archive(const std::filesystem::path& archive);
};

class Display {
public:
    static void display_info(const std::filesystem::path& path);
    static void display_signature(const std::filesystem::path& path);
    static void display_entitlements(const std::filesystem::path& path);
    static void display_requirements(const std::filesystem::path& path);
    static void display_cdhash(const std::filesystem::path& path);
    static void display_archive_contents(const std::filesystem::path& path);
    static void display_certificates(const std::filesystem::path& path);
};

}

#endif