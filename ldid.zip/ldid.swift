import Foundation
#if canImport(Darwin)
import Darwin
#elseif canImport(Glibc)
import Glibc
#elseif canImport(Musl)
import Musl
#endif

let CPU_TYPE_ANY: UInt32 = UInt32(bitPattern: -1)
let CPU_ARCH_ABI64: UInt32 = 0x1000000
let CPU_ARCH_ABI64_32: UInt32 = 0x2000000
let CPU_TYPE_I386: UInt32 = 7
let CPU_TYPE_X86_64: UInt32 = CPU_TYPE_I386 | CPU_ARCH_ABI64
let CPU_TYPE_ARM: UInt32 = 12
let CPU_TYPE_ARM64: UInt32 = CPU_TYPE_ARM | CPU_ARCH_ABI64
let CPU_TYPE_ARM64_32: UInt32 = CPU_TYPE_ARM | CPU_ARCH_ABI64_32
let CPU_TYPE_POWERPC: UInt32 = 18
let CPU_TYPE_POWERPC64: UInt32 = CPU_TYPE_POWERPC | CPU_ARCH_ABI64
let CPU_TYPE_MC680x0: UInt32 = 6
let CPU_TYPE_HPPA: UInt32 = 11
let CPU_TYPE_SPARC: UInt32 = 14
let CPU_TYPE_MC88000: UInt32 = 13
let CPU_TYPE_I860: UInt32 = 15
let CPU_TYPE_SPARC32: UInt32 = 14
let CPU_SUBTYPE_MULTIPLE: UInt32 = UInt32(bitPattern: -1)
let CPU_SUBTYPE_LITTLE_ENDIAN: UInt32 = 0
let CPU_SUBTYPE_BIG_ENDIAN: UInt32 = 1
let CPU_SUBTYPE_X86_64_ALL: UInt32 = 3
let CPU_SUBTYPE_X86_64_H: UInt32 = 8
let CPU_SUBTYPE_I386_ALL: UInt32 = 3
let CPU_SUBTYPE_486: UInt32 = 4
let CPU_SUBTYPE_486SX: UInt32 = 4 + 128
let CPU_SUBTYPE_586: UInt32 = 5
let CPU_SUBTYPE_PENT: UInt32 = 5
let CPU_SUBTYPE_PENTPRO: UInt32 = 6 + (1 << 4)
let CPU_SUBTYPE_PENTII_M3: UInt32 = 6 + (3 << 4)
let CPU_SUBTYPE_PENTII_M5: UInt32 = 6 + (5 << 4)
let CPU_SUBTYPE_PENTIUM_4: UInt32 = 10 + (0 << 4)
let CPU_SUBTYPE_MC680x0_ALL: UInt32 = 1
let CPU_SUBTYPE_MC68030_ONLY: UInt32 = 3
let CPU_SUBTYPE_MC68040: UInt32 = 2
let CPU_SUBTYPE_HPPA_ALL: UInt32 = 0
let CPU_SUBTYPE_HPPA_7100LC: UInt32 = 1
let CPU_SUBTYPE_SPARC_ALL: UInt32 = 0
let CPU_SUBTYPE_MC88000_ALL: UInt32 = 0
let CPU_SUBTYPE_I860_ALL: UInt32 = 0
let CPU_SUBTYPE_ARM_ALL: UInt32 = 0
let CPU_SUBTYPE_ARM_V4T: UInt32 = 5
let CPU_SUBTYPE_ARM_V5TEJ: UInt32 = 7
let CPU_SUBTYPE_ARM_XSCALE: UInt32 = 8
let CPU_SUBTYPE_ARM_V6: UInt32 = 6
let CPU_SUBTYPE_ARM_V6M: UInt32 = 14
let CPU_SUBTYPE_ARM_V7: UInt32 = 9
let CPU_SUBTYPE_ARM_V7F: UInt32 = 10
let CPU_SUBTYPE_ARM_V7S: UInt32 = 11
let CPU_SUBTYPE_ARM_V7K: UInt32 = 12
let CPU_SUBTYPE_ARM_V7M: UInt32 = 15
let CPU_SUBTYPE_ARM_V7EM: UInt32 = 16
let CPU_SUBTYPE_ARM_V8: UInt32 = 13
let CPU_SUBTYPE_ARM64_ALL: UInt32 = 0
let CPU_SUBTYPE_ARM64_V8: UInt32 = 1
let CPU_SUBTYPE_ARM64E: UInt32 = 2
let CPU_SUBTYPE_ARM64_32_V8: UInt32 = 1
let CPU_SUBTYPE_POWERPC_ALL: UInt32 = 0
let CPU_SUBTYPE_POWERPC_601: UInt32 = 1
let CPU_SUBTYPE_POWERPC_603: UInt32 = 3
let CPU_SUBTYPE_POWERPC_603e: UInt32 = 4
let CPU_SUBTYPE_POWERPC_603ev: UInt32 = 5
let CPU_SUBTYPE_POWERPC_604: UInt32 = 6
let CPU_SUBTYPE_POWERPC_604e: UInt32 = 7
let CPU_SUBTYPE_POWERPC_750: UInt32 = 9
let CPU_SUBTYPE_POWERPC_7400: UInt32 = 10
let CPU_SUBTYPE_POWERPC_7450: UInt32 = 11
let CPU_SUBTYPE_POWERPC_970: UInt32 = 100

struct ArchEntry {
    let name: String
    let cputype: UInt32
    let cpusubtype: UInt32
}

let archTable: [ArchEntry] = [
    ArchEntry(name: "any", cputype: CPU_TYPE_ANY, cpusubtype: CPU_SUBTYPE_MULTIPLE),
    ArchEntry(name: "little", cputype: CPU_TYPE_ANY, cpusubtype: CPU_SUBTYPE_LITTLE_ENDIAN),
    ArchEntry(name: "big", cputype: CPU_TYPE_ANY, cpusubtype: CPU_SUBTYPE_BIG_ENDIAN),
    ArchEntry(name: "ppc64", cputype: CPU_TYPE_POWERPC64, cpusubtype: CPU_SUBTYPE_POWERPC_ALL),
    ArchEntry(name: "x86_64", cputype: CPU_TYPE_X86_64, cpusubtype: CPU_SUBTYPE_X86_64_ALL),
    ArchEntry(name: "x86_64h", cputype: CPU_TYPE_X86_64, cpusubtype: CPU_SUBTYPE_X86_64_H),
    ArchEntry(name: "arm64", cputype: CPU_TYPE_ARM64, cpusubtype: CPU_SUBTYPE_ARM64_ALL),
    ArchEntry(name: "ppc970-64", cputype: CPU_TYPE_POWERPC64, cpusubtype: CPU_SUBTYPE_POWERPC_970),
    ArchEntry(name: "arm64_32", cputype: CPU_TYPE_ARM64_32, cpusubtype: CPU_SUBTYPE_ARM64_32_V8),
    ArchEntry(name: "arm64e", cputype: CPU_TYPE_ARM64, cpusubtype: CPU_SUBTYPE_ARM64E),
    ArchEntry(name: "ppc", cputype: CPU_TYPE_POWERPC, cpusubtype: CPU_SUBTYPE_POWERPC_ALL),
    ArchEntry(name: "i386", cputype: CPU_TYPE_I386, cpusubtype: CPU_SUBTYPE_I386_ALL),
    ArchEntry(name: "m68k", cputype: CPU_TYPE_MC680x0, cpusubtype: CPU_SUBTYPE_MC680x0_ALL),
    ArchEntry(name: "hppa", cputype: CPU_TYPE_HPPA, cpusubtype: CPU_SUBTYPE_HPPA_ALL),
    ArchEntry(name: "sparc", cputype: CPU_TYPE_SPARC, cpusubtype: CPU_SUBTYPE_SPARC_ALL),
    ArchEntry(name: "m88k", cputype: CPU_TYPE_MC88000, cpusubtype: CPU_SUBTYPE_MC88000_ALL),
    ArchEntry(name: "i860", cputype: CPU_TYPE_I860, cpusubtype: CPU_SUBTYPE_I860_ALL),
    ArchEntry(name: "arm", cputype: CPU_TYPE_ARM, cpusubtype: CPU_SUBTYPE_ARM_ALL),
    ArchEntry(name: "ppc601", cputype: CPU_TYPE_POWERPC, cpusubtype: CPU_SUBTYPE_POWERPC_601),
    ArchEntry(name: "ppc603", cputype: CPU_TYPE_POWERPC, cpusubtype: CPU_SUBTYPE_POWERPC_603),
    ArchEntry(name: "ppc603e", cputype: CPU_TYPE_POWERPC, cpusubtype: CPU_SUBTYPE_POWERPC_603e),
    ArchEntry(name: "ppc603ev", cputype: CPU_TYPE_POWERPC, cpusubtype: CPU_SUBTYPE_POWERPC_603ev),
    ArchEntry(name: "ppc604", cputype: CPU_TYPE_POWERPC, cpusubtype: CPU_SUBTYPE_POWERPC_604),
    ArchEntry(name: "ppc604e", cputype: CPU_TYPE_POWERPC, cpusubtype: CPU_SUBTYPE_POWERPC_604e),
    ArchEntry(name: "ppc750", cputype: CPU_TYPE_POWERPC, cpusubtype: CPU_SUBTYPE_POWERPC_750),
    ArchEntry(name: "ppc7400", cputype: CPU_TYPE_POWERPC, cpusubtype: CPU_SUBTYPE_POWERPC_7400),
    ArchEntry(name: "ppc7450", cputype: CPU_TYPE_POWERPC, cpusubtype: CPU_SUBTYPE_POWERPC_7450),
    ArchEntry(name: "ppc970", cputype: CPU_TYPE_POWERPC, cpusubtype: CPU_SUBTYPE_POWERPC_970),
    ArchEntry(name: "i486", cputype: CPU_TYPE_I386, cpusubtype: CPU_SUBTYPE_486),
    ArchEntry(name: "i486SX", cputype: CPU_TYPE_I386, cpusubtype: CPU_SUBTYPE_486SX),
    ArchEntry(name: "pentium", cputype: CPU_TYPE_I386, cpusubtype: CPU_SUBTYPE_PENT),
    ArchEntry(name: "i586", cputype: CPU_TYPE_I386, cpusubtype: CPU_SUBTYPE_586),
    ArchEntry(name: "pentpro", cputype: CPU_TYPE_I386, cpusubtype: CPU_SUBTYPE_PENTPRO),
    ArchEntry(name: "i686", cputype: CPU_TYPE_I386, cpusubtype: CPU_SUBTYPE_PENTPRO),
    ArchEntry(name: "pentIIm3", cputype: CPU_TYPE_I386, cpusubtype: CPU_SUBTYPE_PENTII_M3),
    ArchEntry(name: "pentIIm5", cputype: CPU_TYPE_I386, cpusubtype: CPU_SUBTYPE_PENTII_M5),
    ArchEntry(name: "pentium4", cputype: CPU_TYPE_I386, cpusubtype: CPU_SUBTYPE_PENTIUM_4),
    ArchEntry(name: "m68030", cputype: CPU_TYPE_MC680x0, cpusubtype: CPU_SUBTYPE_MC68030_ONLY),
    ArchEntry(name: "m68040", cputype: CPU_TYPE_MC680x0, cpusubtype: CPU_SUBTYPE_MC68040),
    ArchEntry(name: "hppa7100LC", cputype: CPU_TYPE_HPPA, cpusubtype: CPU_SUBTYPE_HPPA_7100LC),
    ArchEntry(name: "armv4t", cputype: CPU_TYPE_ARM, cpusubtype: CPU_SUBTYPE_ARM_V4T),
    ArchEntry(name: "armv5", cputype: CPU_TYPE_ARM, cpusubtype: CPU_SUBTYPE_ARM_V5TEJ),
    ArchEntry(name: "xscale", cputype: CPU_TYPE_ARM, cpusubtype: CPU_SUBTYPE_ARM_XSCALE),
    ArchEntry(name: "armv6", cputype: CPU_TYPE_ARM, cpusubtype: CPU_SUBTYPE_ARM_V6),
    ArchEntry(name: "armv6m", cputype: CPU_TYPE_ARM, cpusubtype: CPU_SUBTYPE_ARM_V6M),
    ArchEntry(name: "armv7", cputype: CPU_TYPE_ARM, cpusubtype: CPU_SUBTYPE_ARM_V7),
    ArchEntry(name: "armv7f", cputype: CPU_TYPE_ARM, cpusubtype: CPU_SUBTYPE_ARM_V7F),
    ArchEntry(name: "armv7s", cputype: CPU_TYPE_ARM, cpusubtype: CPU_SUBTYPE_ARM_V7S),
    ArchEntry(name: "armv7k", cputype: CPU_TYPE_ARM, cpusubtype: CPU_SUBTYPE_ARM_V7K),
    ArchEntry(name: "armv7m", cputype: CPU_TYPE_ARM, cpusubtype: CPU_SUBTYPE_ARM_V7M),
    ArchEntry(name: "armv7em", cputype: CPU_TYPE_ARM, cpusubtype: CPU_SUBTYPE_ARM_V7EM),
    ArchEntry(name: "arm64v8", cputype: CPU_TYPE_ARM64, cpusubtype: CPU_SUBTYPE_ARM64_V8)
]

let PAGE_SHIFT: UInt8 = 0x0c
let PAGE_SIZE: UInt32 = 1 << 12
let MAXSEGALIGN: UInt32 = 15
let MINSEGALIGN32: UInt32 = 2
let MINSEGALIGN64: UInt32 = 3
let LDID_VERSION = "3.0.0-rcodesign"

func fatal(_ message: String) -> Never {
    FileHandle.standardError.write((message + "\n").data(using: .utf8)!)
    exit(1)
}

func warn(_ message: String) {
    FileHandle.standardError.write((message + "\n").data(using: .utf8)!)
}

final class OutputBuffer {
    private(set) var data = Data()
    func put(_ bytes: UnsafeRawPointer, _ size: Int) {
        data.append(bytes.assumingMemoryBound(to: UInt8.self), count: size)
    }
    func put(_ bytes: [UInt8]) {
        data.append(contentsOf: bytes)
    }
    func putUInt8(_ value: UInt8) {
        data.append(value)
    }
    func putUInt16BE(_ value: UInt16) {
        data.append(UInt8((value >> 8) & 0xff))
        data.append(UInt8(value & 0xff))
    }
    func putUInt32BE(_ value: UInt32) {
        data.append(UInt8((value >> 24) & 0xff))
        data.append(UInt8((value >> 16) & 0xff))
        data.append(UInt8((value >> 8) & 0xff))
        data.append(UInt8(value & 0xff))
    }
    func putUInt32LE(_ value: UInt32) {
        data.append(UInt8(value & 0xff))
        data.append(UInt8((value >> 8) & 0xff))
        data.append(UInt8((value >> 16) & 0xff))
        data.append(UInt8((value >> 24) & 0xff))
    }
    func pad(_ size: Int) {
        if size <= 0 { return }
        data.append(Data(count: size))
    }
    var size: Int { return data.count }
    var count: Int { return data.count }
}

struct FatHeaderInfo {
    var magic: UInt32
    var nfatArch: UInt32
    var archs: [(cputype: UInt32, cpusubtype: UInt32, offset: UInt32, size: UInt32, align: UInt32)]
}

func readUInt32BE(_ data: Data, _ offset: Int) -> UInt32 {
    let b0 = UInt32(data[offset])
    let b1 = UInt32(data[offset + 1])
    let b2 = UInt32(data[offset + 2])
    let b3 = UInt32(data[offset + 3])
    return (b0 << 24) | (b1 << 16) | (b2 << 8) | b3
}

func readUInt32LE(_ data: Data, _ offset: Int) -> UInt32 {
    let b0 = UInt32(data[offset])
    let b1 = UInt32(data[offset + 1])
    let b2 = UInt32(data[offset + 2])
    let b3 = UInt32(data[offset + 3])
    return b0 | (b1 << 8) | (b2 << 16) | (b3 << 24)
}

func readUInt64LE(_ data: Data, _ offset: Int) -> UInt64 {
    let lo = UInt64(readUInt32LE(data, offset))
    let hi = UInt64(readUInt32LE(data, offset + 4))
    return lo | (hi << 32)
}

enum MachArch {
    case header(magic: UInt32, cputype: UInt32, cpusubtype: UInt32, filetype: UInt32, ncmds: UInt32, sizeofcmds: UInt32, flags: UInt32, bits64: Bool, swapped: Bool, offset: Int)
}

struct MachSlice {
    var offset: Int
    var size: Int
    var cputype: UInt32
    var cpusubtype: UInt32
    var align: UInt32
    var isFat: Bool
}

struct MachFile {
    var isFat: Bool
    var slices: [MachSlice]
    var data: Data
}

func parseMachFile(_ data: Data) -> MachFile {
    if data.count < 4 {
        fatal("ldid: File too small")
    }
    let magicLE = readUInt32LE(data, 0)
    let magicBE = readUInt32BE(data, 0)
    if magicBE == 0xcafebabe || magicLE == 0xcafebabe {
        let swapped = magicBE != 0xcafebabe
        let n = swapped ? readUInt32BE(data, 4) : readUInt32LE(data, 4)
        var slices: [MachSlice] = []
        var off = 8
        for _ in 0..<Int(n) {
            let cputype = swapped ? readUInt32BE(data, off) : readUInt32LE(data, off)
            let cpusubtype = swapped ? readUInt32BE(data, off + 4) : readUInt32LE(data, off + 4)
            let archOffset = swapped ? readUInt32BE(data, off + 8) : readUInt32LE(data, off + 8)
            let archSize = swapped ? readUInt32BE(data, off + 12) : readUInt32LE(data, off + 12)
            let align = swapped ? readUInt32BE(data, off + 16) : readUInt32LE(data, off + 16)
            slices.append(MachSlice(offset: Int(archOffset), size: Int(archSize), cputype: cputype, cpusubtype: cpusubtype, align: align, isFat: true))
            off += 20
        }
        return MachFile(isFat: true, slices: slices, data: data)
    }
    let magic = magicLE
    if magic == 0xfeedface || magic == 0xfeedfacf || magic == 0xcefaedfe || magic == 0xcffaedfe {
        let swapped = magic == 0xcefaedfe || magic == 0xcffaedfe
        let bits64 = magic == 0xfeedfacf || magic == 0xcffaedfe
        let cputype = swapped ? readUInt32BE(data, 4) : readUInt32LE(data, 4)
        let cpusubtype = swapped ? readUInt32BE(data, 8) : readUInt32LE(data, 8)
        let slice = MachSlice(offset: 0, size: data.count, cputype: cputype, cpusubtype: cpusubtype, align: bits64 ? 3 : 2, isFat: false)
        _ = bits64
        return MachFile(isFat: false, slices: [slice], data: data)
    }
    fatal("ldid: Unknown header magic\nAre you sure that is a Mach-O?")
}

func machFileType(_ data: Data, slice: MachSlice) -> UInt32 {
    let magicLE = readUInt32LE(data, slice.offset)
    let swapped = magicLE == 0xcefaedfe || magicLE == 0xcffaedfe
    let off = slice.offset + 12
    return swapped ? readUInt32BE(data, off) : readUInt32LE(data, off)
}

func machCpuType(_ data: Data, slice: MachSlice) -> UInt32 {
    return slice.cputype
}

func machCpuSubtype(_ data: Data, slice: MachSlice) -> UInt32 {
    return slice.cpusubtype
}

func archName(cputype: UInt32, cpusubtype: UInt32) -> String {
    for entry in archTable {
        if entry.cputype == cputype && entry.cpusubtype == cpusubtype {
            return entry.name
        }
    }
    return "any"
}

struct LoadCommand {
    var cmd: UInt32
    var cmdsize: UInt32
    var offset: Int
}

func loadCommands(_ data: Data, slice: MachSlice) -> [LoadCommand] {
    let magicLE = readUInt32LE(data, slice.offset)
    let swapped = magicLE == 0xcefaedfe || magicLE == 0xcffaedfe
    let bits64 = magicLE == 0xfeedfacf || magicLE == 0xcffaedfe
    let headerSize = bits64 ? 32 : 28
    let ncmds = swapped ? readUInt32BE(data, slice.offset + 16) : readUInt32LE(data, slice.offset + 16)
    var cmds: [LoadCommand] = []
    var off = slice.offset + headerSize
    for _ in 0..<Int(ncmds) {
        if off + 8 > slice.offset + slice.size { break }
        let cmd = swapped ? readUInt32BE(data, off) : readUInt32LE(data, off)
        let cmdsize = swapped ? readUInt32BE(data, off + 4) : readUInt32LE(data, off + 4)
        cmds.append(LoadCommand(cmd: cmd, cmdsize: cmdsize, offset: off))
        off += Int(cmdsize)
    }
    return cmds
}

func isBits64(_ data: Data, slice: MachSlice) -> Bool {
    let magicLE = readUInt32LE(data, slice.offset)
    return magicLE == 0xfeedfacf || magicLE == 0xcffaedfe
}

func isSwapped(_ data: Data, slice: MachSlice) -> Bool {
    let magicLE = readUInt32LE(data, slice.offset)
    return magicLE == 0xcefaedfe || magicLE == 0xcffaedfe
}

func readLE32(_ data: Data, _ offset: Int, swapped: Bool) -> UInt32 {
    return swapped ? readUInt32BE(data, offset) : readUInt32LE(data, offset)
}

func readLE64(_ data: Data, _ offset: Int, swapped: Bool) -> UInt64 {
    if swapped {
        let hi = UInt64(readUInt32BE(data, offset))
        let lo = UInt64(readUInt32BE(data, offset + 4))
        return (hi << 32) | lo
    }
    return readUInt64LE(data, offset)
}

func writeLE32(_ value: UInt32, swapped: Bool) -> [UInt8] {
    let v = swapped ? ldid_swap32(value) : value
    return [UInt8(v & 0xff), UInt8((v >> 8) & 0xff), UInt8((v >> 16) & 0xff), UInt8((v >> 24) & 0xff)]
}

func writeLE64(_ value: UInt64, swapped: Bool) -> [UInt8] {
    let v = swapped ? ldid_swap64(value) : value
    var out = [UInt8]()
    for i in 0..<8 {
        out.append(UInt8((v >> (i * 8)) & 0xff))
    }
    return out
}

func writeLE32At(_ buffer: inout Data, _ offset: Int, _ value: UInt32, swapped: Bool) {
    let bytes = writeLE32(value, swapped: swapped)
    buffer.replaceSubrange(offset..<offset+4, with: bytes)
}

func writeLE64At(_ buffer: inout Data, _ offset: Int, _ value: UInt64, swapped: Bool) {
    let bytes = writeLE64(value, swapped: swapped)
    buffer.replaceSubrange(offset..<offset+8, with: bytes)
}

func align(_ value: UInt64, _ alignment: UInt64) -> UInt64 {
    if alignment == 0 { return value }
    return (value + alignment - 1) / alignment * alignment
}

func alignInt(_ value: Int, _ alignment: Int) -> Int {
    if alignment == 0 { return value }
    return (value + alignment - 1) / alignment * alignment
}

struct SignatureBlob {
    var slot: UInt32
    var data: Data
}

func buildSuperBlob(magic: UInt32, blobs: [SignatureBlob]) -> Data {
    var blobData = Data()
    var indexData = Data()
    var offset = UInt32(12 + blobs.count * 8)
    for blob in blobs {
        var idx = Data()
        idx.append(contentsOf: writeLE32(blob.slot, swapped: true))
        idx.append(contentsOf: writeLE32(offset, swapped: true))
        indexData.append(idx)
        blobData.append(blob.data)
        offset += UInt32(blob.data.count)
    }
    var header = Data()
    header.append(contentsOf: writeLE32(magic, swapped: true))
    header.append(contentsOf: writeLE32(UInt32(12 + blobs.count * 8) + UInt32(blobData.count), swapped: true))
    header.append(contentsOf: writeLE32(UInt32(blobs.count), swapped: true))
    var result = Data()
    result.append(header)
    result.append(indexData)
    result.append(blobData)
    return result
}

func makeBlob(magic: UInt32, payload: Data) -> Data {
    var blob = Data()
    blob.append(contentsOf: writeLE32(magic, swapped: true))
    blob.append(contentsOf: writeLE32(UInt32(8 + payload.count), swapped: true))
    blob.append(payload)
    return blob
}

struct CodeDirectoryInfo {
    var version: UInt32
    var flags: UInt32
    var hashOffset: UInt32
    var identOffset: UInt32
    var nSpecialSlots: UInt32
    var nCodeSlots: UInt32
    var codeLimit: UInt32
    var hashSize: UInt8
    var hashType: UInt8
    var platform: UInt8
    var pageSize: UInt8
    var teamIDOffset: UInt32
    var codeLimit64: UInt64
    var execSegBase: UInt64
    var execSegLimit: UInt64
    var execSegFlags: UInt64
}

func buildCodeDirectory(
    identifier: String,
    team: String,
    codeLimit: UInt64,
    pageHashes: [Data],
    specialHashes: [UInt32: Data],
    hashType: UInt8,
    hashSize: Int,
    flags: UInt32,
    platform: UInt8,
    execSegBase: UInt64,
    execSegLimit: UInt64,
    execSegFlags: UInt64
) -> Data {
    let nCodeSlots = UInt32(pageHashes.count)
    var maxSpecial: UInt32 = 0
    for key in specialHashes.keys {
        if key > maxSpecial { maxSpecial = key }
    }
    var identBytes = Array(identifier.utf8)
    identBytes.append(0)
    var teamBytes = Array(team.utf8)
    if !team.isEmpty { teamBytes.append(0) }
    let headerSize = 88
    var offset: UInt32 = UInt32(8 + headerSize)
    let identOffset = offset
    offset += UInt32(identBytes.count)
    var teamOffset: UInt32 = 0
    if !team.isEmpty {
        teamOffset = offset
        offset += UInt32(teamBytes.count)
    }
    let specialBase = offset
    offset += UInt32(Int(maxSpecial) * hashSize)
    let hashOffset = offset
    offset += UInt32(Int(nCodeSlots) * hashSize)
    var cd = Data()
    cd.append(contentsOf: writeLE32(0x00020400, swapped: true))
    cd.append(contentsOf: writeLE32(flags, swapped: true))
    cd.append(contentsOf: writeLE32(hashOffset, swapped: true))
    cd.append(contentsOf: writeLE32(identOffset, swapped: true))
    cd.append(contentsOf: writeLE32(maxSpecial, swapped: true))
    cd.append(contentsOf: writeLE32(nCodeSlots, swapped: true))
    cd.append(contentsOf: writeLE32(UInt32(truncatingIfNeeded: codeLimit), swapped: true))
    cd.append(UInt8(hashSize))
    cd.append(hashType)
    cd.append(platform)
    cd.append(PAGE_SHIFT)
    cd.append(contentsOf: writeLE32(0, swapped: true))
    cd.append(contentsOf: writeLE32(0, swapped: true))
    cd.append(contentsOf: writeLE32(teamOffset, swapped: true))
    cd.append(contentsOf: writeLE32(0, swapped: true))
    cd.append(contentsOf: writeLE64(codeLimit, swapped: true))
    cd.append(contentsOf: writeLE64(execSegBase, swapped: true))
    cd.append(contentsOf: writeLE64(execSegLimit, swapped: true))
    cd.append(contentsOf: writeLE64(execSegFlags, swapped: true))
    cd.append(contentsOf: identBytes)
    if !team.isEmpty { cd.append(contentsOf: teamBytes) }
    var specialArray = [Data](repeating: Data(count: hashSize), count: Int(maxSpecial))
    for (slot, hash) in specialHashes {
        if slot > 0 && Int(slot) <= Int(maxSpecial) {
            specialArray[Int(maxSpecial) - Int(slot)] = hash
        }
    }
    for h in specialArray {
        cd.append(h)
    }
    for h in pageHashes {
        cd.append(h)
    }
    _ = specialBase
    return makeBlob(magic: 0xfade0c02, payload: cd)
}

func entropyBytes() -> [UInt8] {
    var bytes = [UInt8](repeating: 0, count: 16)
    for i in 0..<16 {
        bytes[i] = UInt8.random(in: 0...255)
    }
    return bytes
}

func readFile(_ path: String) -> Data {
    do {
        return try Data(contentsOf: URL(fileURLWithPath: path))
    } catch {
        fatal("ldid: \(path): \(error.localizedDescription)")
    }
}

func writeFile(_ path: String, _ data: Data) {
    do {
        try data.write(to: URL(fileURLWithPath: path))
    } catch {
        fatal("ldid: \(path): \(error.localizedDescription)")
    }
}

func fileExists(_ path: String) -> Bool {
    return FileManager.default.fileExists(atPath: path)
}

func isDirectory(_ path: String) -> Bool {
    var isDir: ObjCBool = false
    let exists = FileManager.default.fileExists(atPath: path, isDirectory: &isDir)
    return exists && isDir.boolValue
}

func readEntitlementsXML(_ path: String) -> String {
    let data = readFile(path)
    return String(data: data, encoding: .utf8) ?? ""
}

func plistFromXML(_ xml: String) -> UnsafeMutableRawPointer? {
    var node: UnsafeMutableRawPointer? = nil
    let bytes = Array(xml.utf8)
    _ = bytes.withUnsafeBufferPointer { buf in
        plist_from_xml(buf.baseAddress, UInt32(buf.count), &node)
    }
    return node
}

func plistFromData(_ data: Data) -> UnsafeMutableRawPointer? {
    var node: UnsafeMutableRawPointer? = nil
    if data.count >= 8 && data.prefix(8) == "bplist00".data(using: .ascii)! {
        _ = data.withUnsafeBytes { raw in
            plist_from_bin(raw.baseAddress?.assumingMemoryBound(to: CChar.self), UInt32(data.count), &node)
        }
    } else {
        let str = String(data: data, encoding: .utf8) ?? ""
        let bytes = Array(str.utf8)
        _ = bytes.withUnsafeBufferPointer { buf in
            plist_from_xml(buf.baseAddress, UInt32(buf.count), &node)
        }
    }
    return node
}

func plistToXMLString(_ node: UnsafeMutableRawPointer) -> String {
    var xml: UnsafeMutablePointer<CChar>? = nil
    var length: UInt32 = 0
    plist_to_xml(node, &xml, &length)
    if let xml = xml {
        let result = String(cString: xml)
        free(xml)
        return result
    }
    return ""
}

func plistDictGetItem(_ node: UnsafeMutableRawPointer, _ key: String) -> UnsafeMutableRawPointer? {
    return key.withCString { cstr in
        plist_dict_get_item(node, cstr)
    }
}

func plistGetString(_ node: UnsafeMutableRawPointer) -> String {
    var value: UnsafeMutablePointer<CChar>? = nil
    plist_get_string_val(node, &value)
    if let value = value {
        let result = String(cString: value)
        free(value)
        return result
    }
    return ""
}

func plistDictMerge(_ target: UnsafeMutableRawPointer, _ source: UnsafeMutableRawPointer) {
    var iter: UnsafeMutableRawPointer? = nil
    plist_dict_new_iter(source, &iter)
    guard let iter = iter else { return }
    defer { free(iter) }
    while true {
        var key: UnsafeMutablePointer<CChar>? = nil
        var value: UnsafeMutableRawPointer? = nil
        plist_dict_next_item(source, iter, &key, &value)
        if key == nil { break }
        if let value = value {
            let copy = plist_copy(value)
            plist_dict_set_item(target, key, copy)
        }
        free(key)
    }
}

func derEncode(_ node: UnsafeMutableRawPointer) -> Data {
    let type = plist_get_node_type(node)
    var out = Data()
    let rawType = type.rawValue
    switch rawType {
    case 0:
        var value: UInt8 = 0
        plist_get_bool_val(node, &value)
        out.append(0x01)
        out.append(0x01)
        out.append(value != 0 ? 1 : 0)
    case 1:
        var value: UInt64 = 0
        plist_get_uint_val(node, &value)
        out.append(0x02)
        let len = derLength(value)
        out.append(UInt8(len))
        var v = value
        var bytes = [UInt8]()
        if v == 0 { bytes.append(0) }
        while v > 0 {
            bytes.insert(UInt8(v & 0xff), at: 0)
            v >>= 8
        }
        out.append(contentsOf: bytes)
    case 7:
        var value: UnsafeMutablePointer<CChar>? = nil
        var length: UInt64 = 0
        plist_get_data_val(node, &value, &length)
        if let value = value {
            out.append(0x04)
            out.append(contentsOf: derLengthBytes(UInt64(length)))
            out.append(UnsafeRawPointer(value).assumingMemoryBound(to: UInt8.self), count: Int(length))
            free(value)
        }
    case 3:
        var value: UnsafeMutablePointer<CChar>? = nil
        plist_get_string_val(node, &value)
        if let value = value {
            let len = strlen(value)
            out.append(0x0c)
            out.append(contentsOf: derLengthBytes(UInt64(len)))
            out.append(UnsafeRawPointer(value).assumingMemoryBound(to: UInt8.self), count: Int(len))
            free(value)
        }
    case 4:
        let count = plist_array_get_size(node)
        var items = Data()
        for i in 0..<count {
            if let item = plist_array_get_item(node, i) {
                items.append(derEncode(item))
            }
        }
        out.append(0x30)
        out.append(contentsOf: derLengthBytes(UInt64(items.count)))
        out.append(items)
    case 5:
        var items: [Data] = []
        var iter: UnsafeMutableRawPointer? = nil
        plist_dict_new_iter(node, &iter)
        if let iter = iter {
            defer { free(iter) }
            while true {
                var key: UnsafeMutablePointer<CChar>? = nil
                var value: UnsafeMutableRawPointer? = nil
                plist_dict_next_item(node, iter, &key, &value)
                if key == nil { break }
                defer { free(key) }
                if let value = value, let keyPtr = key {
                    let keyBytes = Array(String(cString: keyPtr).utf8)
                    var pair = Data()
                    pair.append(0x0c)
                    pair.append(contentsOf: derLengthBytes(UInt64(keyBytes.count)))
                    pair.append(contentsOf: keyBytes)
                    pair.append(derEncode(value))
                    var wrapped = Data()
                    wrapped.append(0x30)
                    wrapped.append(contentsOf: derLengthBytes(UInt64(pair.count)))
                    wrapped.append(pair)
                    items.append(wrapped)
                }
            }
        }
        items.sort { a, b in a.lexicographicallyPrecedes(b) }
        var combined = Data()
        for i in items { combined.append(i) }
        out.append(0x31)
        out.append(contentsOf: derLengthBytes(UInt64(combined.count)))
        out.append(combined)
    default:
        fatal("ldid: Unsupported plist type \(rawType)")
    }
    return out
}

func derLength(_ value: UInt64) -> Int {
    if value == 0 { return 1 }
    var v = value
    var count = 0
    while v > 0 { v >>= 8; count += 1 }
    return count
}

func derLengthBytes(_ value: UInt64) -> [UInt8] {
    if value < 128 {
        return [UInt8(value)]
    }
    var v = value
    var bytes = [UInt8]()
    while v > 0 {
        bytes.insert(UInt8(v & 0xff), at: 0)
        v >>= 8
    }
    return [0x80 | UInt8(bytes.count)] + bytes
}

func derTag(_ tag: UInt8, _ payload: Data) -> Data {
    var out = Data()
    out.append(tag)
    out.append(contentsOf: derLengthBytes(UInt64(payload.count)))
    out.append(payload)
    return out
}

func derString(_ value: String) -> Data {
    return derTag(0x0c, Data(value.utf8))
}

func derSequence(_ items: [Data]) -> Data {
    var payload = Data()
    for item in items { payload.append(item) }
    return derTag(0x30, payload)
}

func derSet(_ items: [Data]) -> Data {
    var payload = Data()
    for item in items { payload.append(item) }
    return derTag(0x31, payload)
}

func derInteger(_ value: UInt64) -> Data {
    var v = value
    var bytes = [UInt8]()
    if v == 0 { bytes.append(0) }
    while v > 0 {
        bytes.insert(UInt8(v & 0xff), at: 0)
        v >>= 8
    }
    return derTag(0x02, Data(bytes))
}

func sha1Hash(_ data: Data) -> Data {
    var out = [UInt8](repeating: 0, count: 20)
    data.withUnsafeBytes { raw in
        _ = ldid_sha1(raw.baseAddress, data.count, &out)
    }
    return Data(out)
}

func sha256Hash(_ data: Data) -> Data {
    var out = [UInt8](repeating: 0, count: 32)
    data.withUnsafeBytes { raw in
        _ = ldid_sha256(raw.baseAddress, data.count, &out)
    }
    return Data(out)
}

struct SigningResult {
    var data: Data
    var hash: (sha1: Data, sha256: Data)
}

func signSingleSlice(
    sliceData: Data,
    identifier: String,
    entitlementsXML: String?,
    requirementsData: Data?,
    signer: SignerProtocol?,
    flags: UInt32,
    platform: UInt8,
    team: String,
    resourceSHA1: Data? = nil,
    resourceSHA256: Data? = nil
) -> Data {
    let slice = MachSlice(offset: 0, size: sliceData.count, cputype: 0, cpusubtype: 0, align: 3, isFat: false)
    let bits64 = isBits64(sliceData, slice: slice)
    let swapped = isSwapped(sliceData, slice: slice)
    let cmds = loadCommands(sliceData, slice: slice)
    var codeSignatureCmd: (offset: Int, dataoff: UInt32, datasize: UInt32)? = nil
    var symtabCmd: (offset: Int, stroff: UInt32, strsize: UInt32)? = nil
    var executableSegBase: UInt64 = 0
    var executableSegLimit: UInt64 = 0
    for cmd in cmds {
        if cmd.cmd == 0x1d {
            let dataoff = readLE32(sliceData, cmd.offset + 8, swapped: swapped)
            let datasize = readLE32(sliceData, cmd.offset + 12, swapped: swapped)
            codeSignatureCmd = (cmd.offset, dataoff, datasize)
        } else if cmd.cmd == 0x02 {
            let stroff = readLE32(sliceData, cmd.offset + 16, swapped: swapped)
            let strsize = readLE32(sliceData, cmd.offset + 20, swapped: swapped)
            symtabCmd = (cmd.offset, stroff, strsize)
        } else if cmd.cmd == 0x19 || cmd.cmd == 0x01 {
            var segname = [CChar](repeating: 0, count: 17)
            for i in 0..<16 {
                segname[i] = CChar(bitPattern: sliceData[cmd.offset + 8 + i])
            }
            let name = String(cString: segname)
            if cmd.cmd == 0x19 {
                let vmaddr = readLE64(sliceData, cmd.offset + 24, swapped: swapped)
                let vmsize = readLE64(sliceData, cmd.offset + 32, swapped: swapped)
                let initprot = readLE32(sliceData, cmd.offset + 56, swapped: swapped)
                if (initprot & 4) != 0 {
                    if executableSegBase == 0 || vmaddr < executableSegBase {
                        executableSegBase = vmaddr
                    }
                    if vmaddr + vmsize > executableSegLimit {
                        executableSegLimit = vmaddr + vmsize
                    }
                }
                _ = name
            } else {
                let vmaddr = UInt64(readLE32(sliceData, cmd.offset + 24, swapped: swapped))
                let vmsize = UInt64(readLE32(sliceData, cmd.offset + 28, swapped: swapped))
                let initprot = readLE32(sliceData, cmd.offset + 44, swapped: swapped)
                if (initprot & 4) != 0 {
                    if executableSegBase == 0 || vmaddr < executableSegBase {
                        executableSegBase = vmaddr
                    }
                    if vmaddr + vmsize > executableSegLimit {
                        executableSegLimit = vmaddr + vmsize
                    }
                }
            }
        }
    }
    var limit = sliceData.count
    if let cs = codeSignatureCmd {
        limit = Int(cs.dataoff)
    }
    if let st = symtabCmd {
        let end = Int(st.stroff) + Int(st.strsize)
        if end <= limit && end > 0 {
            limit = end
        }
    }
    let alignedLimit = alignInt(limit, 16)
    var pageHashesSHA1: [Data] = []
    var pageHashesSHA256: [Data] = []
    let nPages = (alignedLimit + Int(PAGE_SIZE) - 1) / Int(PAGE_SIZE)
    for i in 0..<nPages {
        let start = i * Int(PAGE_SIZE)
        let end = min(start + Int(PAGE_SIZE), alignedLimit)
        let pageData = sliceData.subdata(in: start..<end)
        pageHashesSHA1.append(sha1Hash(pageData))
        pageHashesSHA256.append(sha256Hash(pageData))
    }
    var specialHashesSHA1: [UInt32: Data] = [:]
    var specialHashesSHA256: [UInt32: Data] = [:]
    if let req = requirementsData {
        let blob = makeBlob(magic: 0xfade0c01, payload: req)
        specialHashesSHA1[2] = sha1Hash(blob)
        specialHashesSHA256[2] = sha256Hash(blob)
    }
    var entitlementsBlobData: Data? = nil
    var derEntitlementsBlobData: Data? = nil
    if let xml = entitlementsXML, !xml.isEmpty {
        if let node = plistFromXML(xml) {
            defer { plist_free(node) }
            if plist_get_node_type(node).rawValue == 5 {
                let derData = derEncode(node)
                let blob = makeBlob(magic: 0xfade7172, payload: derData)
                derEntitlementsBlobData = blob
                specialHashesSHA1[7] = sha1Hash(blob)
                specialHashesSHA256[7] = sha256Hash(blob)
            }
        }
        let payload = Data(xml.utf8)
        let blob = makeBlob(magic: 0xfade7171, payload: payload)
        entitlementsBlobData = blob
        specialHashesSHA1[5] = sha1Hash(blob)
        specialHashesSHA256[5] = sha256Hash(blob)
    }
    if let s1 = resourceSHA1 { specialHashesSHA1[3] = s1 }
    if let s2 = resourceSHA256 { specialHashesSHA256[3] = s2 }
    var execSegFlags: UInt64 = 0
    if machFileType(sliceData, slice: slice) == 0x2 {
        execSegFlags |= 0x001
    }
    if let xml = entitlementsXML, let node = plistFromXML(xml) {
        defer { plist_free(node) }
        func entitled(_ key: String) -> Bool {
            guard let item = plistDictGetItem(node, key) else { return false }
            if plist_get_node_type(item).rawValue != 0 { return false }
            var value: UInt8 = 0
            plist_get_bool_val(item, &value)
            return value != 0
        }
        if entitled("get-task-allow") { execSegFlags |= 0x010 }
        if entitled("run-unsigned-code") { execSegFlags |= 0x010 }
        if entitled("com.apple.private.cs.debugger") { execSegFlags |= 0x020 }
        if entitled("dynamic-codesigning") { execSegFlags |= 0x040 }
        if entitled("com.apple.private.skip-library-validation") { execSegFlags |= 0x080 }
        if entitled("com.apple.private.amfi.can-load-cdhash") { execSegFlags |= 0x100 }
        if entitled("com.apple.private.amfi.can-execute-cdhash") { execSegFlags |= 0x100 }
    }
    let cdSHA1 = buildCodeDirectory(
        identifier: identifier,
        team: team,
        codeLimit: UInt64(alignedLimit),
        pageHashes: pageHashesSHA1,
        specialHashes: specialHashesSHA1,
        hashType: 1,
        hashSize: 20,
        flags: flags,
        platform: platform,
        execSegBase: executableSegBase,
        execSegLimit: executableSegLimit - executableSegBase,
        execSegFlags: execSegFlags
    )
    let cdSHA256 = buildCodeDirectory(
        identifier: identifier,
        team: team,
        codeLimit: UInt64(alignedLimit),
        pageHashes: pageHashesSHA256,
        specialHashes: specialHashesSHA256,
        hashType: 2,
        hashSize: 32,
        flags: flags,
        platform: platform,
        execSegBase: executableSegBase,
        execSegLimit: executableSegLimit - executableSegBase,
        execSegFlags: execSegFlags
    )
    var blobs: [SignatureBlob] = []
    if let req = requirementsData {
        let blob = makeBlob(magic: 0xfade0c01, payload: req)
        blobs.append(SignatureBlob(slot: 2, data: blob))
    }
    if let ent = entitlementsBlobData {
        blobs.append(SignatureBlob(slot: 5, data: ent))
    }
    if let der = derEntitlementsBlobData {
        blobs.append(SignatureBlob(slot: 7, data: der))
    }
    blobs.append(SignatureBlob(slot: 0, data: cdSHA1))
    blobs.append(SignatureBlob(slot: 0x1000, data: cdSHA256))
    if let signer = signer {
        let signedBlob = signer.sign(payload: cdSHA256)
        if let signedBlob = signedBlob {
            let wrapped = makeBlob(magic: 0xfade0b01, payload: signedBlob)
            blobs.append(SignatureBlob(slot: 0x10000, data: wrapped))
        }
    }
    let superBlob = buildSuperBlob(magic: 0xfade0cc0, blobs: blobs)
    let headerSize = bits64 ? 32 : 28
    let header = Data(sliceData.prefix(headerSize))
    var newCmds = Data()
    var newNcmds: UInt32 = 0
    var newSizeofcmds: UInt32 = 0
    var signatureCmdOffsetInNew = 0
    for cmd in cmds {
        if cmd.cmd == 0x1d { continue }
        if cmd.cmd == 0x19 || cmd.cmd == 0x01 {
            var c = Data(sliceData.subdata(in: cmd.offset..<cmd.offset+Int(cmd.cmdsize)))
            var segname = [CChar](repeating: 0, count: 17)
            for i in 0..<16 { segname[i] = CChar(bitPattern: c[8 + i]) }
            let name = String(cString: segname)
            if name == "LINKEDIT" {
                let newFileoff = UInt32(alignedLimit)
                let newFilesize = UInt32(superBlob.count)
                if cmd.cmd == 0x19 {
                    let v = UInt64(align(UInt64(newFilesize), UInt64(1) << slice.align))
                    c.replaceSubrange(32..<40, with: writeLE64(UInt64(newFilesize), swapped: swapped))
                    c.replaceSubrange(40..<48, with: writeLE64(v, swapped: swapped))
                    c.replaceSubrange(48..<56, with: writeLE64(UInt64(newFileoff), swapped: swapped))
                } else {
                    c.replaceSubrange(28..<32, with: writeLE32(newFilesize, swapped: swapped))
                    c.replaceSubrange(32..<36, with: writeLE32(newFilesize, swapped: swapped))
                    c.replaceSubrange(36..<40, with: writeLE32(newFileoff, swapped: swapped))
                }
            }
            newCmds.append(c)
            newNcmds += 1
            newSizeofcmds += UInt32(c.count)
        } else {
            let c = Data(sliceData.subdata(in: cmd.offset..<cmd.offset+Int(cmd.cmdsize)))
            newCmds.append(c)
            newNcmds += 1
            newSizeofcmds += UInt32(c.count)
        }
    }
    signatureCmdOffsetInNew = newCmds.count
    var sigCmd = Data()
    sigCmd.append(contentsOf: writeLE32(0x1d, swapped: swapped))
    sigCmd.append(contentsOf: writeLE32(16, swapped: swapped))
    sigCmd.append(contentsOf: writeLE32(UInt32(alignedLimit), swapped: swapped))
    sigCmd.append(contentsOf: writeLE32(UInt32(superBlob.count), swapped: swapped))
    newCmds.append(sigCmd)
    newNcmds += 1
    newSizeofcmds += 16
    var newHeader = Data(sliceData.prefix(headerSize))
    if bits64 {
        newHeader.replaceSubrange(16..<20, with: writeLE32(newNcmds, swapped: swapped))
        newHeader.replaceSubrange(20..<24, with: writeLE32(newSizeofcmds, swapped: swapped))
    } else {
        newHeader.replaceSubrange(16..<20, with: writeLE32(newNcmds, swapped: swapped))
        newHeader.replaceSubrange(20..<24, with: writeLE32(newSizeofcmds, swapped: swapped))
    }
    _ = header
    _ = signatureCmdOffsetInNew
    var result = Data()
    result.append(newHeader)
    result.append(newCmds)
    let currentSize = result.count
    let originalSizeofcmds = Int(readLE32(sliceData, 20, swapped: swapped))
    let originalHeaderSize = bits64 ? 32 : 28
    let originalCmdsEnd = originalHeaderSize + originalSizeofcmds
    if currentSize < originalCmdsEnd {
        result.append(Data(count: originalCmdsEnd - currentSize))
    }
    let copyStart = result.count
    let copyEnd = alignedLimit
    if copyEnd > copyStart {
        result.append(sliceData.subdata(in: copyStart..<copyEnd))
    }
    while result.count < alignedLimit {
        result.append(0)
    }
    result.append(superBlob)
    return result
}

struct SignOptions {
    var identifier: String? = nil
    var entitlementsPath: String? = nil
    var requirementsPath: String? = nil
    var keyPath: String? = nil
    var certPaths: [String] = []
    var password: String = ""
    var flags: UInt32 = 0
    var platform: UInt8 = 0
    var merge: Bool = false
    var shallow: Bool = false
    var teamID: String? = nil
    var cpuType: UInt32? = nil
    var cpuSubtype: UInt32? = nil
    var adhoc: Bool = false
    var trueSign: Bool = false
}

protocol SignerProtocol {
    func sign(payload: Data) -> Data?
    func teamID() -> String
    var trueSign: Bool { get set }
}

final class NoSigner: SignerProtocol {
    func sign(payload: Data) -> Data? { return nil }
    func teamID() -> String { return "" }
    var trueSign: Bool = false
}

func signFile(path: String, options: SignOptions, signer: SignerProtocol, resourceSHA1: Data? = nil, resourceSHA256: Data? = nil) {
    let original = readFile(path)
    let machFile = parseMachFile(original)
    var entitlementsXML: String? = nil
    if let entPath = options.entitlementsPath {
        entitlementsXML = readEntitlementsXML(entPath)
    }
    var requirementsData: Data? = nil
    if let reqPath = options.requirementsPath {
        requirementsData = readFile(reqPath)
    }
    if machFile.isFat {
        var newSlices: [Data] = []
        for slice in machFile.slices {
            let sliceData = original.subdata(in: slice.offset..<(slice.offset + slice.size))
            let identifier = options.identifier ?? ((path as NSString).lastPathComponent)
            let newData = signSingleSlice(
                sliceData: sliceData,
                identifier: identifier,
                entitlementsXML: entitlementsXML,
                requirementsData: requirementsData,
                signer: signer,
                flags: options.flags,
                platform: options.platform,
                team: signer.teamID(),
                resourceSHA1: resourceSHA1,
                resourceSHA256: resourceSHA256
            )
            newSlices.append(newData)
        }
        var out = Data()
        var fatHeader = Data()
        fatHeader.append(contentsOf: writeLE32(0xcafebabe, swapped: true))
        fatHeader.append(contentsOf: writeLE32(UInt32(newSlices.count), swapped: true))
        var offset = UInt32(8 + newSlices.count * 20)
        var archData = Data()
        for (i, slice) in machFile.slices.enumerated() {
            let aligned = align(UInt64(offset), UInt64(1) << slice.align)
            archData.append(contentsOf: writeLE32(slice.cputype, swapped: true))
            archData.append(contentsOf: writeLE32(slice.cpusubtype, swapped: true))
            archData.append(contentsOf: writeLE32(UInt32(aligned), swapped: true))
            archData.append(contentsOf: writeLE32(UInt32(newSlices[i].count), swapped: true))
            archData.append(contentsOf: writeLE32(slice.align, swapped: true))
            offset = UInt32(aligned) + UInt32(newSlices[i].count)
        }
        out.append(fatHeader)
        out.append(archData)
        var cursor = UInt32(8 + newSlices.count * 20)
        for (i, slice) in machFile.slices.enumerated() {
            let aligned = align(UInt64(cursor), UInt64(1) << slice.align)
            if aligned > UInt64(cursor) {
                out.append(Data(count: Int(aligned) - Int(cursor)))
            }
            out.append(newSlices[i])
            cursor = UInt32(aligned) + UInt32(newSlices[i].count)
        }
        writeFile(path, out)
    } else {
        let identifier = options.identifier ?? ((path as NSString).lastPathComponent)
        let newData = signSingleSlice(
            sliceData: original,
            identifier: identifier,
            entitlementsXML: entitlementsXML,
            requirementsData: requirementsData,
            signer: signer,
            flags: options.flags,
            platform: options.platform,
            team: signer.teamID(),
            resourceSHA1: resourceSHA1,
            resourceSHA256: resourceSHA256
        )
        writeFile(path, newData)
    }
}

func printUsage(_ argv0: String) {
    let usage = """
Link Identity Editor \(LDID_VERSION)
Usage: \(argv0) [-Acputype:subtype] [-a] [-C[adhoc | enforcement | expires | hard |
host | kill | library-validation | restrict | runtime | linker-signed]] [-D] [-d]
[-Enum:file] [-e] [-H[sha1 | sha256]] [-h] [-Iname]
[-Kkey.p12 [-Upassword]] [-M] [-P[num]] [-Qrequirements.xml] [-q]
[-r | -Sfile.xml | -s] [-w] [-u] [-tTeamID] [-arch arch_type] [--true-sign] file ...
Common Options:
-S[file.xml]  Pseudo-sign using the entitlements in file.xml
-w            Shallow sign
-Kkey.p12     Sign using private key in key.p12
-Upassword    Use password to unlock key.p12
-M            Merge entitlements with any existing
-h            Print CDHash of file
--true-sign   Enable codesign -compatible true signing
More information: 'man ldid'
"""
    FileHandle.standardError.write(usage.data(using: .utf8)!)
}

func printCDHash(_ path: String) {
    let data = readFile(path)
    let machFile = parseMachFile(data)
    for slice in machFile.slices {
        let sliceData = data.subdata(in: slice.offset..<(slice.offset + slice.size))
        let cmds = loadCommands(sliceData, slice: MachSlice(offset: 0, size: sliceData.count, cputype: 0, cpusubtype: 0, align: 3, isFat: false))
        var sigOffset: Int? = nil
        for cmd in cmds {
            if cmd.cmd == 0x1d {
                let swapped = isSwapped(sliceData, slice: MachSlice(offset: 0, size: sliceData.count, cputype: 0, cpusubtype: 0, align: 3, isFat: false))
                sigOffset = Int(readLE32(sliceData, cmd.offset + 8, swapped: swapped))
            }
        }
        guard let sigOff = sigOffset else {
            warn("ldid: \(path): not signed")
            continue
        }
        if sigOff + 12 > sliceData.count { continue }
        let magic = readUInt32LE(sliceData, sigOff)
        if magic != 0xfade0cc0 { continue }
        let count = readUInt32LE(sliceData, sigOff + 8)
        var bestSHA1: Data? = nil
        var bestSHA256: Data? = nil
        var identifier = ""
        var flags: UInt32 = 0
        var team = "not set"
        for i in 0..<Int(count) {
            let idxOff = sigOff + 12 + i * 8
            let _ = readUInt32LE(sliceData, idxOff)
            let offset = readUInt32LE(sliceData, idxOff + 4)
            let blobOff = sigOff + Int(offset)
            if blobOff + 8 > sliceData.count { continue }
            let blobMagic = readUInt32LE(sliceData, blobOff)
            if blobMagic != 0xfade0c02 { continue }
            let blobLen = readUInt32LE(sliceData, blobOff + 4)
            let blob = sliceData.subdata(in: blobOff..<(blobOff + Int(blobLen)))
            let version = readUInt32LE(blob, 8)
            flags = readUInt32LE(blob, 12)
            let identOffset = readUInt32LE(blob, 20)
            let teamIDOffset = readUInt32LE(blob, 48)
            let hashType = blob[36]
            let hashSize = blob[35]
            let hashOffset = readUInt32LE(blob, 16)
            if identOffset > 0 && Int(identOffset) < blob.count {
                identifier = String(cString: blob.subdata(in: Int(identOffset)..<blob.count).map { Int8(bitPattern: $0) } + [0])
            }
            if hashType == 1 {
                bestSHA1 = sha1Hash(blob)
            } else if hashType == 2 {
                bestSHA256 = sha256Hash(blob)
            }
            if teamIDOffset > 0 && Int(teamIDOffset) < blob.count {
                team = String(cString: blob.subdata(in: Int(teamIDOffset)..<blob.count).map { Int8(bitPattern: $0) } + [0])
            }
            _ = version
            _ = hashOffset
            _ = hashSize
        }
        var buf = [CChar](repeating: 0, count: 4096)
        realpath(path, &buf)
        print("Executable=\(String(cString: buf))")
        print("Identifier=\(identifier)")
        var names: [String] = []
        if (flags & 0x0001) != 0 { names.append("host") }
        if (flags & 0x0002) != 0 { names.append("adhoc") }
        if (flags & 0x0100) != 0 { names.append("hard") }
        if (flags & 0x0200) != 0 { names.append("kill") }
        if (flags & 0x0400) != 0 { names.append("expires") }
        if (flags & 0x0800) != 0 { names.append("restrict") }
        if (flags & 0x1000) != 0 { names.append("enforcement") }
        if (flags & 0x2000) != 0 { names.append("library-validation") }
        if (flags & 0x10000) != 0 { names.append("runtime") }
        if (flags & 0x20000) != 0 { names.append("linker-signed") }
        print("CodeDirectory flags=0x\(String(flags, radix: 16))(\(names.isEmpty ? "none" : names.joined(separator: ", ")))")
        if let h = bestSHA1 {
            print("CDHash=\(h.map { String(format: "%02x", $0) }.joined())")
        }
        if let h = bestSHA256 {
            print("CDHash(SHA256)=\(h.map { String(format: "%02x", $0) }.joined())")
        }
        print("TeamIdentifier=\(team)")
    }
}

func printEntitlements(_ path: String) {
    let data = readFile(path)
    let machFile = parseMachFile(data)
    for slice in machFile.slices {
        let sliceData = data.subdata(in: slice.offset..<(slice.offset + slice.size))
        let s = MachSlice(offset: 0, size: sliceData.count, cputype: 0, cpusubtype: 0, align: 3, isFat: false)
        let swapped = isSwapped(sliceData, slice: s)
        let cmds = loadCommands(sliceData, slice: s)
        var sigOff: Int? = nil
        for cmd in cmds {
            if cmd.cmd == 0x1d {
                sigOff = Int(readLE32(sliceData, cmd.offset + 8, swapped: swapped))
            }
        }
        guard let sigOff = sigOff else { continue }
        let count = readUInt32LE(sliceData, sigOff + 8)
        for i in 0..<Int(count) {
            let idxOff = sigOff + 12 + i * 8
            let slot = readUInt32LE(sliceData, idxOff)
            let offset = readUInt32LE(sliceData, idxOff + 4)
            if slot == 5 || slot == 7 {
                let blobOff = sigOff + Int(offset)
                let blobLen = readUInt32LE(sliceData, blobOff + 4)
                let payload = sliceData.subdata(in: (blobOff + 8)..<(blobOff + Int(blobLen)))
                FileHandle.standardOutput.write(payload)
            }
        }
    }
}

func printRequirements(_ path: String) {
    let data = readFile(path)
    let machFile = parseMachFile(data)
    for slice in machFile.slices {
        let sliceData = data.subdata(in: slice.offset..<(slice.offset + slice.size))
        let s = MachSlice(offset: 0, size: sliceData.count, cputype: 0, cpusubtype: 0, align: 3, isFat: false)
        let swapped = isSwapped(sliceData, slice: s)
        let cmds = loadCommands(sliceData, slice: s)
        var sigOff: Int? = nil
        for cmd in cmds {
            if cmd.cmd == 0x1d {
                sigOff = Int(readLE32(sliceData, cmd.offset + 8, swapped: swapped))
            }
        }
        guard let sigOff = sigOff else { continue }
        let count = readUInt32LE(sliceData, sigOff + 8)
        for i in 0..<Int(count) {
            let idxOff = sigOff + 12 + i * 8
            let slot = readUInt32LE(sliceData, idxOff)
            let offset = readUInt32LE(sliceData, idxOff + 4)
            if slot == 2 {
                let blobOff = sigOff + Int(offset)
                let blobLen = readUInt32LE(sliceData, blobOff + 4)
                let payload = sliceData.subdata(in: blobOff..<(blobOff + Int(blobLen)))
                FileHandle.standardOutput.write(payload)
            }
        }
    }
}

func unsign(_ path: String) {
    let original = readFile(path)
    let machFile = parseMachFile(original)
    if machFile.isFat {
        var newSlices: [Data] = []
        for slice in machFile.slices {
            let sliceData = original.subdata(in: slice.offset..<(slice.offset + slice.size))
            let stripped = stripSignatureFromSlice(sliceData)
            newSlices.append(stripped)
        }
        var out = Data()
        var fatHeader = Data()
        fatHeader.append(contentsOf: writeLE32(0xcafebabe, swapped: true))
        fatHeader.append(contentsOf: writeLE32(UInt32(newSlices.count), swapped: true))
        var offset = UInt32(8 + newSlices.count * 20)
        var archData = Data()
        for (i, slice) in machFile.slices.enumerated() {
            let aligned = align(UInt64(offset), UInt64(1) << slice.align)
            archData.append(contentsOf: writeLE32(slice.cputype, swapped: true))
            archData.append(contentsOf: writeLE32(slice.cpusubtype, swapped: true))
            archData.append(contentsOf: writeLE32(UInt32(aligned), swapped: true))
            archData.append(contentsOf: writeLE32(UInt32(newSlices[i].count), swapped: true))
            archData.append(contentsOf: writeLE32(slice.align, swapped: true))
            offset = UInt32(aligned) + UInt32(newSlices[i].count)
        }
        out.append(fatHeader)
        out.append(archData)
        var cursor = UInt32(8 + newSlices.count * 20)
        for (i, slice) in machFile.slices.enumerated() {
            let aligned = align(UInt64(cursor), UInt64(1) << slice.align)
            if aligned > UInt64(cursor) {
                out.append(Data(count: Int(aligned) - Int(cursor)))
            }
            out.append(newSlices[i])
            cursor = UInt32(aligned) + UInt32(newSlices[i].count)
        }
        writeFile(path, out)
    } else {
        let stripped = stripSignatureFromSlice(original)
        writeFile(path, stripped)
    }
}

func stripSignatureFromSlice(_ sliceData: Data) -> Data {
    let slice = MachSlice(offset: 0, size: sliceData.count, cputype: 0, cpusubtype: 0, align: 3, isFat: false)
    let swapped = isSwapped(sliceData, slice: slice)
    let bits64 = isBits64(sliceData, slice: slice)
    let cmds = loadCommands(sliceData, slice: slice)
    let headerSize = bits64 ? 32 : 28
    var newCmds = Data()
    var ncmds: UInt32 = 0
    var sizeofcmds: UInt32 = 0
    var sigOffset: UInt32? = nil
    var sigSize: UInt32 = 0
    for cmd in cmds {
        if cmd.cmd == 0x1d {
            sigOffset = readLE32(sliceData, cmd.offset + 8, swapped: swapped)
            sigSize = readLE32(sliceData, cmd.offset + 12, swapped: swapped)
            continue
        }
        newCmds.append(sliceData.subdata(in: cmd.offset..<cmd.offset+Int(cmd.cmdsize)))
        ncmds += 1
        sizeofcmds += cmd.cmdsize
    }
    var newHeader = Data(sliceData.prefix(headerSize))
    newHeader.replaceSubrange(16..<20, with: writeLE32(ncmds, swapped: swapped))
    newHeader.replaceSubrange(20..<24, with: writeLE32(sizeofcmds, swapped: swapped))
    var result = Data()
    result.append(newHeader)
    result.append(newCmds)
    let originalHeaderSize = bits64 ? 32 : 28
    let originalCmdsEnd = originalHeaderSize + Int(readLE32(sliceData, 20, swapped: swapped))
    if result.count < originalCmdsEnd {
        result.append(Data(count: originalCmdsEnd - result.count))
    }
    let end = sigOffset.map { Int($0) } ?? sliceData.count
    if end > result.count {
        result.append(sliceData.subdata(in: result.count..<end))
    }
    _ = sigSize
    return result
}

func generateCodeResources(_ bundlePath: String) -> String {
    let fm = FileManager.default
    let enumerator = fm.enumerator(atPath: bundlePath)
    var filesDict: [String: Any] = [:]
    var files2Dict: [String: Any] = [:]
    let rules: [String : Any] = [
        "^.*": true,
        "^.*\\.lproj/": ["optional": true, "weight": 1000],
        "^.*\\.lproj/locversion.plist$": ["omit": true, "weight": 1050],
        "^Base\\.lproj/": ["weight": 1010],
        "^version\\.plist$": true,
        "^embedded\\.provisionprofile$": true,
        "^Info\\.plist$": ["omit": true, "weight": 10],
        "^PkgInfo$": true,
        "^CodeResources$": ["omit": true]
    ]
    while let path = enumerator?.nextObject() as? String {
        if path == "_CodeResources" || path.hasPrefix(".") { continue }
        let fullPath = (bundlePath as NSString).appendingPathComponent(path)
        var isDir: ObjCBool = false
        if fm.fileExists(atPath: fullPath, isDirectory: &isDir) && isDir.boolValue { continue }
        guard let data = try? Data(contentsOf: URL(fileURLWithPath: fullPath)) else { continue }
        let sha1 = sha1Hash(data)
        let sha256 = sha256Hash(data)
        filesDict[path] = sha1
        files2Dict[path] = ["hash2": sha256]
    }
    let plist: [String: Any] = [
        "files": filesDict,
        "files2": files2Dict,
        "rules": rules,
        "rules2": rules
    ]
    guard let xmlData = try? PropertyListSerialization.data(fromPropertyList: plist, format: .xml, options: 0) else {
        return ""
    }
    return String(data: xmlData, encoding: .utf8) ?? ""
}

var flagW = false
var flagU = false
var flagH = false
var flagR = false
var flagE = false
var flagQ = false
var flagS = false
var flagSSmall = false
var flagD = false
var flagDSmall = false
var flagA = false
var flagASmall = false
var flagUSmall = false
var flagM = false
var flagTrueSign = false
var flagT: String? = nil
var flagI: String? = nil
var flagCPUType: UInt32? = nil
var flagCPUSubtype: UInt32? = nil
var flagPlatform: UInt8 = 0
var flagFlags: UInt32 = 0
var password = ""

func main() {
    _ = ldid_load_default_provider()
    _ = ldid_load_legacy_provider()
    let args = CommandLine.arguments
    if args.count == 1 {
        printUsage(args[0])
        exit(0)
    }
    var files: [String] = []
    var entitlementsPath: String? = nil
    var requirementsPath: String? = nil
    var keyPath: String? = nil
    var certPaths: [String] = []
    var i = 1
    while i < args.count {
        let arg = args[i]
        if arg.hasPrefix("-") == false {
            files.append(arg)
            i += 1
            continue
        }
        if arg == "--true-sign" {
            flagTrueSign = true
            i += 1
            continue
        }
        let c = arg[arg.index(arg.startIndex, offsetBy: 1)]
        switch c {
        case "r":
            flagR = true
        case "e":
            flagE = true
        case "q":
            flagQ = true
        case "h":
            flagH = true
        case "w":
            flagW = true
        case "M":
            flagM = true
        case "D":
            flagD = true
        case "d":
            flagDSmall = true
        case "a":
            flagASmall = true
        case "u":
            flagUSmall = true
        case "U":
            flagU = true
            if arg.count > 2 {
                password = String(arg.dropFirst(2))
            }
        case "K":
            if arg.count > 2 {
                keyPath = String(arg.dropFirst(2))
            }
        case "X":
            if arg.count > 2 {
                certPaths.append(String(arg.dropFirst(2)))
            }
        case "S":
            flagS = true
            if arg.count > 2 {
                entitlementsPath = String(arg.dropFirst(2))
            }
        case "s":
            flagSSmall = true
            flagM = true
        case "Q":
            if arg.count > 2 {
                requirementsPath = String(arg.dropFirst(2))
            }
        case "I":
            if arg.count > 2 {
                flagI = String(arg.dropFirst(2))
            }
        case "t":
            if arg.count > 2 {
                flagT = String(arg.dropFirst(2))
            }
        case "P":
            if arg.count > 2 {
                flagPlatform = UInt8(String(arg.dropFirst(2))) ?? 0
            } else {
                flagPlatform = 13
            }
        case "H":
            flagH = true
        case "A":
            flagA = true
            if arg.count > 2 {
                let parts = String(arg.dropFirst(2)).split(separator: ":")
                if parts.count == 2 {
                    flagCPUType = UInt32(parts[0], radix: 16) ?? UInt32(parts[0])
                    flagCPUSubtype = UInt32(parts[1], radix: 16) ?? UInt32(parts[1])
                }
            }
        case "C":
            if arg.count > 2 {
                let names = String(arg.dropFirst(2)).split(separator: ",")
                for n in names {
                    switch n {
                    case "host": flagFlags |= 0x0001
                    case "adhoc": flagFlags |= 0x0002
                    case "hard": flagFlags |= 0x0100
                    case "kill": flagFlags |= 0x0200
                    case "expires": flagFlags |= 0x0400
                    case "restrict": flagFlags |= 0x0800
                    case "enforcement": flagFlags |= 0x1000
                    case "library-validation": flagFlags |= 0x2000
                    case "runtime": flagFlags |= 0x10000
                    case "linker-signed": flagFlags |= 0x20000
                    default: fatal("ldid: -C: Unsupported option")
                    }
                }
            }
        case "-":
            if arg == "-arch" {
                i += 1
                if i >= args.count {
                    fatal("ldid: -arch must be followed by an architecture string")
                }
                let name = args[i]
                var found = false
                for entry in archTable {
                    if entry.name == name {
                        flagA = true
                        flagCPUType = entry.cputype
                        flagCPUSubtype = entry.cpusubtype
                        found = true
                        break
                    }
                }
                if !found {
                    fatal("error: unknown architecture specification flag: -arch \(name)")
                }
            }
        default:
            printUsage(args[0])
            exit(1)
        }
        i += 1
    }
    if flagI != nil && !flagS {
        fatal("ldid: -I requires -S")
    }
    if files.isEmpty { return }
    var signer: SignerProtocol = NoSigner()
    signer.trueSign = flagTrueSign
    if let kp = keyPath {
        signer = createSigner(keyPath: kp, certPaths: certPaths, password: password)
        signer.trueSign = flagTrueSign
    }
    for file in files {
        if isDirectory(file) {
            let codeResourcesXML = generateCodeResources(file)
            let codeResourcesPath = (file as NSString).appendingPathComponent("_CodeResources")
            do {
                try codeResourcesXML.write(toFile: codeResourcesPath, atomically: true, encoding: .utf8)
            } catch {
                fatal("ldid: Failed to write _CodeResources: \(error.localizedDescription)")
            }
            let infoPlistPath = (file as NSString).appendingPathComponent("Info.plist")
            if let infoData = try? Data(contentsOf: URL(fileURLWithPath: infoPlistPath)),
               let infoPlist = try? PropertyListSerialization.propertyList(from: infoData, options: [], format: nil) as? [String: Any],
               let execName = infoPlist["CFBundleExecutable"] as? String {
                let execPath = (file as NSString).appendingPathComponent(execName)
                var opts = SignOptions()
                opts.identifier = flagI ?? execName
                opts.entitlementsPath = entitlementsPath
                opts.requirementsPath = requirementsPath
                opts.flags = flagFlags
                opts.platform = flagPlatform
                opts.merge = flagM
                opts.teamID = flagT
                opts.trueSign = flagTrueSign
                let crData = readFile(codeResourcesPath)
                let crSHA1 = sha1Hash(crData)
                let crSHA256 = sha256Hash(crData)
                signFile(path: execPath, options: opts, signer: signer, resourceSHA1: crSHA1, resourceSHA256: crSHA256)
            } else {
                fatal("ldid: Cannot find Info.plist or CFBundleExecutable in \(file)")
            }
        } else {
            if flagS || flagR || flagSSmall {
                if flagR {
                    unsign(file)
                } else {
                    var opts = SignOptions()
                    opts.identifier = flagI ?? (file as NSString).lastPathComponent
                    opts.entitlementsPath = entitlementsPath
                    opts.requirementsPath = requirementsPath
                    opts.flags = flagFlags
                    opts.platform = flagPlatform
                    opts.merge = flagM
                    opts.teamID = flagT
                    opts.trueSign = flagTrueSign
                    signFile(path: file, options: opts, signer: signer)
                }
            }
        }
        if flagH {
            printCDHash(file)
        }
        if flagE {
            printEntitlements(file)
        }
        if flagQ {
            printRequirements(file)
        }
        if flagDSmall {
            let data = readFile(file)
            let machFile = parseMachFile(data)
            for slice in machFile.slices {
                let sliceData = data.subdata(in: slice.offset..<(slice.offset + slice.size))
                let s = MachSlice(offset: 0, size: sliceData.count, cputype: 0, cpusubtype: 0, align: 3, isFat: false)
                let swapped = isSwapped(sliceData, slice: s)
                let cmds = loadCommands(sliceData, slice: s)
                for cmd in cmds {
                    if cmd.cmd == 0x21 || cmd.cmd == 0x2c {
                        let cryptid = readLE32(sliceData, cmd.offset + 16, swapped: swapped)
                        print("cryptid=\(cryptid)")
                    }
                }
            }
        }
        if flagUSmall {
            let data = readFile(file)
            let machFile = parseMachFile(data)
            for slice in machFile.slices {
                let sliceData = data.subdata(in: slice.offset..<(slice.offset + slice.size))
                let s = MachSlice(offset: 0, size: sliceData.count, cputype: 0, cpusubtype: 0, align: 3, isFat: false)
                let swapped = isSwapped(sliceData, slice: s)
                let cmds = loadCommands(sliceData, slice: s)
                for cmd in cmds {
                    if cmd.cmd == 0x0c {
                        let nameOff = readLE32(sliceData, cmd.offset + 8, swapped: swapped)
                        let nameOffAbs = cmd.offset + Int(nameOff)
                        if nameOffAbs < sliceData.count {
                            let nameBytes = sliceData.subdata(in: nameOffAbs..<sliceData.count)
                            let name = String(cString: nameBytes.map { Int8(bitPattern: $0) } + [0])
                            if name == "/System/Library/Frameworks/UIKit.framework/UIKit" {
                                let currentVersion = readLE32(sliceData, cmd.offset + 12, swapped: swapped)
                                let major = (currentVersion >> 16) & 0xffff
                                let minor = (currentVersion >> 8) & 0xff
                                let patch = currentVersion & 0xff
                                print("uikit=\(major).\(minor).\(patch)")
                            }
                        }
                    }
                }
            }
        }
    }
}

func createSigner(keyPath: String, certPaths: [String], password: String) -> SignerProtocol {
    if keyPath.hasPrefix("pkcs11:") {
        return NoSigner()
    }
    return P12Signer(keyPath: keyPath, certPaths: certPaths, password: password)
}

final class P12Signer: SignerProtocol {
    private var pkey: OpaquePointer? = nil
    private var cert: OpaquePointer? = nil
    private var caCerts: OpaquePointer? = nil
    private var team: String = ""
    var trueSign: Bool = false
    
    init(keyPath: String, certPaths: [String], password: String) {
        let data = readFile(keyPath)
        guard let bio = BIO_new_mem_buf((data as NSData).bytes, Int32(data.count)) else {
            fatal("ldid: Failed to create BIO")
        }
        defer { BIO_free(bio) }
        guard let p12 = d2i_PKCS12_bio(bio, nil) else {
            fatal("ldid: An error occurred while getting the PKCS12 file")
        }
        var pkey: OpaquePointer? = nil
        var cert: OpaquePointer? = nil
        var ca: OpaquePointer? = nil
        let passCStr = password.cString(using: .utf8) ?? []
        let result = PKCS12_parse(p12, passCStr, &pkey, &cert, &ca)
        PKCS12_free(p12)
        guard result == 1 else {
            fatal("ldid: An error occurred while parsing PKCS12")
        }
        self.pkey = pkey
        self.cert = cert
        self.caCerts = ca
        if let cert = cert {
            var name: OpaquePointer? = nil
            X509_get_subject_name(cert)
            name = X509_get_subject_name(cert)
            if let name = name {
                let index = X509_NAME_get_index_by_NID(name, NID_organizationalUnitName, -1)
                if index >= 0 {
                    let entry = X509_NAME_get_entry(name, index)
                    if let entry = entry {
                        let str = X509_NAME_ENTRY_get_data(entry)
                        if let str = str {
                            if let data = ASN1_STRING_get0_data(str) {
                                team = String(cString: data)
                            }
                        }
                    }
                }
            }
        }
    }
    
    func teamID() -> String { return team }
    
    func sign(payload: Data) -> Data? {
        guard let pkey = pkey, let cert = cert else { return nil }
        guard let pkcs7 = PKCS7_new() else { return nil }
        defer { PKCS7_free(pkcs7) }
        PKCS7_set_type(pkcs7, NID_pkcs7_signed)
        PKCS7_content_new(pkcs7, NID_pkcs7_data)
        if let ca = caCerts {
            let count = Int(ldid_OPENSSL_sk_num(UnsafeMutableRawPointer(ca)))
            if count > 0 {
                PKCS7_add_certificate(pkcs7, cert)
                for i in 0..<count {
                    let val = ldid_OPENSSL_sk_value(UnsafeMutableRawPointer(ca), Int32(i))
                    if val != nil {
                        let c = OpaquePointer(val!)
                        PKCS7_add_certificate(pkcs7, c)
                    }
                }
            } else {
                PKCS7_add_certificate(pkcs7, cert)
            }
        } else {
            PKCS7_add_certificate(pkcs7, cert)
        }
        guard let info = PKCS7_sign_add_signer(pkcs7, cert, pkey, EVP_sha256(), PKCS7_NOSMIMECAP) else {
            return nil
        }
        let sha1 = sha1Hash(payload)
        let sha256 = sha256Hash(payload)
        if trueSign {
            let xmlPlist = """
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
<key>cdhashes</key>
<array>
<data>
\(sha1.base64EncodedString())
</data>
<data>
\(sha256.base64EncodedString())
</data>
</array>
<key>cdhashes2</key>
<array>
<data>
\(sha256.base64EncodedString())
</data>
</array>
</dict>
</plist>
"""
            let attr1 = xmlPlist.withCString { cstr -> OpaquePointer? in
                ldid_create_cdhashes1_attr(cstr, Int32(xmlPlist.utf8.count))
            }
            if let a = attr1 {
                if info.pointee.auth_attr == nil {
                    info.pointee.auth_attr = OpaquePointer(ldid_OPENSSL_sk_new_null())
                }
                _ = ldid_OPENSSL_sk_push(UnsafeMutableRawPointer(info.pointee.auth_attr), UnsafeMutableRawPointer(a))
            }
            let attr2 = sha1.withUnsafeBytes { s1 -> OpaquePointer? in
                sha256.withUnsafeBytes { s2 -> OpaquePointer? in
                    ldid_create_cdhashes2_attr(s1.baseAddress?.assumingMemoryBound(to: UInt8.self), s2.baseAddress?.assumingMemoryBound(to: UInt8.self))
                }
            }
            if let a = attr2 {
                if info.pointee.auth_attr == nil {
                    info.pointee.auth_attr = OpaquePointer(ldid_OPENSSL_sk_new_null())
                }
                _ = ldid_OPENSSL_sk_push(UnsafeMutableRawPointer(info.pointee.auth_attr), UnsafeMutableRawPointer(a))
            }
        } else {
            let xmlPlist = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<!DOCTYPE plist PUBLIC \"-//Apple//DTD PLIST 1.0//EN\" \"http://www.apple.com/DTDs/PropertyList-1.0.dtd\">\n<plist version=\"1.0\">\n<dict>\n\t<key>cdhashes</key>\n\t<array>\n\t\t<data>\n\t\t\(sha1.base64EncodedString())\n\t\t</data>\n\t</array>\n</dict>\n</plist>\n"
            let attr1 = xmlPlist.withCString { cstr -> OpaquePointer? in
                ldid_create_cdhashes1_attr(cstr, Int32(xmlPlist.utf8.count))
            }
            if let a = attr1 {
                if info.pointee.auth_attr == nil {
                    info.pointee.auth_attr = OpaquePointer(ldid_OPENSSL_sk_new_null())
                }
                _ = ldid_OPENSSL_sk_push(UnsafeMutableRawPointer(info.pointee.auth_attr), UnsafeMutableRawPointer(a))
            }
        }
        PKCS7_ctrl(pkcs7, 1, 1, nil)
        var data = payload
        guard let bio = BIO_new(BIO_s_mem()) else { return nil }
        defer { BIO_free(bio) }
        data.withUnsafeMutableBytes { raw in
            _ = PKCS7_final(pkcs7, BIO_new_mem_buf(raw.baseAddress, Int32(payload.count)), PKCS7_BINARY)
        }
        guard let outBio = BIO_new(BIO_s_mem()) else { return nil }
        defer { BIO_free(outBio) }
        if i2d_PKCS7_bio(outBio, pkcs7) != 1 { return nil }
        var outPtr: UnsafeMutablePointer<CChar>? = nil
        let len = withUnsafeMutablePointer(to: &outPtr) { ptr in
            BIO_ctrl(outBio, 1, 0, UnsafeMutableRawPointer(ptr))
        }
        guard len > 0, let ptr = outPtr else { return nil }
        return Data(bytes: ptr, count: Int(len))
    }
    
    deinit {
        if let pkey = pkey { EVP_PKEY_free(pkey) }
        if let cert = cert { X509_free(cert) }
        if let ca = caCerts {
            ldid_OPENSSL_sk_pop_free_X509(UnsafeMutableRawPointer(ca))
        }
    }
}

if CommandLine.arguments.count > 1 && (CommandLine.arguments.contains("--verify") || CommandLine.arguments.contains("--super-deep") || CommandLine.arguments.contains("--keychain")) {
    exit(ldid_cs_main())
}



