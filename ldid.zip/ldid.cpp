#include "ldid.hpp"
#include <archive.h>
#include <archive_entry.h>
#include <cstring>
#include <cstdio>
#include <cstdlib>
#include <algorithm>
#include <numeric>
#include <fstream>
#include <sstream>
#include <iostream>
#include <set>
#include <map>
#include <mutex>
#include <cassert>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <fcntl.h>
#include <unistd.h>
#include <dirent.h>
#include <errno.h>
#include <dlfcn.h>
#include <openssl/sha.h>
#include <openssl/rsa.h>
#include <openssl/ec.h>
#include <openssl/bn.h>
#include <openssl/objects.h>
#include <openssl/asn1.h>
#include <openssl/asn1t.h>
#include <openssl/provider.h>
#include <openssl/stack.h>
#include <openssl/pem.h>
#include <openssl/ui.h>

typedef struct {
    ASN1_OBJECT *algorithm;
    ASN1_OCTET_STRING *value;
} LDID_APPLE_CDHASH;

typedef struct {
    ASN1_OBJECT *object;
    STACK_OF(LDID_APPLE_CDHASH) *cdhashes;
} LDID_APPLE_CDATTR;

ASN1_SEQUENCE(LDID_APPLE_CDHASH) = {
    ASN1_SIMPLE(LDID_APPLE_CDHASH, algorithm, ASN1_OBJECT),
    ASN1_SIMPLE(LDID_APPLE_CDHASH, value, ASN1_OCTET_STRING)
} ASN1_SEQUENCE_END(LDID_APPLE_CDHASH)
IMPLEMENT_ASN1_FUNCTIONS(LDID_APPLE_CDHASH)

ASN1_SEQUENCE(LDID_APPLE_CDATTR) = {
    ASN1_SIMPLE(LDID_APPLE_CDATTR, object, ASN1_OBJECT),
    ASN1_SEQUENCE_OF(LDID_APPLE_CDATTR, cdhashes, LDID_APPLE_CDHASH)
} ASN1_SEQUENCE_END(LDID_APPLE_CDATTR)
IMPLEMENT_ASN1_FUNCTIONS(LDID_APPLE_CDATTR)

namespace ldid {

namespace {

inline uint16_t swap16(uint16_t v) { return (uint16_t)((v >> 8) | (v << 8)); }

inline uint32_t swap32(uint32_t v) {
    v = ((v >> 8) & 0x00ff00ff) | ((v << 8) & 0xff00ff00);
    v = ((v >> 16) & 0x0000ffff) | ((v << 16) & 0xffff0000);
    return v;
}

inline uint64_t swap64(uint64_t v) {
    v = (v & 0x00000000ffffffffULL) << 32 | (v & 0xffffffff00000000ULL) >> 32;
    v = (v & 0x0000ffff0000ffffULL) << 16 | (v & 0xffff0000ffff0000ULL) >> 16;
    v = (v & 0x00ff00ff00ff00ffULL) << 8  | (v & 0xff00ff00ff00ff00ULL) >> 8;
    return v;
}

inline bool host_is_le() { const uint16_t x = 1; return ((const uint8_t *)&x)[0] == 1; }
inline uint32_t swap32h(uint32_t v) { return host_is_le() ? swap32(v) : v; }
inline uint64_t swap64h(uint64_t v) { return host_is_le() ? swap64(v) : v; }
inline uint64_t align_up64(uint64_t v, uint64_t a) { return a == 0 ? v : (v + a - 1) / a * a; }

struct MachHdr {
    bool b64; bool swp; uint32_t hsz;
    uint32_t cpu; uint32_t sub; uint32_t ft;
    uint32_t nc; uint32_t sc; uint32_t fl;
};

struct LdCmd { uint32_t cmd; uint32_t sz; uint64_t off; };

struct SegInfo {
    std::string name; uint64_t vmaddr; uint64_t vmsize;
    uint64_t fileoff; uint64_t filesize; uint32_t initprot;
    uint64_t cmd_off; uint32_t cmd; uint32_t nsects;
};

struct SliceInfo {
    MachHdr hdr;
    std::vector<LdCmd> cmds;
    std::vector<SegInfo> segs;
    uint64_t sig_off; uint64_t sig_sz; bool has_sig;
    uint64_t exec_base; uint64_t exec_end;
    uint64_t le_fileoff; uint64_t le_filesize;
    uint64_t le_cmd_off; uint32_t le_cmd; bool has_le;
    uint32_t cryptid; bool has_crypt;
    uint64_t sym_stroff; uint64_t sym_strsz; bool has_sym;
    uint64_t content_start; uint64_t cmds_end;
};

MachHdr parse_hdr(const uint8_t *d, size_t sz) {
    MachHdr h{};
    h.b64 = false; h.swp = false; h.hsz = 0;
    h.cpu = 0; h.sub = 0; h.ft = 0; h.nc = 0; h.sc = 0; h.fl = 0;
    if (sz < 4) return h;
    uint32_t m; memcpy(&m, d, 4);
    if (m == 0xfeedfacf || m == 0xcffaedfe) { h.b64 = true; h.swp = (m == 0xcffaedfe); h.hsz = 32; }
    else if (m == 0xfeedface || m == 0xcefaedfe) { h.b64 = false; h.swp = (m == 0xcefaedfe); h.hsz = 28; }
    else return h;
    if (sz < h.hsz) return h;
    auto r32 = [&](size_t o) -> uint32_t { uint32_t v; memcpy(&v, d + o, 4); return h.swp ? swap32(v) : v; };
    h.cpu = r32(4); h.sub = r32(8); h.ft = r32(12);
    h.nc = r32(16); h.sc = r32(20); h.fl = r32(24);
    return h;
}

SliceInfo analyze(const uint8_t *d, size_t sz, uint64_t soff) {
    SliceInfo r{};
    r.hdr = parse_hdr(d, sz);
    r.has_sig = false; r.has_le = false; r.has_crypt = false; r.has_sym = false;
    r.exec_base = 0; r.exec_end = 0; r.sig_off = 0; r.sig_sz = 0;
    r.le_fileoff = 0; r.le_filesize = 0; r.le_cmd_off = 0; r.le_cmd = 0;
    r.cryptid = 0; r.sym_stroff = 0; r.sym_strsz = 0;
    r.cmds_end = soff + r.hdr.hsz + r.hdr.sc;
    r.content_start = r.cmds_end;
    auto r32 = [&](size_t o) -> uint32_t { if (o + 4 > sz) return 0; uint32_t v; memcpy(&v, d + o, 4); return r.hdr.swp ? swap32(v) : v; };
    auto r64 = [&](size_t o) -> uint64_t { if (o + 8 > sz) return 0; uint64_t v; memcpy(&v, d + o, 8); return r.hdr.swp ? swap64(v) : v; };
    uint64_t off = r.hdr.hsz;
    for (uint32_t i = 0; i < r.hdr.nc; i++) {
        if (off + 8 > sz) break;
        uint32_t cmd = r32(off); uint32_t csz = r32(off + 4);
        if (csz < 8 || off + csz > sz) break;
        r.cmds.push_back({cmd, csz, off});
        if (cmd == 0x1d) { r.sig_off = r32(off + 8); r.sig_sz = r32(off + 12); r.has_sig = true; }
        else if (cmd == 0x21 || cmd == 0x2c) { r.cryptid = r32(off + 16); r.has_crypt = true; }
        else if (cmd == 0x02) { r.sym_stroff = r32(off + 16); r.sym_strsz = r32(off + 20); r.has_sym = true; }
        else if (cmd == 0x19 || cmd == 0x01) {
            SegInfo sg{};
            sg.cmd = cmd; sg.cmd_off = off;
            sg.vmaddr = 0; sg.vmsize = 0; sg.fileoff = 0; sg.filesize = 0;
            sg.initprot = 0; sg.nsects = 0;
            char nb[17] = {0}; memcpy(nb, d + off + 8, 16); sg.name = nb;
            if (cmd == 0x19) {
                sg.vmaddr = r64(off + 24); sg.vmsize = r64(off + 32);
                sg.fileoff = r64(off + 40); sg.filesize = r64(off + 48);
                sg.initprot = r32(off + 60); sg.nsects = r32(off + 64);
            } else {
                sg.vmaddr = r32(off + 24); sg.vmsize = r32(off + 28);
                sg.fileoff = r32(off + 32); sg.filesize = r32(off + 36);
                sg.initprot = r32(off + 44); sg.nsects = r32(off + 48);
            }
            r.segs.push_back(sg);
            if ((sg.initprot & 4) != 0) {
                if (r.exec_base == 0 || sg.vmaddr < r.exec_base) r.exec_base = sg.vmaddr;
                if (sg.vmaddr + sg.vmsize > r.exec_end) r.exec_end = sg.vmaddr + sg.vmsize;
            }
            if (sg.name == "__LINKEDIT") {
                r.le_fileoff = sg.fileoff; r.le_filesize = sg.filesize;
                r.le_cmd_off = off; r.le_cmd = cmd; r.has_le = true;
            }
            uint64_t ss = (cmd == 0x19) ? off + 72 : off + 56;
            uint64_t sss = (cmd == 0x19) ? 80 : 68;
            for (uint32_t s = 0; s < sg.nsects; s++) {
                uint64_t so = ss + s * sss;
                if (so + sss > sz) break;
                uint32_t sfo = (cmd == 0x19) ? r32(so + 48) : r32(so + 40);
                uint64_t ab = soff + sfo;
                if (ab > r.cmds_end && ab < r.content_start) r.content_start = ab;
            }
        }
        off += csz;
    }
    return r;
}

void pu32(std::vector<uint8_t> &o, uint32_t v) {
    o.push_back((v >> 24) & 0xff); o.push_back((v >> 16) & 0xff);
    o.push_back((v >> 8) & 0xff); o.push_back(v & 0xff);
}

void pu64(std::vector<uint8_t> &o, uint64_t v) {
    for (int i = 7; i >= 0; i--) o.push_back((v >> (i * 8)) & 0xff);
}

void wu32(std::vector<uint8_t> &o, uint32_t v, bool sw) {
    if (sw) v = swap32(v);
    for (int i = 0; i < 4; i++) o.push_back((v >> (i * 8)) & 0xff);
}

void wu64(std::vector<uint8_t> &o, uint64_t v, bool sw) {
    if (sw) v = swap64(v);
    for (int i = 0; i < 8; i++) o.push_back((v >> (i * 8)) & 0xff);
}

uint32_t ru32le(const uint8_t *d, size_t o) {
    return (uint32_t)d[o] | ((uint32_t)d[o+1] << 8) | ((uint32_t)d[o+2] << 16) | ((uint32_t)d[o+3] << 24);
}

uint32_t ru32be(const uint8_t *d, size_t o) {
    return ((uint32_t)d[o] << 24) | ((uint32_t)d[o+1] << 16) | ((uint32_t)d[o+2] << 8) | (uint32_t)d[o+3];
}

std::vector<uint8_t> der_len_bytes(uint64_t v) {
    std::vector<uint8_t> o;
    if (v < 128) { o.push_back((uint8_t)v); return o; }
    std::vector<uint8_t> b;
    while (v > 0) { b.insert(b.begin(), v & 0xff); v >>= 8; }
    o.push_back(0x80 | (uint8_t)b.size());
    o.insert(o.end(), b.begin(), b.end());
    return o;
}

std::vector<uint8_t> der_tag(uint8_t t, const std::vector<uint8_t> &p) {
    std::vector<uint8_t> o;
    o.push_back(t);
    auto l = der_len_bytes(p.size());
    o.insert(o.end(), l.begin(), l.end());
    o.insert(o.end(), p.begin(), p.end());
    return o;
}

std::vector<uint8_t> der_bool(bool v) { return {0x01, 0x01, (uint8_t)(v ? 1 : 0)}; }
std::vector<uint8_t> der_utf8(const std::string &s) { return der_tag(0x0c, std::vector<uint8_t>(s.begin(), s.end())); }
std::vector<uint8_t> der_oct(const std::vector<uint8_t> &v) { return der_tag(0x04, v); }

std::vector<uint8_t> der_int(int64_t v) {
    std::vector<uint8_t> b;
    if (v == 0) b.push_back(0);
    else if (v > 0) {
        uint64_t x = (uint64_t)v;
        while (x > 0) { b.insert(b.begin(), x & 0xff); x >>= 8; }
        if (b[0] & 0x80) b.insert(b.begin(), 0);
    } else {
        uint64_t x = (uint64_t)v;
        std::vector<uint8_t> a(8);
        for (int i = 0; i < 8; i++) a[i] = (x >> ((7 - i) * 8)) & 0xff;
        int s = 0;
        while (s < 7 && a[s] == 0xff && (a[s + 1] & 0x80)) s++;
        b.assign(a.begin() + s, a.end());
    }
    return der_tag(0x02, b);
}

std::vector<uint8_t> der_encode_plist_node(plist_t node) {
    std::vector<uint8_t> out;
    plist_type t = plist_get_node_type(node);
    switch (t) {
        case PLIST_BOOLEAN: { uint8_t v = 0; plist_get_bool_val(node, &v); out = der_bool(v != 0); break; }
        case PLIST_UINT: { uint64_t v = 0; plist_get_uint_val(node, &v); out = der_int((int64_t)v); break; }
        case PLIST_REAL: { double v = 0; plist_get_real_val(node, &v); out = der_int((int64_t)v); break; }
        case PLIST_STRING: { char *v = nullptr; plist_get_string_val(node, &v); if (v) { out = der_utf8(std::string(v)); free(v); } break; }
        case PLIST_DATA: { char *v = nullptr; uint64_t l = 0; plist_get_data_val(node, &v, &l); if (v) { out = der_oct(std::vector<uint8_t>(v, v + l)); free(v); } break; }
        case PLIST_ARRAY: {
            uint32_t c = plist_array_get_size(node);
            std::vector<uint8_t> items;
            for (uint32_t i = 0; i < c; i++) {
                auto e = der_encode_plist_node(plist_array_get_item(node, i));
                items.insert(items.end(), e.begin(), e.end());
            }
            out = der_tag(0x30, items);
            break;
        }
        case PLIST_DICT: {
            std::vector<std::vector<uint8_t>> pairs;
            plist_dict_iter it = nullptr;
            plist_dict_new_iter(node, &it);
            if (it) {
                char *k = nullptr; plist_t v = nullptr;
                plist_dict_next_item(node, it, &k, &v);
                while (k) {
                    auto kd = der_utf8(std::string(k));
                    auto vd = der_encode_plist_node(v);
                    std::vector<uint8_t> pp;
                    pp.insert(pp.end(), kd.begin(), kd.end());
                    pp.insert(pp.end(), vd.begin(), vd.end());
                    pairs.push_back(der_tag(0x30, pp));
                    free(k); k = nullptr; v = nullptr;
                    plist_dict_next_item(node, it, &k, &v);
                }
                free(it);
            }
            std::sort(pairs.begin(), pairs.end());
            std::vector<uint8_t> comb;
            for (auto &p : pairs) comb.insert(comb.end(), p.begin(), p.end());
            out = der_tag(0x31, comb);
            break;
        }
        default: break;
    }
    return out;
}

std::string plist_xml_str(plist_t n) {
    char *x = nullptr; uint32_t l = 0;
    plist_to_xml(n, &x, &l);
    if (x) { std::string r(x, l); free(x); return r; }
    return "";
}

plist_t plist_from_xml_s(const std::string &x) {
    plist_t n = nullptr;
    plist_from_xml(x.c_str(), x.size(), &n);
    return n;
}

bool plist_dict_bool(plist_t d, const std::string &k) {
    plist_t i = plist_dict_get_item(d, k.c_str());
    if (!i || plist_get_node_type(i) != PLIST_BOOLEAN) return false;
    uint8_t v = 0;
    plist_get_bool_val(i, &v);
    return v != 0;
}

struct ASN1Node {
    uint8_t tc; bool cons; uint64_t tn;
    size_t so; size_t eo;
    std::vector<ASN1Node> ch;
};

std::vector<ASN1Node> asn1_dec(const uint8_t *d, size_t sz, size_t base) {
    std::vector<ASN1Node> nodes;
    size_t off = 0;
    while (off < sz) {
        ASN1Node n{};
        n.so = base + off; n.tc = 0; n.cons = false; n.tn = 0; n.eo = 0;
        uint8_t fb = d[off]; off++;
        n.tc = (fb >> 6) & 0x03;
        n.cons = ((fb >> 5) & 0x01) == 1;
        n.tn = fb & 0x1F;
        if (n.tn == 0x1F) {
            n.tn = 0;
            while (off < sz) { uint8_t b = d[off]; off++; n.tn = (n.tn << 7) | (b & 0x7F); if ((b & 0x80) == 0) break; }
        }
        if (off >= sz) break;
        uint64_t len = 0;
        uint8_t lb = d[off]; off++;
        if ((lb & 0x80) == 0) len = lb;
        else { int nb = lb & 0x7F; for (int i = 0; i < nb && off < sz; i++) { len = (len << 8) | d[off]; off++; } }
        size_t ve = off + len;
        if (ve > sz) break;
        if (n.cons) n.ch = asn1_dec(d + off, len, base + off);
        n.eo = base + ve;
        nodes.push_back(std::move(n));
        off = ve;
    }
    return nodes;
}

std::vector<std::vector<uint8_t>> extract_certs_raw(const uint8_t *d, size_t sz) {
    std::vector<std::vector<uint8_t>> certs;
    auto nodes = asn1_dec(d, sz, 0);
    std::function<void(const ASN1Node &)> trav = [&](const ASN1Node &n) {
        if (n.tc == 2 && n.tn == 0 && n.cons) {
            for (auto &c : n.ch) {
                if (c.tc == 1 && c.tn == 17 && c.cons) {
                    for (auto &cn : c.ch) {
                        if (cn.tc == 0 && cn.tn == 16 && cn.cons)
                            certs.emplace_back(d + cn.so, d + cn.eo);
                    }
                }
            }
        }
        for (auto &c : n.ch) trav(c);
    };
    for (auto &n : nodes) trav(n);
    return certs;
}

std::string read_cstr(const uint8_t *d, size_t sz, size_t off, size_t lim) {
    std::string r;
    size_t rem = std::min(lim, (size_t)65536);
    size_t c = off;
    while (rem > 0 && c < sz) {
        if (d[c] == 0) break;
        r.push_back((char)d[c]); c++; rem--;
    }
    return r;
}

std::string temp_path() {
    static int ctr = 0;
    std::ostringstream o;
    o << "/tmp/ldid-" << getpid() << "-" << ctr++;
    return o.str();
}

struct ArchiveEngine {
    static bool extract(const std::filesystem::path &ap, const std::filesystem::path &dd) {
        struct archive *a = archive_read_new();
        struct archive *ext = archive_write_disk_new();
        if (!a || !ext) { if (a) archive_read_free(a); if (ext) archive_write_free(ext); return false; }
        archive_read_support_format_all(a);
        archive_read_support_filter_all(a);
        archive_write_disk_set_options(ext, ARCHIVE_EXTRACT_TIME | ARCHIVE_EXTRACT_PERM | ARCHIVE_EXTRACT_ACL | ARCHIVE_EXTRACT_FFLAGS);
        archive_write_disk_set_standard_lookup(ext);
        if (archive_read_open_filename(a, ap.c_str(), 10240) != ARCHIVE_OK) {
            archive_read_free(a); archive_write_free(ext); return false;
        }
        std::filesystem::create_directories(dd);
        struct archive_entry *entry = nullptr;
        int result;
        while ((result = archive_read_next_header(a, &entry)) == ARCHIVE_OK) {
            std::string np = dd.string() + "/" + archive_entry_pathname(entry);
            archive_entry_set_pathname(entry, np.c_str());
            result = archive_write_header(ext, entry);
            if (result != ARCHIVE_OK) { archive_read_data_skip(a); continue; }
            const void *buff; size_t size; la_int64_t offset;
            while (archive_read_data_block(a, &buff, &size, &offset) == ARCHIVE_OK)
                archive_write_data_block(ext, buff, size, offset);
            archive_write_finish_entry(ext);
        }
        archive_read_close(a); archive_read_free(a);
        archive_write_close(ext); archive_write_free(ext);
        return true;
    }

    static bool create_ipa(const std::filesystem::path &app, const std::filesystem::path &out) {
        struct archive *a = archive_write_new();
        if (!a) return false;
        archive_write_set_format_zip(a);
        archive_write_zip_set_compression_deflate(a);
        if (archive_write_open_filename(a, out.c_str()) != ARCHIVE_OK) { archive_write_free(a); return false; }
        std::string bn = app.filename().string();
        std::string prefix = "Payload/" + bn + "/";
        auto pe = archive_entry_new();
        archive_entry_set_pathname(pe, "Payload/");
        archive_entry_set_filetype(pe, AE_IFDIR);
        archive_entry_set_perm(pe, 0755);
        archive_write_header(a, pe);
        archive_entry_free(pe);
        auto be = archive_entry_new();
        archive_entry_set_pathname(be, prefix.c_str());
        archive_entry_set_filetype(be, AE_IFDIR);
        archive_entry_set_perm(be, 0755);
        archive_write_header(a, be);
        archive_entry_free(be);
        bool ok = add_dir(a, app, prefix);
        archive_write_close(a);
        archive_write_free(a);
        return ok;
    }

    static bool create_zip(const std::filesystem::path &src, const std::filesystem::path &out) {
        struct archive *a = archive_write_new();
        if (!a) return false;
        archive_write_set_format_zip(a);
        archive_write_zip_set_compression_deflate(a);
        if (archive_write_open_filename(a, out.c_str()) != ARCHIVE_OK) { archive_write_free(a); return false; }
        bool ok = add_dir(a, src, "");
        archive_write_close(a);
        archive_write_free(a);
        return ok;
    }

    static std::optional<std::string> find_app_bundle(const std::filesystem::path &dir) {
        for (auto &e : std::filesystem::directory_iterator(dir)) {
            if (e.is_directory() && e.path().extension() == ".app") return e.path().string();
        }
        return std::nullopt;
    }

    static std::optional<std::string> find_exec_in_bundle(const std::filesystem::path &bp) {
        auto ip = bp / "Info.plist";
        if (!std::filesystem::exists(ip)) return std::nullopt;
        auto data = read_file(ip);
        plist_t root = nullptr;
        plist_from_xml((const char *)data.data(), data.size(), &root);
        if (!root) plist_from_bin((const char *)data.data(), data.size(), &root);
        if (!root) return std::nullopt;
        plist_t ei = plist_dict_get_item(root, "CFBundleExecutable");
        if (!ei || plist_get_node_type(ei) != PLIST_STRING) { plist_free(root); return std::nullopt; }
        char *en = nullptr;
        plist_get_string_val(ei, &en);
        plist_free(root);
        if (!en) return std::nullopt;
        std::string exec_name(en);
        free(en);
        auto ep = bp / exec_name;
        if (!std::filesystem::exists(ep)) return std::nullopt;
        return ep.string();
    }

private:
    static bool add_dir(struct archive *a, const std::filesystem::path &dir, const std::string &prefix) {
        for (auto &e : std::filesystem::directory_iterator(dir)) {
            std::string name = prefix.empty() ? e.path().filename().string() : prefix + e.path().filename().string();
            if (e.is_directory()) {
                std::string dn = name + "/";
                auto ae = archive_entry_new();
                archive_entry_set_pathname(ae, dn.c_str());
                archive_entry_set_filetype(ae, AE_IFDIR);
                archive_entry_set_perm(ae, 0755);
                archive_write_header(a, ae);
                archive_entry_free(ae);
                if (!add_dir(a, e.path(), name)) return false;
            } else if (e.is_regular_file()) {
                auto ae = archive_entry_new();
                archive_entry_set_pathname(ae, name.c_str());
                archive_entry_set_filetype(ae, AE_IFREG);
                archive_entry_set_perm(ae, 0644);
                auto fs = std::filesystem::file_size(e.path());
                archive_entry_set_size(ae, fs);
                archive_write_header(a, ae);
                std::ifstream f(e.path(), std::ios::binary);
                std::vector<uint8_t> buf(65536);
                while (f.good()) {
                    f.read((char *)buf.data(), buf.size());
                    auto n = f.gcount();
                    if (n > 0) archive_write_data(a, buf.data(), n);
                }
                archive_entry_free(ae);
            }
        }
        return true;
    }
};

}

std::vector<uint8_t> read_file(const std::filesystem::path &path) {
    std::ifstream f(path, std::ios::binary | std::ios::ate);
    if (!f.is_open()) return {};
    auto sz = f.tellg();
    f.seekg(0, std::ios::beg);
    std::vector<uint8_t> data(sz);
    f.read((char *)data.data(), sz);
    return data;
}

bool write_file(const std::filesystem::path &path, const std::vector<uint8_t> &data) {
    std::ofstream f(path, std::ios::binary | std::ios::trunc);
    if (!f.is_open()) return false;
    f.write((const char *)data.data(), data.size());
    return f.good();
}

std::vector<uint8_t> CryptoEngine::sha1(const void *data, size_t len) {
    std::vector<uint8_t> out(20);
    unsigned int ol = 0;
    EVP_MD_CTX *ctx = EVP_MD_CTX_new();
    if (!ctx) return out;
    if (EVP_DigestInit_ex(ctx, EVP_sha1(), nullptr) != 1 ||
        EVP_DigestUpdate(ctx, data, len) != 1 ||
        EVP_DigestFinal_ex(ctx, out.data(), &ol) != 1) { EVP_MD_CTX_free(ctx); return out; }
    EVP_MD_CTX_free(ctx);
    out.resize(ol);
    return out;
}

std::vector<uint8_t> CryptoEngine::sha256(const void *data, size_t len) {
    std::vector<uint8_t> out(32);
    unsigned int ol = 0;
    EVP_MD_CTX *ctx = EVP_MD_CTX_new();
    if (!ctx) return out;
    if (EVP_DigestInit_ex(ctx, EVP_sha256(), nullptr) != 1 ||
        EVP_DigestUpdate(ctx, data, len) != 1 ||
        EVP_DigestFinal_ex(ctx, out.data(), &ol) != 1) { EVP_MD_CTX_free(ctx); return out; }
    EVP_MD_CTX_free(ctx);
    out.resize(ol);
    return out;
}

std::vector<uint8_t> CryptoEngine::sign_pkcs7(EVP_PKEY *pkey, X509 *cert, STACK_OF(X509) *ca, const std::vector<uint8_t> &payload, bool include_cdhash_attrs) {
    PKCS7 *p7 = PKCS7_new();
    if (!p7) return {};
    PKCS7_set_type(p7, NID_pkcs7_signed);
    PKCS7_content_new(p7, NID_pkcs7_data);
    PKCS7_add_certificate(p7, cert);
    if (ca) {
        int cnt = sk_X509_num(ca);
        for (int i = 0; i < cnt; i++) {
            X509 *c = sk_X509_value(ca, i);
            if (c) PKCS7_add_certificate(p7, c);
        }
    }
    PKCS7_SIGNER_INFO *info = PKCS7_sign_add_signer(p7, cert, pkey, EVP_sha256(), PKCS7_NOSMIMECAP);
    if (!info) { PKCS7_free(p7); return {}; }
    if (include_cdhash_attrs) {
        auto cd_sha1 = sha1(payload.data(), payload.size());
        auto cd_sha256 = sha256(payload.data(), payload.size());
        std::string xml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
            "<!DOCTYPE plist PUBLIC \"-//Apple//DTD PLIST 1.0//EN\" \"http://www.apple.com/DTDs/PropertyList-1.0.dtd\">\n"
            "<plist version=\"1.0\">\n<dict>\n\t<key>cdhashes</key>\n\t<array>\n";
        {
            BIO *b64 = BIO_new(BIO_f_base64());
            BIO *mem = BIO_new(BIO_s_mem());
            b64 = BIO_push(b64, mem);
            BIO_set_flags(b64, BIO_FLAGS_BASE64_NO_NL);
            BIO_write(b64, cd_sha1.data(), cd_sha1.size());
            BIO_flush(b64);
            BUF_MEM *bp = nullptr;
            BIO_get_mem_ptr(b64, &bp);
            xml += "\t\t<data>" + std::string(bp->data, bp->length) + "</data>\n";
            BIO_free_all(b64);
        }
        {
            BIO *b64 = BIO_new(BIO_f_base64());
            BIO *mem = BIO_new(BIO_s_mem());
            b64 = BIO_push(b64, mem);
            BIO_set_flags(b64, BIO_FLAGS_BASE64_NO_NL);
            BIO_write(b64, cd_sha256.data(), cd_sha256.size());
            BIO_flush(b64);
            BUF_MEM *bp = nullptr;
            BIO_get_mem_ptr(b64, &bp);
            xml += "\t\t<data>" + std::string(bp->data, bp->length) + "</data>\n";
            BIO_free_all(b64);
        }
        xml += "\t</array>\n</dict>\n</plist>\n";
        ASN1_OBJECT *obj1 = OBJ_txt2obj("1.2.840.113635.100.9.1", 1);
        X509_ATTRIBUTE *attr1 = X509_ATTRIBUTE_create_by_NID(nullptr, NID_undef, V_ASN1_OCTET_STRING, xml.c_str(), xml.size());
        X509_ATTRIBUTE_set1_object(attr1, obj1);
        ASN1_OBJECT_free(obj1);
        if (!info->auth_attr) info->auth_attr = sk_X509_ATTRIBUTE_new_null();
        sk_X509_ATTRIBUTE_push(info->auth_attr, attr1);
        uint8_t der[200];
        uint8_t *p = der;
        uint8_t sha1_alg[] = {0x30, 0x09, 0x06, 0x05, 0x2B, 0x0E, 0x03, 0x02, 0x1A, 0x05, 0x00};
        uint8_t sha256_alg[] = {0x30, 0x0D, 0x06, 0x09, 0x60, 0x86, 0x48, 0x01, 0x65, 0x03, 0x04, 0x02, 0x01, 0x05, 0x00};
        uint8_t sha1_seq[35];
        sha1_seq[0] = 0x30; sha1_seq[1] = 0x21;
        memcpy(sha1_seq + 2, sha1_alg, 11);
        sha1_seq[13] = 0x04; sha1_seq[14] = 0x14;
        memcpy(sha1_seq + 15, cd_sha1.data(), 20);
        uint8_t sha256_seq[51];
        sha256_seq[0] = 0x30; sha256_seq[1] = 0x33;
        memcpy(sha256_seq + 2, sha256_alg, 15);
        sha256_seq[17] = 0x04; sha256_seq[18] = 0x20;
        memcpy(sha256_seq + 19, cd_sha256.data(), 32);
        int total_len = sizeof(sha1_seq) + sizeof(sha256_seq);
        *p++ = 0x30;
        *p++ = (uint8_t)total_len;
        memcpy(p, sha1_seq, sizeof(sha1_seq)); p += sizeof(sha1_seq);
        memcpy(p, sha256_seq, sizeof(sha256_seq)); p += sizeof(sha256_seq);
        int val_len = (int)(p - der);
        ASN1_OBJECT *obj2 = OBJ_txt2obj("1.2.840.113635.100.9.2", 1);
        X509_ATTRIBUTE *attr2 = X509_ATTRIBUTE_create_by_NID(nullptr, NID_undef, V_ASN1_SEQUENCE, der, val_len);
        X509_ATTRIBUTE_set1_object(attr2, obj2);
        ASN1_OBJECT_free(obj2);
        sk_X509_ATTRIBUTE_push(info->auth_attr, attr2);
    }
    PKCS7_ctrl(p7, 1, 1, nullptr);
    BIO *data_bio = BIO_new_mem_buf(payload.data(), payload.size());
    if (PKCS7_final(p7, data_bio, PKCS7_BINARY) != 1) {
        BIO_free(data_bio); PKCS7_free(p7); return {};
    }
    BIO_free(data_bio);
    BIO *out_bio = BIO_new(BIO_s_mem());
    if (i2d_PKCS7_bio(out_bio, p7) != 1) { BIO_free(out_bio); PKCS7_free(p7); return {}; }
    char *out_ptr = nullptr;
    long len = BIO_get_mem_data(out_bio, &out_ptr);
    std::vector<uint8_t> result;
    if (len > 0 && out_ptr) result.assign(out_ptr, out_ptr + len);
    BIO_free(out_bio);
    PKCS7_free(p7);
    return result;
}

std::vector<std::vector<uint8_t>> CryptoEngine::extract_certs_from_pkcs7(const std::vector<uint8_t> &pkcs7_data) {
    return extract_certs_raw(pkcs7_data.data(), pkcs7_data.size());
}

std::vector<Slice> MachOParser::parse_slices(const std::vector<uint8_t> &data) {
    std::vector<Slice> slices;
    if (data.size() < 4) return slices;
    uint32_t m; memcpy(&m, data.data(), 4);
    uint32_t mbe = swap32(m);
    if (mbe == 0xcafebabe || m == 0xcafebabe) {
        bool swp = (mbe != 0xcafebabe);
        if (data.size() < 8) return slices;
        uint32_t n; memcpy(&n, data.data() + 4, 4);
        if (swp) n = swap32(n);
        for (uint32_t i = 0; i < n; i++) {
            size_t off = 8 + i * 20;
            if (off + 20 > data.size()) break;
            auto rd32 = [&](size_t o) -> uint32_t { uint32_t v; memcpy(&v, data.data() + o, 4); return swp ? swap32(v) : v; };
            Slice s;
            s.cpu_type = (CPUType)rd32(off);
            s.cpu_subtype = rd32(off + 4);
            s.offset = rd32(off + 8);
            s.size = rd32(off + 12);
            s.align = rd32(off + 16);
            if (s.offset + s.size > data.size()) continue;
            slices.push_back(s);
        }
        return slices;
    }
    if (m == 0xfeedface || m == 0xfeedfacf || m == 0xcefaedfe || m == 0xcffaedfe) {
        auto hdr = parse_hdr(data.data(), data.size());
        Slice s;
        s.offset = 0; s.size = data.size();
        s.cpu_type = (CPUType)hdr.cpu; s.cpu_subtype = hdr.sub;
        s.align = hdr.b64 ? 3 : 2;
        slices.push_back(s);
    }
    return slices;
}

std::vector<uint8_t> MachOParser::read_slice(const std::vector<uint8_t> &data, const Slice &slice) {
    if (slice.offset + slice.size > data.size()) return {};
    return std::vector<uint8_t>(data.begin() + slice.offset, data.begin() + slice.offset + slice.size);
}

bool MachOParser::is_fat(const std::vector<uint8_t> &data) {
    if (data.size() < 4) return false;
    uint32_t m; memcpy(&m, data.data(), 4);
    return swap32(m) == 0xcafebabe || m == 0xcafebabe;
}

FileType MachOParser::get_file_type(const std::vector<uint8_t> &data, const Slice &slice) {
    auto sd = read_slice(data, slice);
    if (sd.empty()) return FileType::OBJECT;
    auto h = parse_hdr(sd.data(), sd.size());
    return (FileType)h.ft;
}

std::tuple<uint64_t, uint64_t> MachOParser::get_exec_seg_info(const std::vector<uint8_t> &data, const Slice &slice) {
    auto sd = read_slice(data, slice);
    if (sd.empty()) return {0, 0};
    auto a = analyze(sd.data(), sd.size(), 0);
    uint64_t limit = a.exec_end >= a.exec_base ? a.exec_end - a.exec_base : 0;
    return {a.exec_base, limit};
}

std::optional<SignatureInfo> MachOParser::get_signature_info(const std::vector<uint8_t> &data, const Slice &slice) {
    auto sd = read_slice(data, slice);
    if (sd.empty()) return std::nullopt;
    auto a = analyze(sd.data(), sd.size(), 0);
    if (!a.has_sig) return std::nullopt;
    SignatureInfo info;
    info.is_adhoc = false; info.flags = 0; info.platform = Platform::IOS;
    uint64_t so = a.sig_off;
    if (so + 12 > sd.size()) return std::nullopt;
    uint32_t magic = ru32be(sd.data(), so);
    if (magic != 0xfade0cc0 && magic != 0xfade0cc1) return std::nullopt;
    uint32_t count = ru32be(sd.data(), so + 8);
    for (uint32_t i = 0; i < count; i++) {
        size_t io = so + 12 + i * 8;
        if (io + 8 > sd.size()) break;
        uint32_t slot = ru32be(sd.data(), io);
        uint32_t rel = ru32be(sd.data(), io + 4);
        uint64_t ba = so + rel;
        if (ba + 8 > sd.size()) continue;
        uint32_t blen = ru32be(sd.data(), ba + 4);
        if (blen < 8 || ba + blen > sd.size()) continue;
        if (slot == 5) {
            info.entitlements_xml.assign(sd.begin() + ba + 8, sd.begin() + ba + blen);
        } else if (slot == 2) {
            info.requirements_blob.assign(sd.begin() + ba, sd.begin() + ba + blen);
        } else if (slot == 0 || slot == 0x1000) {
            if (info.identifier.empty() && blen >= 88) {
                info.flags = ru32be(sd.data(), ba + 12);
                uint32_t ioff = ru32be(sd.data(), ba + 20);
                uint32_t toff = ru32be(sd.data(), ba + 48);
                uint8_t ht = sd[ba + 37];
                if (ioff >= 8 && ioff < blen)
                    info.identifier = read_cstr(sd.data(), sd.size(), ba + ioff, blen - ioff);
                if (toff >= 8 && toff < blen)
                    info.team_id = read_cstr(sd.data(), sd.size(), ba + toff, blen - toff);
                std::vector<uint8_t> cdb(sd.begin() + ba, sd.begin() + ba + blen);
                if (ht == 1) info.cd_hash_sha1 = CryptoEngine::sha1(cdb.data(), cdb.size());
                else if (ht == 2) info.cd_hash_sha256 = CryptoEngine::sha256(cdb.data(), cdb.size());
                if (info.flags & 0x0002) info.is_adhoc = true;
            }
        }
    }
    return info;
}

std::vector<uint8_t> BlobBuilder::make_blob(uint32_t magic, const std::vector<uint8_t> &payload) {
    std::vector<uint8_t> out;
    pu32(out, magic);
    pu32(out, (uint32_t)(8 + payload.size()));
    out.insert(out.end(), payload.begin(), payload.end());
    return out;
}

std::vector<uint8_t> BlobBuilder::build_superblob(uint32_t magic, const std::vector<std::pair<uint32_t, std::vector<uint8_t>>> &items) {
    uint64_t hsz = 12 + items.size() * 8;
    uint64_t total = hsz;
    for (auto &it : items) total += it.second.size();
    std::vector<uint8_t> out;
    pu32(out, magic);
    pu32(out, (uint32_t)total);
    pu32(out, (uint32_t)items.size());
    uint64_t offset = hsz;
    for (auto &it : items) {
        pu32(out, it.first);
        pu32(out, (uint32_t)offset);
        offset += it.second.size();
    }
    for (auto &it : items)
        out.insert(out.end(), it.second.begin(), it.second.end());
    return out;
}

std::vector<uint8_t> BlobBuilder::build_code_directory(
    const std::string &identifier, const std::string &team_id,
    uint64_t code_limit, const std::vector<std::vector<uint8_t>> &page_hashes,
    const std::unordered_map<uint32_t, std::vector<uint8_t>> &special_hashes,
    HashType hash_type, uint32_t flags, Platform platform, uint8_t page_shift,
    uint64_t exec_seg_base, uint64_t exec_seg_limit, uint64_t exec_seg_flags)
{
    uint32_t hs = (hash_type == HashType::SHA1) ? 20 : 32;
    uint32_t ncs = (uint32_t)page_hashes.size();
    uint32_t max_sp = 0;
    for (auto &kv : special_hashes) if (kv.first > max_sp) max_sp = kv.first;
    std::vector<uint8_t> ib(identifier.begin(), identifier.end());
    ib.push_back(0);
    std::vector<uint8_t> tb;
    if (!team_id.empty()) { tb.assign(team_id.begin(), team_id.end()); tb.push_back(0); }
    uint32_t offset = 88;
    uint32_t ident_off = offset;
    offset += (uint32_t)ib.size();
    uint32_t team_off = 0;
    if (!team_id.empty()) { team_off = offset; offset += (uint32_t)tb.size(); }
    offset += max_sp * hs;
    uint32_t hash_off = offset;
    uint64_t blob_len = (uint64_t)hash_off + (uint64_t)ncs * hs;
    std::vector<uint8_t> cd;
    pu32(cd, 0xfade0c02);
    pu32(cd, (uint32_t)blob_len);
    pu32(cd, 0x00020400);
    pu32(cd, flags);
    pu32(cd, hash_off);
    pu32(cd, ident_off);
    pu32(cd, max_sp);
    pu32(cd, ncs);
    pu32(cd, code_limit > 0xffffffff ? 0xffffffff : (uint32_t)code_limit);
    cd.push_back((uint8_t)hs);
    cd.push_back((uint8_t)hash_type);
    cd.push_back((uint8_t)platform);
    cd.push_back(page_shift);
    pu32(cd, 0);
    pu32(cd, 0);
    pu32(cd, team_off);
    pu32(cd, 0);
    pu64(cd, code_limit);
    pu64(cd, exec_seg_base);
    pu64(cd, exec_seg_limit);
    pu64(cd, exec_seg_flags);
    cd.insert(cd.end(), ib.begin(), ib.end());
    if (!team_id.empty()) cd.insert(cd.end(), tb.begin(), tb.end());
    for (uint32_t slot = max_sp; slot >= 1; slot--) {
        auto it = special_hashes.find(slot);
        if (it != special_hashes.end() && it->second.size() == hs)
            cd.insert(cd.end(), it->second.begin(), it->second.end());
        else
            cd.resize(cd.size() + hs, 0);
    }
    for (auto &h : page_hashes) cd.insert(cd.end(), h.begin(), h.end());
    return cd;
}

std::vector<uint8_t> BlobBuilder::build_entitlements_blob(const std::string &xml) {
    return make_blob(0xfade7171, std::vector<uint8_t>(xml.begin(), xml.end()));
}

std::vector<uint8_t> BlobBuilder::build_der_entitlements_blob(plist_t plist) {
    auto dd = der_encode_plist_node(plist);
    return make_blob(0xfade7172, dd);
}

std::vector<uint8_t> BlobBuilder::build_requirements_blob(const std::vector<uint8_t> &raw) {
    if (raw.size() >= 8 && ru32be(raw.data(), 0) == 0xfade0c01) return raw;
    return make_blob(0xfade0c01, raw);
}

KeychainManager &KeychainManager::instance() {
    static KeychainManager mgr;
    return mgr;
}

bool KeychainManager::add_identity(const std::string &label, const std::vector<uint8_t> &p12_data, const std::string &password) {
    BIO *bio = BIO_new_mem_buf(p12_data.data(), p12_data.size());
    if (!bio) return false;
    PKCS12 *p12 = d2i_PKCS12_bio(bio, nullptr);
    BIO_free(bio);
    if (!p12) return false;
    EVP_PKEY *pkey = nullptr; X509 *cert = nullptr; STACK_OF(X509) *ca = nullptr;
    if (PKCS12_parse(p12, password.c_str(), &pkey, &cert, &ca) != 1) { PKCS12_free(p12); return false; }
    PKCS12_free(p12);
    if (!pkey || !cert) {
        if (pkey) EVP_PKEY_free(pkey);
        if (cert) X509_free(cert);
        if (ca) sk_X509_pop_free(ca, X509_free);
        return false;
    }
    IdentityEntry entry;
    entry.label = label;
    entry.p12_data = p12_data;
    entry.password = password;
    entry.common_name = extract_common_name(cert);
    entry.sha1_hash = compute_cert_hash(cert);
    EVP_PKEY_free(pkey);
    X509_free(cert);
    if (ca) sk_X509_pop_free(ca, X509_free);
    identities_.push_back(std::move(entry));
    return true;
}

std::optional<std::pair<EVP_PKEY *, X509 *>> KeychainManager::find_identity(const std::string &query) {
    for (auto &e : identities_) {
        if (e.common_name.find(query) != std::string::npos ||
            e.sha1_hash.find(query) != std::string::npos ||
            e.label.find(query) != std::string::npos) {
            BIO *bio = BIO_new_mem_buf(e.p12_data.data(), e.p12_data.size());
            if (!bio) continue;
            PKCS12 *p12 = d2i_PKCS12_bio(bio, nullptr);
            BIO_free(bio);
            if (!p12) continue;
            EVP_PKEY *pkey = nullptr; X509 *cert = nullptr; STACK_OF(X509) *ca = nullptr;
            if (PKCS12_parse(p12, e.password.c_str(), &pkey, &cert, &ca) != 1) { PKCS12_free(p12); continue; }
            PKCS12_free(p12);
            if (ca) sk_X509_pop_free(ca, X509_free);
            return std::make_pair(pkey, cert);
        }
    }
    return std::nullopt;
}

std::vector<std::string> KeychainManager::list_identities() {
    std::vector<std::string> names;
    for (auto &e : identities_) names.push_back(e.common_name + " [" + e.sha1_hash + "]");
    return names;
}

void KeychainManager::clear() { identities_.clear(); }

std::string KeychainManager::compute_cert_hash(X509 *cert) {
    unsigned char md[20]; unsigned int len = 0;
    X509_digest(cert, EVP_sha1(), md, &len);
    std::string hex;
    char buf[3];
    for (unsigned int i = 0; i < len; i++) { snprintf(buf, sizeof(buf), "%02x", md[i]); hex += buf; }
    return hex;
}

std::string KeychainManager::extract_common_name(X509 *cert) {
    X509_NAME *name = X509_get_subject_name(cert);
    if (!name) return "";
    char buf[256] = {0};
    X509_NAME_get_text_by_NID(name, NID_commonName, buf, sizeof(buf));
    return std::string(buf);
}

Verifier::Result Verifier::verify(const std::filesystem::path &path) {
    auto data = read_file(path);
    if (data.empty()) return Result::IO_ERROR;
    return verify_memory(data);
}

Verifier::Result Verifier::verify_memory(const std::vector<uint8_t> &data) {
    auto slices = MachOParser::parse_slices(data);
    if (slices.empty()) return Result::INVALID_FORMAT;
    for (auto &slice : slices) {
        if (!verify_slice(data, slice)) return Result::INVALID_SIGNATURE;
    }
    return Result::VALID;
}

bool Verifier::verify_with_system(const std::filesystem::path &path) {
    typedef int32_t (*SecStaticCodeCreateWithPathAndAttributes_t)(void *, uint32_t, void *, void **);
    typedef int32_t (*SecCodeCopySigningInformation_t)(void *, uint32_t, void **);
    typedef void (*CFRelease_t)(void *);
    auto create_fn = (SecStaticCodeCreateWithPathAndAttributes_t)dlsym(RTLD_DEFAULT, "SecStaticCodeCreateWithPathAndAttributes");
    auto copy_fn = (SecCodeCopySigningInformation_t)dlsym(RTLD_DEFAULT, "SecCodeCopySigningInformation");
    auto release_fn = (CFRelease_t)dlsym(RTLD_DEFAULT, "CFRelease");
    if (!create_fn || !copy_fn || !release_fn) return false;
    typedef void *(*CFURLCreateFromFileSystemRepresentation_t)(void *, const uint8_t *, long, bool);
    auto url_fn = (CFURLCreateFromFileSystemRepresentation_t)dlsym(RTLD_DEFAULT, "CFURLCreateFromFileSystemRepresentation");
    if (!url_fn) return false;
    auto url = url_fn(nullptr, (const uint8_t *)path.c_str(), path.string().size(), false);
    if (!url) return false;
    void *code = nullptr;
    int32_t status = create_fn(url, 0, nullptr, &code);
    release_fn(url);
    if (status != 0 || !code) return false;
    void *info = nullptr;
    status = copy_fn(code, 0x2 | 0x4, &info);
    release_fn(code);
    if (status != 0) return false;
    if (info) release_fn(info);
    return true;
}

bool Verifier::verify_slice(const std::vector<uint8_t> &data, const Slice &slice) {
    auto sd = MachOParser::read_slice(data, slice);
    if (sd.empty()) return false;
    auto a = analyze(sd.data(), sd.size(), 0);
    if (!a.has_sig) return false;
    uint64_t so = a.sig_off;
    if (so + 12 > sd.size()) return false;
    if (ru32be(sd.data(), so) != 0xfade0cc0) return false;
    uint32_t count = ru32be(sd.data(), so + 8);
    uint64_t cd_off = 0;
    bool found = false;
    for (uint32_t i = 0; i < count; i++) {
        size_t io = so + 12 + i * 8;
        if (io + 8 > sd.size()) break;
        uint32_t slot = ru32be(sd.data(), io);
        uint32_t rel = ru32be(sd.data(), io + 4);
        if (slot == 0 || slot == 0x1000) { cd_off = so + rel; found = true; break; }
    }
    if (!found) return false;
    if (cd_off + 88 > sd.size()) return false;
    if (ru32be(sd.data(), cd_off) != 0xfade0c02) return false;
    uint32_t hash_off = ru32be(sd.data(), cd_off + 16);
    uint32_t nsp = ru32be(sd.data(), cd_off + 24);
    uint32_t ncs = ru32be(sd.data(), cd_off + 28);
    uint32_t cl = ru32be(sd.data(), cd_off + 32);
    uint8_t hs = sd[cd_off + 36];
    uint8_t ht = sd[cd_off + 37];
    uint8_t ps = sd[cd_off + 39];
    uint64_t page_size = 1ULL << ps;
    uint64_t limit = cl;
    uint64_t hashes_start = cd_off + hash_off - (uint64_t)nsp * hs;
    uint64_t total_hs = (uint64_t)(nsp + ncs) * hs;
    if (hashes_start + total_hs > sd.size()) return false;
    uint64_t cur = 0;
    uint64_t rem = limit;
    uint32_t pi = 0;
    uint64_t code_hs_start = (uint64_t)nsp * hs;
    while (rem > 0) {
        uint64_t pl = std::min(page_size, rem);
        std::vector<uint8_t> pd;
        if (cur + pl <= sd.size()) pd.assign(sd.begin() + cur, sd.begin() + cur + pl);
        else {
            size_t avail = (cur < sd.size()) ? sd.size() - cur : 0;
            pd.assign(sd.begin() + cur, sd.begin() + cur + avail);
            pd.resize(pl, 0);
        }
        std::vector<uint8_t> computed;
        if (ht == 1) computed = CryptoEngine::sha1(pd.data(), pd.size());
        else if (ht == 2) computed = CryptoEngine::sha256(pd.data(), pd.size());
        else return false;
        uint64_t es = hashes_start + code_hs_start + (uint64_t)pi * hs;
        if (es + hs > sd.size()) return false;
        if (memcmp(sd.data() + es, computed.data(), hs) != 0) return false;
        cur += pl; rem -= pl; pi++;
    }
    return true;
}

bool Signer::sign(const std::filesystem::path &path, const SignOptions &options) {
    auto data = read_file(path);
    if (data.empty()) return false;
    if (!sign_memory(data, options)) return false;
    return write_file(path, data);
}

bool Signer::sign_memory(std::vector<uint8_t> &data, const SignOptions &options) {
    auto slices = MachOParser::parse_slices(data);
    if (slices.empty()) return false;
    EVP_PKEY *pkey = nullptr; X509 *cert = nullptr; STACK_OF(X509) *ca = nullptr;
    if (!options.key_path.empty()) {
        auto kd = read_file(options.key_path);
        BIO *bio = BIO_new_mem_buf(kd.data(), kd.size());
        if (bio) {
            PKCS12 *p12 = d2i_PKCS12_bio(bio, nullptr);
            BIO_free(bio);
            if (p12) { PKCS12_parse(p12, options.password.c_str(), &pkey, &cert, &ca); PKCS12_free(p12); }
        }
    }
    if (MachOParser::is_fat(data)) {
        std::vector<std::vector<uint8_t>> new_slices;
        for (auto &slice : slices) {
            auto sd = MachOParser::read_slice(data, slice);
            if (!sign_single_slice(sd, options, pkey, cert, ca)) {
                if (pkey) EVP_PKEY_free(pkey);
                if (cert) X509_free(cert);
                if (ca) sk_X509_pop_free(ca, X509_free);
                return false;
            }
            new_slices.push_back(std::move(sd));
        }
        std::vector<uint8_t> out;
        pu32(out, 0xcafebabe);
        pu32(out, (uint32_t)new_slices.size());
        uint64_t offset = 8 + new_slices.size() * 20;
        std::vector<uint8_t> arch_data;
        for (size_t i = 0; i < slices.size(); i++) {
            uint64_t alignment = 1ULL << (slices[i].align > 31 ? 12 : slices[i].align);
            offset = align_up64(offset, alignment);
            pu32(arch_data, (uint32_t)slices[i].cpu_type);
            pu32(arch_data, slices[i].cpu_subtype);
            pu32(arch_data, (uint32_t)offset);
            pu32(arch_data, (uint32_t)new_slices[i].size());
            pu32(arch_data, slices[i].align);
            offset += new_slices[i].size();
        }
        out.insert(out.end(), arch_data.begin(), arch_data.end());
        uint64_t cursor = 8 + new_slices.size() * 20;
        for (size_t i = 0; i < slices.size(); i++) {
            uint64_t alignment = 1ULL << (slices[i].align > 31 ? 12 : slices[i].align);
            uint64_t aligned = align_up64(cursor, alignment);
            if (aligned > cursor) out.resize(out.size() + (aligned - cursor), 0);
            out.insert(out.end(), new_slices[i].begin(), new_slices[i].end());
            cursor = aligned + new_slices[i].size();
        }
        data = std::move(out);
    } else {
        if (!sign_single_slice(data, options, pkey, cert, ca)) {
            if (pkey) EVP_PKEY_free(pkey);
            if (cert) X509_free(cert);
            if (ca) sk_X509_pop_free(ca, X509_free);
            return false;
        }
    }
    if (pkey) EVP_PKEY_free(pkey);
    if (cert) X509_free(cert);
    if (ca) sk_X509_pop_free(ca, X509_free);
    return true;
}

bool Signer::unsign(const std::filesystem::path &path) {
    auto data = read_file(path);
    if (data.empty()) return false;
    if (!unsign_memory(data)) return false;
    return write_file(path, data);
}

bool Signer::unsign_memory(std::vector<uint8_t> &data) {
    auto slices = MachOParser::parse_slices(data);
    if (slices.empty()) return false;
    if (MachOParser::is_fat(data)) {
        std::vector<std::vector<uint8_t>> new_slices;
        for (auto &slice : slices) {
            auto sd = MachOParser::read_slice(data, slice);
            auto a = analyze(sd.data(), sd.size(), 0);
            if (!a.has_sig) { new_slices.push_back(std::move(sd)); continue; }
            std::vector<uint8_t> nc;
            uint32_t ncmds = 0, sizeofcmds = 0;
            for (auto &cmd : a.cmds) {
                if (cmd.cmd == 0x1d) continue;
                nc.insert(nc.end(), sd.begin() + cmd.off, sd.begin() + cmd.off + cmd.sz);
                ncmds++; sizeofcmds += cmd.sz;
            }
            std::vector<uint8_t> result;
            result.insert(result.end(), sd.begin(), sd.begin() + a.hdr.hsz);
            if (a.hdr.swp) {
                uint32_t v = swap32(ncmds); memcpy(result.data() + 16, &v, 4);
                v = swap32(sizeofcmds); memcpy(result.data() + 20, &v, 4);
            } else {
                memcpy(result.data() + 16, &ncmds, 4);
                memcpy(result.data() + 20, &sizeofcmds, 4);
            }
            result.insert(result.end(), nc.begin(), nc.end());
            uint64_t oce = a.hdr.hsz + a.hdr.sc;
            if (result.size() < oce) result.resize(oce, 0);
            uint64_t end = a.sig_off;
            if (end > result.size() && end <= sd.size())
                result.insert(result.end(), sd.begin() + result.size(), sd.begin() + end);
            new_slices.push_back(std::move(result));
        }
        std::vector<uint8_t> out;
        pu32(out, 0xcafebabe);
        pu32(out, (uint32_t)new_slices.size());
        uint64_t offset = 8 + new_slices.size() * 20;
        std::vector<uint8_t> arch_data;
        for (size_t i = 0; i < slices.size(); i++) {
            uint64_t alignment = 1ULL << (slices[i].align > 31 ? 12 : slices[i].align);
            offset = align_up64(offset, alignment);
            pu32(arch_data, (uint32_t)slices[i].cpu_type);
            pu32(arch_data, slices[i].cpu_subtype);
            pu32(arch_data, (uint32_t)offset);
            pu32(arch_data, (uint32_t)new_slices[i].size());
            pu32(arch_data, slices[i].align);
            offset += new_slices[i].size();
        }
        out.insert(out.end(), arch_data.begin(), arch_data.end());
        uint64_t cursor = 8 + new_slices.size() * 20;
        for (size_t i = 0; i < slices.size(); i++) {
            uint64_t alignment = 1ULL << (slices[i].align > 31 ? 12 : slices[i].align);
            uint64_t aligned = align_up64(cursor, alignment);
            if (aligned > cursor) out.resize(out.size() + (aligned - cursor), 0);
            out.insert(out.end(), new_slices[i].begin(), new_slices[i].end());
            cursor = aligned + new_slices[i].size();
        }
        data = std::move(out);
    } else {
        auto a = analyze(data.data(), data.size(), 0);
        if (!a.has_sig) return true;
        std::vector<uint8_t> nc;
        uint32_t ncmds = 0, sizeofcmds = 0;
        for (auto &cmd : a.cmds) {
            if (cmd.cmd == 0x1d) continue;
            nc.insert(nc.end(), data.begin() + cmd.off, data.begin() + cmd.off + cmd.sz);
            ncmds++; sizeofcmds += cmd.sz;
        }
        std::vector<uint8_t> result;
        result.insert(result.end(), data.begin(), data.begin() + a.hdr.hsz);
        if (a.hdr.swp) {
            uint32_t v = swap32(ncmds); memcpy(result.data() + 16, &v, 4);
            v = swap32(sizeofcmds); memcpy(result.data() + 20, &v, 4);
        } else {
            memcpy(result.data() + 16, &ncmds, 4);
            memcpy(result.data() + 20, &sizeofcmds, 4);
        }
        result.insert(result.end(), nc.begin(), nc.end());
        uint64_t oce = a.hdr.hsz + a.hdr.sc;
        if (result.size() < oce) result.resize(oce, 0);
        uint64_t end = a.sig_off;
        if (end > result.size() && end <= data.size())
            result.insert(result.end(), data.begin() + result.size(), data.begin() + end);
        data = std::move(result);
    }
    return true;
}

bool Signer::deep_sign(const std::filesystem::path &bundle_path, const SignOptions &options) {
    auto ext = bundle_path.extension().string();
    if (ext == ".ipa") {
        auto tmp = std::filesystem::temp_directory_path() / ("ldid-ipa-" + std::to_string(getpid()));
        if (!ArchiveEngine::extract(bundle_path, tmp)) return false;
        auto payload = tmp / "Payload";
        if (std::filesystem::is_directory(payload)) {
            for (auto &e : std::filesystem::directory_iterator(payload)) {
                if (e.is_directory() && e.path().extension() == ".app")
                    deep_sign(e.path(), options);
            }
        }
        std::filesystem::path app_bundle;
        if (std::filesystem::is_directory(payload)) {
            for (auto &e : std::filesystem::directory_iterator(payload)) {
                if (e.is_directory() && e.path().extension() == ".app") { app_bundle = e.path(); break; }
            }
        }
        if (!app_bundle.empty()) {
            auto out_ipa = bundle_path;
            out_ipa.replace_extension(".signed.ipa");
            ArchiveEngine::create_ipa(app_bundle, out_ipa);
        }
        std::filesystem::remove_all(tmp);
        return true;
    }
    if (!std::filesystem::is_directory(bundle_path)) return sign(bundle_path, options);
    struct BundleInfo { std::string path; std::string exec; int depth; };
    std::vector<BundleInfo> bundles;
    std::function<void(const std::filesystem::path &, int)> discover = [&](const std::filesystem::path &dir, int depth) {
        auto ip = dir / "Info.plist";
        if (std::filesystem::exists(ip)) {
            auto exec = ArchiveEngine::find_exec_in_bundle(dir);
            if (exec) bundles.push_back({dir.string(), *exec, depth});
        }
        for (auto &e : std::filesystem::directory_iterator(dir)) {
            if (e.is_directory()) discover(e.path(), depth + 1);
        }
    };
    discover(bundle_path, 0);
    std::sort(bundles.begin(), bundles.end(), [](const BundleInfo &a, const BundleInfo &b) { return a.depth > b.depth; });
    EVP_PKEY *pkey = nullptr; X509 *cert = nullptr; STACK_OF(X509) *ca = nullptr;
    if (!options.key_path.empty()) {
        auto kd = read_file(options.key_path);
        BIO *bio = BIO_new_mem_buf(kd.data(), kd.size());
        if (bio) {
            PKCS12 *p12 = d2i_PKCS12_bio(bio, nullptr);
            BIO_free(bio);
            if (p12) { PKCS12_parse(p12, options.password.c_str(), &pkey, &cert, &ca); PKCS12_free(p12); }
        }
    }
    for (auto &b : bundles) {
        auto sig_dir = std::filesystem::path(b.path) / "_CodeSignature";
        std::filesystem::create_directories(sig_dir);
        auto resources = generate_code_resources(b.path);
        if (!resources.empty()) {
            auto res_path = sig_dir / "CodeResources";
            write_file(res_path, resources);
            auto rsha1 = CryptoEngine::sha1(resources.data(), resources.size());
            auto rsha256 = CryptoEngine::sha256(resources.data(), resources.size());
            SignOptions opts = options;
            sign_single_slice_from_path(std::filesystem::path(b.exec), opts, pkey, cert, ca, &rsha1, &rsha256);
        }
    }
    if (pkey) EVP_PKEY_free(pkey);
    if (cert) X509_free(cert);
    if (ca) sk_X509_pop_free(ca, X509_free);
    return true;
}

bool Signer::sign_single_slice(std::vector<uint8_t> &sd, const SignOptions &options, EVP_PKEY *pkey, X509 *cert, STACK_OF(X509) *ca) {
    return sign_single_slice_impl(sd, options, pkey, cert, ca, nullptr, nullptr);
}

bool Signer::sign_single_slice_impl(std::vector<uint8_t> &sd, const SignOptions &options, EVP_PKEY *pkey, X509 *cert, STACK_OF(X509) *ca, const std::vector<uint8_t> *res_sha1, const std::vector<uint8_t> *res_sha256) {
    auto a = analyze(sd.data(), sd.size(), 0);
    std::string identifier = options.identifier.empty() ? "unknown" : options.identifier;
    std::string ent_xml;
    if (!options.entitlements_path.empty()) {
        auto ed = read_file(options.entitlements_path);
        ent_xml.assign(ed.begin(), ed.end());
    }
    if (options.merge_entitlements && a.has_sig) {
        auto ei = MachOParser::get_signature_info(sd, Slice{0, sd.size(), CPUType::ANY, 0, 0});
        if (ei && !ei->entitlements_xml.empty())
            ent_xml = merge_entitlements(ei->entitlements_xml, ent_xml);
    }
    std::vector<uint8_t> req_blob;
    if (!options.requirements_path.empty()) {
        auto rd = read_file(options.requirements_path);
        req_blob = BlobBuilder::build_requirements_blob(rd);
    }
    uint32_t flags = options.flags;
    if (options.adhoc) flags |= 0x0002;
    std::vector<uint8_t> ent_blob, der_blob;
    plist_t ent_plist = nullptr;
    if (!ent_xml.empty()) {
        ent_blob = BlobBuilder::build_entitlements_blob(ent_xml);
        ent_plist = plist_from_xml_s(ent_xml);
        if (ent_plist) der_blob = BlobBuilder::build_der_entitlements_blob(ent_plist);
    }
    std::unordered_map<uint32_t, std::vector<uint8_t>> sp1, sp2;
    if (!req_blob.empty()) { sp1[2] = CryptoEngine::sha1(req_blob.data(), req_blob.size()); sp2[2] = CryptoEngine::sha256(req_blob.data(), req_blob.size()); }
    if (!ent_blob.empty()) { sp1[5] = CryptoEngine::sha1(ent_blob.data(), ent_blob.size()); sp2[5] = CryptoEngine::sha256(ent_blob.data(), ent_blob.size()); }
    if (!der_blob.empty()) { sp1[7] = CryptoEngine::sha1(der_blob.data(), der_blob.size()); sp2[7] = CryptoEngine::sha256(der_blob.data(), der_blob.size()); }
    if (res_sha1) sp1[3] = *res_sha1;
    if (res_sha256) sp2[3] = *res_sha256;
    uint64_t limit = a.has_sig ? a.sig_off : sd.size();
    if (limit > sd.size()) limit = sd.size();
    uint64_t sig_offset = align_up64(limit, 16);
    uint8_t page_shift = options.page_shift > 0 ? options.page_shift : 12;
    uint64_t page_size = 1ULL << page_shift;
    uint32_t n_pages = (uint32_t)((limit + page_size - 1) / page_size);
    uint64_t exec_seg_flags = 0;
    if (a.hdr.ft == 0x2) exec_seg_flags |= 0x001;
    if (ent_plist) {
        if (plist_dict_bool(ent_plist, "get-task-allow") || plist_dict_bool(ent_plist, "run-unsigned-code")) exec_seg_flags |= 0x010;
        if (plist_dict_bool(ent_plist, "com.apple.private.cs.debugger")) exec_seg_flags |= 0x020;
        if (plist_dict_bool(ent_plist, "dynamic-codesigning")) exec_seg_flags |= 0x040;
        if (plist_dict_bool(ent_plist, "com.apple.private.skip-library-validation")) exec_seg_flags |= 0x080;
        if (plist_dict_bool(ent_plist, "com.apple.private.amfi.can-load-cdhash") || plist_dict_bool(ent_plist, "com.apple.private.amfi.can-execute-cdhash")) exec_seg_flags |= 0x100;
    }
    uint64_t exec_seg_limit = a.exec_end >= a.exec_base ? a.exec_end - a.exec_base : 0;
    std::vector<std::vector<uint8_t>> ph1, ph2;
    ph1.reserve(n_pages);
    ph2.reserve(n_pages);
    for (uint32_t i = 0; i < n_pages; i++) {
        uint64_t start = (uint64_t)i * page_size;
        uint64_t len = std::min(page_size, limit - start);
        std::vector<uint8_t> pd;
        if (start + len <= sd.size()) pd.assign(sd.begin() + start, sd.begin() + start + len);
        else {
            size_t avail = (start < sd.size()) ? sd.size() - start : 0;
            pd.assign(sd.begin() + start, sd.begin() + start + avail);
            pd.resize(len, 0);
        }
        ph1.push_back(CryptoEngine::sha1(pd.data(), pd.size()));
        ph2.push_back(CryptoEngine::sha256(pd.data(), pd.size()));
    }
    bool has_sha1 = options.hash_types.empty() || std::find(options.hash_types.begin(), options.hash_types.end(), HashType::SHA1) != options.hash_types.end();
    bool has_sha256 = options.hash_types.empty() || std::find(options.hash_types.begin(), options.hash_types.end(), HashType::SHA256) != options.hash_types.end();
    std::vector<std::pair<uint32_t, std::vector<uint8_t>>> super_items;
    if (!req_blob.empty()) super_items.push_back({2, req_blob});
    if (!ent_blob.empty()) super_items.push_back({5, ent_blob});
    if (!der_blob.empty()) super_items.push_back({7, der_blob});
    if (has_sha1) {
        auto cd1 = BlobBuilder::build_code_directory(identifier, options.team_id, limit, ph1, sp1, HashType::SHA1, flags, options.platform, page_shift, a.exec_base, exec_seg_limit, exec_seg_flags);
        super_items.push_back({0, cd1});
    }
    if (has_sha256) {
        auto cd2 = BlobBuilder::build_code_directory(identifier, options.team_id, limit, ph2, sp2, HashType::SHA256, flags, options.platform, page_shift, a.exec_base, exec_seg_limit, exec_seg_flags);
        super_items.push_back({has_sha1 ? 0x1000u : 0u, cd2});
    }
    std::vector<uint8_t> cd_for_signing;
    if (has_sha256) cd_for_signing = BlobBuilder::build_code_directory(identifier, options.team_id, limit, ph2, sp2, HashType::SHA256, flags, options.platform, page_shift, a.exec_base, exec_seg_limit, exec_seg_flags);
    else if (has_sha1) cd_for_signing = BlobBuilder::build_code_directory(identifier, options.team_id, limit, ph1, sp1, HashType::SHA1, flags, options.platform, page_shift, a.exec_base, exec_seg_limit, exec_seg_flags);
    if (pkey && cert && !cd_for_signing.empty()) {
        auto pkcs7 = CryptoEngine::sign_pkcs7(pkey, cert, ca, cd_for_signing, options.true_sign);
        if (!pkcs7.empty()) {
            auto wrapper = BlobBuilder::make_blob(0xfade0b01, pkcs7);
            super_items.push_back({0x10000, wrapper});
        }
    }
    auto super_blob = BlobBuilder::build_superblob(0xfade0cc0, super_items);
    std::vector<uint8_t> new_cmds;
    uint32_t new_ncmds = 0, new_sizeofcmds = 0;
    for (auto &cmd : a.cmds) {
        if (cmd.cmd == 0x1d) continue;
        std::vector<uint8_t> cmd_data(sd.begin() + cmd.off, sd.begin() + cmd.off + cmd.sz);
        if (a.has_le && cmd.off == a.le_cmd_off) {
            uint64_t new_end = sig_offset + super_blob.size();
            uint64_t new_fs = new_end - a.le_fileoff;
            uint64_t new_vs = align_up64(new_fs, 4096);
            if (a.le_cmd == 0x19) {
                if (a.hdr.swp) {
                    uint64_t v = swap64(new_vs); memcpy(cmd_data.data() + 32, &v, 8);
                    v = swap64(new_fs); memcpy(cmd_data.data() + 48, &v, 8);
                } else {
                    memcpy(cmd_data.data() + 32, &new_vs, 8);
                    memcpy(cmd_data.data() + 48, &new_fs, 8);
                }
            } else {
                uint32_t v32 = (uint32_t)new_vs, f32 = (uint32_t)new_fs;
                if (a.hdr.swp) { v32 = swap32(v32); f32 = swap32(f32); }
                memcpy(cmd_data.data() + 28, &v32, 4);
                memcpy(cmd_data.data() + 36, &f32, 4);
            }
        }
        new_cmds.insert(new_cmds.end(), cmd_data.begin(), cmd_data.end());
        new_ncmds++; new_sizeofcmds += cmd.sz;
    }
    std::vector<uint8_t> sig_cmd;
    wu32(sig_cmd, 0x1d, a.hdr.swp);
    wu32(sig_cmd, 16, a.hdr.swp);
    wu32(sig_cmd, (uint32_t)sig_offset, a.hdr.swp);
    wu32(sig_cmd, (uint32_t)super_blob.size(), a.hdr.swp);
    new_cmds.insert(new_cmds.end(), sig_cmd.begin(), sig_cmd.end());
    new_ncmds++; new_sizeofcmds += 16;
    uint64_t available = a.content_start - a.hdr.hsz;
    if (new_sizeofcmds > available) return false;
    std::vector<uint8_t> result;
    result.reserve(sig_offset + super_blob.size() + 4096);
    result.insert(result.end(), sd.begin(), sd.begin() + a.hdr.hsz);
    if (a.hdr.swp) {
        uint32_t v = swap32(new_ncmds); memcpy(result.data() + 16, &v, 4);
        v = swap32(new_sizeofcmds); memcpy(result.data() + 20, &v, 4);
    } else {
        memcpy(result.data() + 16, &new_ncmds, 4);
        memcpy(result.data() + 20, &new_sizeofcmds, 4);
    }
    result.insert(result.end(), new_cmds.begin(), new_cmds.end());
    uint64_t cursor = a.hdr.hsz + new_cmds.size();
    uint64_t cmds_end_rel = a.cmds_end;
    if (cursor < cmds_end_rel) { result.resize(result.size() + (cmds_end_rel - cursor), 0); cursor = cmds_end_rel; }
    uint64_t content_start_rel = a.content_start;
    if (content_start_rel > cursor && content_start_rel <= sd.size()) {
        result.insert(result.end(), sd.begin() + cursor, sd.begin() + content_start_rel);
        cursor = content_start_rel;
    }
    uint64_t copy_end = std::min(sig_offset, (uint64_t)sd.size());
    if (copy_end > cursor && cursor < sd.size()) {
        size_t ae = std::min(copy_end, (uint64_t)sd.size());
        if (cursor < ae) result.insert(result.end(), sd.begin() + cursor, sd.begin() + ae);
        cursor = copy_end;
    }
    if (sig_offset > cursor) { result.resize(result.size() + (sig_offset - cursor), 0); cursor = sig_offset; }
    result.insert(result.end(), super_blob.begin(), super_blob.end());
    sd = std::move(result);
    if (ent_plist) plist_free(ent_plist);
    return true;
}

bool Signer::sign_single_slice_from_path(const std::filesystem::path &path, const SignOptions &options, EVP_PKEY *pkey, X509 *cert, STACK_OF(X509) *ca, const std::vector<uint8_t> *res_sha1, const std::vector<uint8_t> *res_sha256) {
    auto data = read_file(path);
    if (data.empty()) return false;
    if (!sign_single_slice_impl(data, options, pkey, cert, ca, res_sha1, res_sha256)) return false;
    return write_file(path, data);
}

std::vector<uint8_t> Signer::generate_code_resources(const std::filesystem::path &bundle_path) {
    std::map<std::string, std::vector<uint8_t>> files_sha1, files_sha256;
    for (auto &e : std::filesystem::recursive_directory_iterator(bundle_path)) {
        if (e.is_directory()) continue;
        auto rel = std::filesystem::relative(e.path(), bundle_path).string();
        if (rel.find("_CodeSignature") == 0) continue;
        auto fd = read_file(e.path());
        files_sha1[rel] = CryptoEngine::sha1(fd.data(), fd.size());
        files_sha256[rel] = CryptoEngine::sha256(fd.data(), fd.size());
    }
    plist_t root = plist_new_dict();
    plist_t files_dict = plist_new_dict();
    plist_t files2_dict = plist_new_dict();
    for (auto &kv : files_sha1)
        plist_dict_set_item(files_dict, kv.first.c_str(), plist_new_data((const char *)kv.second.data(), kv.second.size()));
    for (auto &kv : files_sha256) {
        plist_t entry = plist_new_dict();
        plist_dict_set_item(entry, "hash2", plist_new_data((const char *)kv.second.data(), kv.second.size()));
        plist_dict_set_item(files2_dict, kv.first.c_str(), entry);
    }
    plist_t rules = plist_new_dict();
    plist_dict_set_item(rules, "^.*", plist_new_bool(1));
    plist_dict_set_item(rules, "^.*\\.lproj/", plist_new_dict());
    plist_dict_set_item(rules, "^version\\.plist$", plist_new_bool(1));
    plist_dict_set_item(rules, "^embedded\\.provisionprofile$", plist_new_bool(1));
    plist_dict_set_item(rules, "^Info\\.plist$", plist_new_bool(0));
    plist_dict_set_item(rules, "^PkgInfo$", plist_new_bool(1));
    plist_dict_set_item(rules, "^CodeResources$", plist_new_bool(0));
    plist_dict_set_item(root, "files", files_dict);
    plist_dict_set_item(root, "files2", files2_dict);
    plist_dict_set_item(root, "rules", rules);
    plist_dict_set_item(root, "rules2", plist_copy(rules));
    char *xml = nullptr; uint32_t xml_len = 0;
    plist_to_xml(root, &xml, &xml_len);
    plist_free(root);
    std::vector<uint8_t> result;
    if (xml) { result.assign(xml, xml + xml_len); free(xml); }
    return result;
}

std::string Signer::merge_entitlements(const std::string &existing_xml, const std::string &new_xml) {
    plist_t old_root = plist_from_xml_s(existing_xml);
    plist_t new_root = plist_from_xml_s(new_xml);
    if (!old_root) { if (new_root) plist_free(new_root); return new_xml; }
    if (!new_root) { plist_free(old_root); return existing_xml; }
    if (plist_get_node_type(old_root) != PLIST_DICT || plist_get_node_type(new_root) != PLIST_DICT) {
        plist_free(old_root); plist_free(new_root); return new_xml;
    }
    plist_dict_iter iter = nullptr;
    plist_dict_new_iter(new_root, &iter);
    if (iter) {
        char *key = nullptr; plist_t value = nullptr;
        plist_dict_next_item(new_root, iter, &key, &value);
        while (key) {
            plist_dict_set_item(old_root, key, plist_copy(value));
            free(key); key = nullptr; value = nullptr;
            plist_dict_next_item(new_root, iter, &key, &value);
        }
        free(iter);
    }
    std::string result = plist_xml_str(old_root);
    plist_free(old_root);
    plist_free(new_root);
    return result;
}

void Display::display_signature(const std::filesystem::path &path) {
    auto data = read_file(path);
    if (data.empty()) return;
    auto slices = MachOParser::parse_slices(data);
    for (auto &slice : slices) {
        auto info = MachOParser::get_signature_info(data, slice);
        if (!info) { std::cout << path.string() << ": not signed" << std::endl; continue; }
        std::cout << "Executable=" << path.string() << std::endl;
        std::cout << "Identifier=" << info->identifier << std::endl;
        std::cout << "Format=Mach-O" << std::endl;
        std::cout << "CodeDirectory flags=0x" << std::hex << info->flags << std::dec;
        if (info->flags & 0x0001) std::cout << "(host)";
        if (info->flags & 0x0002) std::cout << "(adhoc)";
        if (info->flags & 0x0100) std::cout << "(hard)";
        if (info->flags & 0x0200) std::cout << "(kill)";
        if (info->flags & 0x0400) std::cout << "(expires)";
        if (info->flags & 0x0800) std::cout << "(restrict)";
        if (info->flags & 0x1000) std::cout << "(enforcement)";
        if (info->flags & 0x2000) std::cout << "(library-validation)";
        if (info->flags & 0x10000) std::cout << "(runtime)";
        if (info->flags & 0x20000) std::cout << "(linker-signed)";
        std::cout << std::endl;
        if (!info->cd_hash_sha1.empty()) {
            std::cout << "CDHash=";
            for (auto b : info->cd_hash_sha1) printf("%02x", b);
            std::cout << std::endl;
        }
        if (!info->cd_hash_sha256.empty()) {
            std::cout << "CDHash(SHA256)=";
            for (auto b : info->cd_hash_sha256) printf("%02x", b);
            std::cout << std::endl;
        }
        std::cout << "TeamIdentifier=" << info->team_id << std::endl;
    }
}

void Display::display_entitlements(const std::filesystem::path &path) {
    auto data = read_file(path);
    if (data.empty()) return;
    auto slices = MachOParser::parse_slices(data);
    for (auto &slice : slices) {
        auto info = MachOParser::get_signature_info(data, slice);
        if (info && !info->entitlements_xml.empty())
            std::cout << info->entitlements_xml << std::endl;
    }
}

void Display::display_requirements(const std::filesystem::path &path) {
    auto data = read_file(path);
    if (data.empty()) return;
    auto slices = MachOParser::parse_slices(data);
    for (auto &slice : slices) {
        auto info = MachOParser::get_signature_info(data, slice);
        if (info && !info->requirements_blob.empty())
            std::cout.write((const char *)info->requirements_blob.data(), info->requirements_blob.size());
    }
}

void Display::display_certificates(const std::filesystem::path &path) {
    auto data = read_file(path);
    if (data.empty()) return;
    auto slices = MachOParser::parse_slices(data);
    for (auto &slice : slices) {
        auto sd = MachOParser::read_slice(data, slice);
        if (sd.empty()) continue;
        auto a = analyze(sd.data(), sd.size(), 0);
        if (!a.has_sig) continue;
        uint64_t so = a.sig_off;
        if (so + 12 > sd.size()) continue;
        uint32_t count = ru32be(sd.data(), so + 8);
        for (uint32_t i = 0; i < count; i++) {
            size_t io = so + 12 + i * 8;
            if (io + 8 > sd.size()) break;
            uint32_t slot = ru32be(sd.data(), io);
            uint32_t rel = ru32be(sd.data(), io + 4);
            if (slot == 0x10000) {
                uint64_t ba = so + rel;
                if (ba + 8 > sd.size()) continue;
                uint32_t blen = ru32be(sd.data(), ba + 4);
                if (ba + blen > sd.size()) continue;
                std::vector<uint8_t> pkcs7(sd.begin() + ba + 8, sd.begin() + ba + blen);
                auto certs = CryptoEngine::extract_certs_from_pkcs7(pkcs7);
                for (size_t j = 0; j < certs.size(); j++) {
                    std::cout << "Certificate " << j << ":" << std::endl;
                    std::cout << "  Size: " << certs[j].size() << " bytes" << std::endl;
                    BIO *b64 = BIO_new(BIO_f_base64());
                    BIO *mem = BIO_new(BIO_s_mem());
                    b64 = BIO_push(b64, mem);
                    BIO_set_flags(b64, BIO_FLAGS_BASE64_NO_NL);
                    BIO_write(b64, certs[j].data(), certs[j].size());
                    BIO_flush(b64);
                    BUF_MEM *bp = nullptr;
                    BIO_get_mem_ptr(b64, &bp);
                    std::string b64s(bp->data, std::min(bp->length, (size_t)64));
                    std::cout << "  Data: " << b64s << "..." << std::endl;
                    BIO_free_all(b64);
                }
            }
        }
    }
}

void Display::print_cdhash(const std::filesystem::path &path) {
    display_signature(path);
}

}

int main(int argc, char *argv[]) {
    OSSL_PROVIDER_load(nullptr, "default");
    OSSL_PROVIDER_load(nullptr, "legacy");
    if (argc < 2) {
        fprintf(stderr, "Link Identity Editor\n");
        fprintf(stderr, "Usage: %s [-Acputype:subtype] [-a] [-C[adhoc|enforcement|expires|hard|\n", argv[0]);
        fprintf(stderr, "host|kill|library-validation|restrict|runtime|linker-signed]] [-D] [-d]\n");
        fprintf(stderr, "[-Enum:file] [-e] [-H[sha1|sha256]] [-h] [-Iname]\n");
        fprintf(stderr, "[-Kkey.p12 [-Upassword]] [-M] [-P[num]] [-Qrequirements.xml] [-q]\n");
        fprintf(stderr, "[-r|-Sfile.xml|-s] [-w] [-u] [-tTeamID] [-arch arch_type] [--true-sign] file ...\n");
        return 0;
    }
    std::vector<std::string> files;
    std::string entitlements_path, requirements_path, key_path, password, identifier, team_id;
    uint32_t flags = 0;
    uint8_t platform = 0;
    bool flag_sign = false, flag_unsign = false, flag_display = false;
    bool flag_ent = false, flag_req = false, flag_cdhash = false;
    bool flag_merge = false, flag_adhoc = false, flag_true_sign = false;
    bool flag_deep = false;
    uint8_t page_shift = 12;
    std::vector<ldid::HashType> hash_types;
    for (int i = 1; i < argc; i++) {
        std::string arg = argv[i];
        if (arg == "--true-sign") { flag_true_sign = true; continue; }
        if (arg == "--deep" || arg == "--super-deep") { flag_deep = true; continue; }
        if (arg.size() >= 2 && arg[0] == '-') {
            char c = arg[1];
            switch (c) {
                case 'S': flag_sign = true; if (arg.size() > 2) entitlements_path = arg.substr(2); break;
                case 's': flag_sign = true; flag_merge = true; break;
                case 'r': flag_unsign = true; break;
                case 'e': flag_ent = true; break;
                case 'q': flag_req = true; break;
                case 'h': flag_cdhash = true; break;
                case 'd': flag_display = true; break;
                case 'w': break;
                case 'M': flag_merge = true; break;
                case 'K': if (arg.size() > 2) key_path = arg.substr(2); break;
                case 'U': if (arg.size() > 2) password = arg.substr(2); break;
                case 'I': if (arg.size() > 2) identifier = arg.substr(2); break;
                case 't': if (arg.size() > 2) team_id = arg.substr(2); break;
                case 'Q': if (arg.size() > 2) requirements_path = arg.substr(2); break;
                case 'P': if (arg.size() > 2) platform = (uint8_t)atoi(arg.c_str() + 2); else platform = 13; break;
                case 'H':
                    if (arg.size() > 2) {
                        std::string alg = arg.substr(2);
                        if (alg == "sha1") hash_types.push_back(ldid::HashType::SHA1);
                        else if (alg == "sha256") hash_types.push_back(ldid::HashType::SHA256);
                        else { hash_types.push_back(ldid::HashType::SHA1); hash_types.push_back(ldid::HashType::SHA256); }
                    }
                    break;
                case 'C':
                    if (arg.size() > 2) {
                        std::string opts = arg.substr(2);
                        std::istringstream iss(opts);
                        std::string token;
                        while (std::getline(iss, token, ',')) {
                            if (token == "host") flags |= 0x0001;
                            else if (token == "adhoc") flags |= 0x0002;
                            else if (token == "hard") flags |= 0x0100;
                            else if (token == "kill") flags |= 0x0200;
                            else if (token == "expires") flags |= 0x0400;
                            else if (token == "restrict") flags |= 0x0800;
                            else if (token == "enforcement") flags |= 0x1000;
                            else if (token == "library-validation") flags |= 0x2000;
                            else if (token == "runtime") flags |= 0x10000;
                            else if (token == "linker-signed") flags |= 0x20000;
                        }
                    }
                    break;
                default: break;
            }
        } else {
            files.push_back(arg);
        }
    }
    for (auto &file : files) {
        std::filesystem::path path(file);
        if (!std::filesystem::exists(path)) {
            fprintf(stderr, "ldid: %s: No such file or directory\n", file.c_str());
            continue;
        }
        if (flag_display) { ldid::Display::display_signature(path); continue; }
        if (flag_ent) { ldid::Display::display_entitlements(path); continue; }
        if (flag_req) { ldid::Display::display_requirements(path); continue; }
        if (flag_cdhash) { ldid::Display::print_cdhash(path); continue; }
        if (flag_unsign) { ldid::Signer::unsign(path); continue; }
        if (flag_sign || !key_path.empty() || flag_deep) {
            ldid::SignOptions options;
            options.identifier = identifier.empty() ? path.filename().string() : identifier;
            options.team_id = team_id;
            options.entitlements_path = entitlements_path;
            options.requirements_path = requirements_path;
            options.key_path = key_path;
            options.password = password;
            options.flags = flags;
            options.platform = (ldid::Platform)platform;
            options.merge_entitlements = flag_merge;
            options.adhoc = flag_adhoc;
            options.true_sign = flag_true_sign;
            options.page_shift = page_shift;
            options.hash_types = hash_types;
            if (flag_deep || std::filesystem::is_directory(path)) {
                ldid::Signer::deep_sign(path, options);
            } else {
                ldid::Signer::sign(path, options);
            }
            auto vr = ldid::Verifier::verify(path);
            if (vr != ldid::Verifier::Result::VALID) {
                if (ldid::Verifier::verify_with_system(path))
                    fprintf(stderr, "ldid: %s: verified by system codesign\n", file.c_str());
            }
        }
    }
    return 0;
}
