#include "ldid.hpp"
#include <cstdlib>
#include <random>
#include <cctype>
#include <cerrno>
#include <climits>
#include <mutex>
#include <curl/curl.h>
#include <openssl/ts.h>
#include <openssl/rand.h>
#include <limits>
#include <openssl/objects.h>
#if defined(__APPLE__)
#include <TargetConditionals.h>
#if TARGET_OS_OSX
#include <Security/Security.h>
#include <CoreFoundation/CoreFoundation.h>
#endif
#endif

namespace ldid {
namespace {

[[maybe_unused]] inline uint16_t swap16(uint16_t v) {
    return static_cast<uint16_t>((v >> 8) | (v << 8));
}

inline uint32_t swap32(uint32_t v) {
    return (v >> 24) | ((v >> 8) & 0x0000FF00) | ((v << 8) & 0x00FF0000) | (v << 24);
}

[[maybe_unused]] inline uint64_t swap64(uint64_t v) {
    return (static_cast<uint64_t>(swap32(static_cast<uint32_t>(v))) << 32) |
           swap32(static_cast<uint32_t>(v >> 32));
}

[[maybe_unused]] inline bool host_is_le() {
    const uint32_t x = 1;
    return *reinterpret_cast<const uint8_t*>(&x) == 1;
}

inline uint64_t align_up64(uint64_t value, uint64_t alignment) {
    if (alignment == 0) return value;
    return ((value + alignment - 1) / alignment) * alignment;
}

inline uint32_t load_le32(const uint8_t* p) {
    uint32_t v;
    std::memcpy(&v, p, sizeof(v));
    return v;
}

inline uint64_t load_le64(const uint8_t* p) {
    uint64_t v;
    std::memcpy(&v, p, sizeof(v));
    return v;
}

inline uint32_t load_be32(const uint8_t* p) {
    return (static_cast<uint32_t>(p[0]) << 24) |
           (static_cast<uint32_t>(p[1]) << 16) |
           (static_cast<uint32_t>(p[2]) << 8) |
           static_cast<uint32_t>(p[3]);
}

inline uint64_t load_be64(const uint8_t* p) {
    return (static_cast<uint64_t>(load_be32(p)) << 32) |
           static_cast<uint64_t>(load_be32(p + 4));
}

inline uint32_t read_u32_file(const uint8_t* p, bool big) {
    return big ? load_be32(p) : load_le32(p);
}

inline uint64_t read_u64_file(const uint8_t* p, bool big) {
    return big ? load_be64(p) : load_le64(p);
}

inline void write_u32_file(uint8_t* p, uint32_t v, bool big) {
    if (big) {
        p[0] = static_cast<uint8_t>(v >> 24);
        p[1] = static_cast<uint8_t>(v >> 16);
        p[2] = static_cast<uint8_t>(v >> 8);
        p[3] = static_cast<uint8_t>(v);
    } else {
        std::memcpy(p, &v, sizeof(v));
    }
}

inline void write_u64_file(uint8_t* p, uint64_t v, bool big) {
    if (big) {
        p[0] = static_cast<uint8_t>(v >> 56);
        p[1] = static_cast<uint8_t>(v >> 48);
        p[2] = static_cast<uint8_t>(v >> 40);
        p[3] = static_cast<uint8_t>(v >> 32);
        p[4] = static_cast<uint8_t>(v >> 24);
        p[5] = static_cast<uint8_t>(v >> 16);
        p[6] = static_cast<uint8_t>(v >> 8);
        p[7] = static_cast<uint8_t>(v);
    } else {
        std::memcpy(p, &v, sizeof(v));
    }
}

inline void append_be32(std::vector<uint8_t>& out, uint32_t v) {
    out.push_back(static_cast<uint8_t>(v >> 24));
    out.push_back(static_cast<uint8_t>(v >> 16));
    out.push_back(static_cast<uint8_t>(v >> 8));
    out.push_back(static_cast<uint8_t>(v));
}

[[maybe_unused]] inline void append_be64(std::vector<uint8_t>& out, uint64_t v) {
    append_be32(out, static_cast<uint32_t>(v >> 32));
    append_be32(out, static_cast<uint32_t>(v & 0xFFFFFFFF));
}

inline std::vector<uint8_t> der_length_bytes(size_t length) {
    std::vector<uint8_t> out;
    if (length < 0x80) {
        out.push_back(static_cast<uint8_t>(length));
        return out;
    }
    std::vector<uint8_t> bytes;
    while (length != 0) {
        bytes.push_back(static_cast<uint8_t>(length & 0xFF));
        length >>= 8;
    }
    out.push_back(static_cast<uint8_t>(0x80 | bytes.size()));
    for (auto it = bytes.rbegin(); it != bytes.rend(); ++it) {
        out.push_back(*it);
    }
    return out;
}

inline std::vector<uint8_t> der_wrap(uint8_t tag, const std::vector<uint8_t>& body) {
    std::vector<uint8_t> out;
    out.push_back(tag);
    auto length = der_length_bytes(body.size());
    out.insert(out.end(), length.begin(), length.end());
    out.insert(out.end(), body.begin(), body.end());
    return out;
}

inline std::vector<uint8_t> der_bool(bool value) {
    return der_wrap(0x01, {static_cast<uint8_t>(value ? 0xFF : 0x00)});
}

inline std::vector<uint8_t> der_utf8(const std::string& value) {
    return der_wrap(0x0C, std::vector<uint8_t>(value.begin(), value.end()));
}

inline std::vector<uint8_t> der_oct(const std::vector<uint8_t>& value) {
    return der_wrap(0x04, value);
}

inline std::vector<uint8_t> der_int(uint64_t value) {
    std::vector<uint8_t> bytes;
    if (value == 0) {
        bytes.push_back(0);
    } else {
        while (value != 0) {
            bytes.push_back(static_cast<uint8_t>(value & 0xFF));
            value >>= 8;
        }
        if (bytes.back() & 0x80) {
            bytes.push_back(0);
        }
        std::reverse(bytes.begin(), bytes.end());
    }
    return der_wrap(0x02, bytes);
}

inline std::vector<uint8_t> der_null() {
    return der_wrap(0x05, {});
}

inline std::vector<uint8_t> der_sequence(const std::vector<std::vector<uint8_t>>& items) {
    std::vector<uint8_t> body;
    for (auto& item : items) {
        body.insert(body.end(), item.begin(), item.end());
    }
    return der_wrap(0x30, body);
}

struct ASN1Node {
    uint8_t tag = 0;
    bool constructed = false;
    std::vector<uint8_t> content;
    std::vector<ASN1Node> children;
};

inline bool asn1_parse_node(const std::vector<uint8_t>& data, size_t& pos, ASN1Node& out) {
    if (pos >= data.size()) return false;
    out.tag = data[pos++];
    out.constructed = (out.tag & 0x20) != 0;
    if (pos >= data.size()) return false;
    uint8_t first = data[pos++];
    size_t length = 0;
    if (first < 0x80) {
        length = first;
    } else {
        size_t count = first & 0x7F;
        if (count == 0 || count > sizeof(size_t) || pos + count > data.size()) return false;
        for (size_t i = 0; i < count; ++i) {
            length = (length << 8) | data[pos++];
        }
    }
    if (pos + length > data.size()) return false;
    out.content.assign(data.begin() + pos, data.begin() + pos + length);
    if (out.constructed) {
        size_t child_pos = 0;
        while (child_pos < out.content.size()) {
            ASN1Node child;
            if (!asn1_parse_node(out.content, child_pos, child)) return false;
            out.children.push_back(child);
        }
    }
    pos += length;
    return true;
}

[[maybe_unused]] inline std::optional<ASN1Node> asn1_decode(const std::vector<uint8_t>& data) {
    size_t pos = 0;
    ASN1Node root;
    if (!asn1_parse_node(data, pos, root)) return std::nullopt;
    return root;
}

inline std::string plist_string_value(plist_t node) {
    if (!node) return {};
    char* raw = nullptr;
    plist_get_string_val(node, &raw);
    if (!raw) return {};
    std::string value = raw;
    free(raw);
    return value;
}

inline std::string plist_key_value(plist_t node) {
    if (!node) return {};
    char* raw = nullptr;
    plist_get_key_val(node, &raw);
    if (!raw) return {};
    std::string value = raw;
    free(raw);
    return value;
}

inline std::vector<uint8_t> plist_xml_bytes(plist_t node) {
    if (!node) return {};
    char* xml = nullptr;
    uint32_t length = 0;
    plist_to_xml(node, &xml, &length);
    if (!xml) return {};
    std::vector<uint8_t> out(xml, xml + length);
    free(xml);
    return out;
}

inline plist_t plist_from_xml_bytes(const std::vector<uint8_t>& xml) {
    if (xml.empty() || xml.size() > std::numeric_limits<uint32_t>::max()) return nullptr;
    plist_t plist = nullptr;
    const char* data = reinterpret_cast<const char*>(xml.data());
    const uint32_t size = static_cast<uint32_t>(xml.size());
    if (xml.size() >= 8 && std::memcmp(data, "bplist00", 8) == 0) {
        plist_from_bin(data, size, &plist);
    } else {
        plist_from_xml(data, size, &plist);
    }
    return plist;
}

inline bool plist_dict_bool(plist_t dict, const char* key) {
    if (!dict) return false;
    plist_t item = plist_dict_get_item(dict, key);
    if (!item) return false;
    uint8_t value = 0;
    plist_get_bool_val(item, &value);
    return value != 0;
}

std::vector<uint8_t> der_encode_plist_node(plist_t node);

inline std::vector<uint8_t> der_encode_plist_dict(plist_t dict) {
    std::vector<std::pair<std::string, std::vector<uint8_t>>> entries;
    plist_dict_iter it = nullptr;
    plist_dict_new_iter(dict, &it);
    if (!it) return der_sequence({});
    for (;;) {
        char* key = nullptr;
        plist_t value = nullptr;
        plist_dict_next_item(dict, it, &key, &value);
        if (!key || !value) {
            free(key);
            break;
        }
        entries.emplace_back(std::string(key), der_encode_plist_node(value));
        free(key);
    }
    std::sort(entries.begin(), entries.end(), [](const auto& a, const auto& b) {
        return a.first < b.first;
    });
    std::vector<uint8_t> body;
    for (auto& entry : entries) {
        auto encoded_key = der_utf8(entry.first);
        body.insert(body.end(), encoded_key.begin(), encoded_key.end());
        body.insert(body.end(), entry.second.begin(), entry.second.end());
    }
    return der_wrap(0x31, body);
}

inline std::vector<uint8_t> der_encode_plist_array(plist_t array) {
    std::vector<uint8_t> body;
    uint32_t size = plist_array_get_size(array);
    for (uint32_t i = 0; i < size; ++i) {
        plist_t item = plist_array_get_item(array, i);
        auto encoded = der_encode_plist_node(item);
        body.insert(body.end(), encoded.begin(), encoded.end());
    }
    return der_wrap(0x30, body);
}

inline std::vector<uint8_t> der_encode_plist_node(plist_t node) {
    if (!node) return der_null();
    switch (plist_get_node_type(node)) {
        case PLIST_BOOLEAN: {
            uint8_t value = 0;
            plist_get_bool_val(node, &value);
            return der_bool(value != 0);
        }
        case PLIST_UINT: {
            uint64_t value = 0;
            plist_get_uint_val(node, &value);
            return der_int(value);
        }
        case PLIST_REAL: {
            double value = 0.0;
            plist_get_real_val(node, &value);
            std::ostringstream os;
            os << value;
            return der_utf8(os.str());
        }
        case PLIST_STRING:
            return der_utf8(plist_string_value(node));
        case PLIST_KEY:
            return der_utf8(plist_key_value(node));
        case PLIST_ARRAY:
            return der_encode_plist_array(node);
        case PLIST_DICT:
            return der_encode_plist_dict(node);
        case PLIST_DATA: {
            char* buffer = nullptr;
            uint64_t length = 0;
            plist_get_data_val(node, &buffer, &length);
            std::vector<uint8_t> value;
            if (buffer) {
                value.assign(buffer, buffer + length);
                free(buffer);
            }
            return der_oct(value);
        }
        case PLIST_DATE: {
            int64_t unix_seconds = 0;
            plist_get_unix_date_val(node, &unix_seconds);
            constexpr int64_t mac_epoch = 978307200;
            if (unix_seconds > (std::numeric_limits<int64_t>::max() / 1000000) ||
                unix_seconds < (std::numeric_limits<int64_t>::min() / 1000000)) {
                return der_null();
            }
            const int64_t value = (unix_seconds - mac_epoch) * 1000000;
            return der_int(static_cast<uint64_t>(value));
        }
        case PLIST_UID: {
            uint64_t value = 0;
            plist_get_uid_val(node, &value);
            return der_int(value);
        }
        default:
            return der_null();
    }
}

inline std::string make_temp_dir() {
    static std::mt19937_64 rng([] {
        std::random_device rd;
        const auto now = std::chrono::steady_clock::now().time_since_epoch().count();
        return static_cast<uint64_t>(rd()) ^ (static_cast<uint64_t>(now) << 1);
    }());
    for (;;) {
        std::ostringstream os;
        os << "ldid-" << std::hex << rng();
        auto path = std::filesystem::temp_directory_path() / os.str();
        std::error_code ec;
        if (std::filesystem::create_directory(path, ec) && !ec) return path.string();
    }
}

inline std::filesystem::path make_unique_temp_path(const std::filesystem::path& target, const char* suffix) {
    static std::mt19937_64 rng([] {
        std::random_device rd;
        const auto now = std::chrono::steady_clock::now().time_since_epoch().count();
        return static_cast<uint64_t>(rd()) ^ (static_cast<uint64_t>(now) << 1);
    }());
    const auto parent = target.parent_path().empty() ? std::filesystem::path(".") : target.parent_path();
    const auto stem = target.filename().string();
    for (;;) {
        std::ostringstream os;
        os << stem << suffix << '-' << std::hex << rng();
        auto candidate = parent / os.str();
        std::error_code ec;
        if (!std::filesystem::exists(candidate, ec) && !ec) return candidate;
    }
}


inline std::string read_c_string(const std::vector<uint8_t>& data, size_t offset) {
    if (offset >= data.size()) return {};
    size_t end = offset;
    while (end < data.size() && data[end] != 0) ++end;
    return std::string(reinterpret_cast<const char*>(data.data() + offset), end - offset);
}

[[maybe_unused]] inline void log_verbose(const std::string& message) {
    const char* enabled = std::getenv("LDID_VERBOSE");
    if (enabled && *enabled != '0') {
        std::cout << message << std::endl;
    }
}

inline std::string hex_encode(const std::vector<uint8_t>& data) {
    static const char* table = "0123456789abcdef";
    std::string out;
    out.reserve(data.size() * 2);
    for (uint8_t byte : data) {
        out.push_back(table[byte >> 4]);
        out.push_back(table[byte & 0x0F]);
    }
    return out;
}

inline std::vector<uint8_t> hex_decode(const std::string& hex) {
    auto value_of = [](char c) -> int {
        if (c >= '0' && c <= '9') return c - '0';
        if (c >= 'a' && c <= 'f') return c - 'a' + 10;
        if (c >= 'A' && c <= 'F') return c - 'A' + 10;
        return -1;
    };
    std::vector<uint8_t> out;
    if (hex.size() % 2 != 0) return out;
    out.reserve(hex.size() / 2);
    for (size_t i = 0; i < hex.size(); i += 2) {
        int high = value_of(hex[i]);
        int low = value_of(hex[i + 1]);
        if (high < 0 || low < 0) return {};
        out.push_back(static_cast<uint8_t>((high << 4) | low));
    }
    return out;
}

struct BioPtr {
    BIO* p;
    explicit BioPtr(BIO* ptr) : p(ptr) {}
    BioPtr(const BioPtr&) = delete;
    BioPtr& operator=(const BioPtr&) = delete;
    BioPtr(BioPtr&& other) noexcept : p(other.p) { other.p = nullptr; }
    BioPtr& operator=(BioPtr&& other) noexcept { if (this != &other) { if (p) BIO_free(p); p = other.p; other.p = nullptr; } return *this; }
    ~BioPtr() { if (p) BIO_free(p); }
    BIO* get() const { return p; }
};

struct PkeyPtr {
    EVP_PKEY* p;
    explicit PkeyPtr(EVP_PKEY* ptr) : p(ptr) {}
    PkeyPtr(const PkeyPtr&) = delete;
    PkeyPtr& operator=(const PkeyPtr&) = delete;
    PkeyPtr(PkeyPtr&& other) noexcept : p(other.p) { other.p = nullptr; }
    PkeyPtr& operator=(PkeyPtr&& other) noexcept { if (this != &other) { if (p) EVP_PKEY_free(p); p = other.p; other.p = nullptr; } return *this; }
    ~PkeyPtr() { if (p) EVP_PKEY_free(p); }
    EVP_PKEY* get() const { return p; }
};

struct X509Ptr {
    X509* p;
    explicit X509Ptr(X509* ptr) : p(ptr) {}
    X509Ptr(const X509Ptr&) = delete;
    X509Ptr& operator=(const X509Ptr&) = delete;
    X509Ptr(X509Ptr&& other) noexcept : p(other.p) { other.p = nullptr; }
    X509Ptr& operator=(X509Ptr&& other) noexcept { if (this != &other) { if (p) X509_free(p); p = other.p; other.p = nullptr; } return *this; }
    ~X509Ptr() { if (p) X509_free(p); }
    X509* get() const { return p; }
};

struct Pkcs7Ptr {
    PKCS7* p;
    explicit Pkcs7Ptr(PKCS7* ptr) : p(ptr) {}
    Pkcs7Ptr(const Pkcs7Ptr&) = delete;
    Pkcs7Ptr& operator=(const Pkcs7Ptr&) = delete;
    Pkcs7Ptr(Pkcs7Ptr&& other) noexcept : p(other.p) { other.p = nullptr; }
    Pkcs7Ptr& operator=(Pkcs7Ptr&& other) noexcept { if (this != &other) { if (p) PKCS7_free(p); p = other.p; other.p = nullptr; } return *this; }
    ~Pkcs7Ptr() { if (p) PKCS7_free(p); }
    PKCS7* get() const { return p; }
};

struct P12Ptr {
    PKCS12* p;
    explicit P12Ptr(PKCS12* ptr) : p(ptr) {}
    P12Ptr(const P12Ptr&) = delete;
    P12Ptr& operator=(const P12Ptr&) = delete;
    P12Ptr(P12Ptr&& other) noexcept : p(other.p) { other.p = nullptr; }
    P12Ptr& operator=(P12Ptr&& other) noexcept { if (this != &other) { if (p) PKCS12_free(p); p = other.p; other.p = nullptr; } return *this; }
    ~P12Ptr() { if (p) PKCS12_free(p); }
    PKCS12* get() const { return p; }
};

struct StackPtr {
    STACK_OF(X509)* p;
    explicit StackPtr(STACK_OF(X509)* ptr) : p(ptr) {}
    StackPtr(const StackPtr&) = delete;
    StackPtr& operator=(const StackPtr&) = delete;
    StackPtr(StackPtr&& other) noexcept : p(other.p) { other.p = nullptr; }
    StackPtr& operator=(StackPtr&& other) noexcept { if (this != &other) { if (p) sk_X509_pop_free(p, X509_free); p = other.p; other.p = nullptr; } return *this; }
    ~StackPtr() { if (p) sk_X509_pop_free(p, X509_free); }
    STACK_OF(X509)* get() const { return p; }
};

}

namespace macho {

constexpr uint32_t MH_MAGIC = 0xfeedface;
constexpr uint32_t MH_CIGAM = 0xcefaedfe;
constexpr uint32_t MH_MAGIC_64 = 0xfeedfacf;
constexpr uint32_t MH_CIGAM_64 = 0xcffaedfe;
constexpr uint32_t FAT_MAGIC = 0xcafebabe;
constexpr uint32_t FAT_CIGAM = 0xbebafeca;
constexpr uint32_t FAT_MAGIC_64 = 0xcafebabf;
constexpr uint32_t FAT_CIGAM_64 = 0xbfbafeca;
constexpr uint32_t LC_SEGMENT = 0x19;
constexpr uint32_t LC_SEGMENT_64 = 0x1;
constexpr uint32_t LC_CODE_SIGNATURE = 0x1d;
constexpr uint32_t SUPERBLOB_MAGIC = 0xfade0cc0;
constexpr uint32_t CODEDIRECTORY_MAGIC = 0xfade0c02;
constexpr uint32_t REQUIREMENTS_MAGIC = 0xfade0c01;
constexpr uint32_t ENTITLEMENTS_MAGIC = 0xfade7171;
constexpr uint32_t DER_ENTITLEMENTS_MAGIC = 0xfade7172;
constexpr uint32_t BLOBWRAPPER_MAGIC = 0xfade0b01;
constexpr uint32_t SLOT_CODEDIRECTORY = 0;
constexpr uint32_t SLOT_REQUIREMENTS = 2;
constexpr uint32_t SLOT_ENTITLEMENTS = 5;
constexpr uint32_t SLOT_DER_ENTITLEMENTS = 7;
constexpr uint32_t SLOT_CMS_SIGNATURE = 0x10000;

struct MachHeaderFields {
    bool valid = false;
    uint32_t magic = 0;
    CPUType cputype = CPUType::ANY;
    uint32_t cpusubtype = 0;
    uint32_t filetype = 0;
    uint32_t ncmds = 0;
    uint32_t sizeofcmds = 0;
    uint32_t flags = 0;
    uint32_t reserved = 0;
    bool is_64 = false;
    bool big = false;
    size_t header_size = 0;
};

struct LoadCommandRef {
    uint32_t cmd = 0;
    uint32_t cmdsize = 0;
    size_t offset = 0;
};

struct MachoAnalysis {
    bool valid = false;
    bool is_fat = false;
    bool is_64 = false;
    bool big = false;
    CPUType cpu_type = CPUType::ANY;
    uint32_t cpu_subtype = 0;
    size_t base = 0;
    size_t load_commands_offset = 0;
    size_t header_end = 0;
    uint32_t ncmds = 0;
    uint32_t sizeofcmds = 0;
    size_t code_signature_offset = 0;
    size_t code_signature_size = 0;
    size_t linkedit_fileoff = 0;
    size_t linkedit_filesize = 0;
    uint64_t exec_seg_base = 0;
    uint64_t exec_seg_limit = 0;
    uint64_t exec_seg_flags = 0;
    bool main_executable = false;
    uint32_t sdk_version = 0;
    uint32_t min_os_version = 0;
};

inline bool is_thin_magic(uint32_t magic) {
    return magic == MH_MAGIC || magic == MH_CIGAM || magic == MH_MAGIC_64 || magic == MH_CIGAM_64;
}

inline bool is_fat_magic(uint32_t magic) {
    return magic == FAT_MAGIC || magic == FAT_CIGAM || magic == FAT_MAGIC_64 || magic == FAT_CIGAM_64;
}

inline MachHeaderFields parse_header(const std::vector<uint8_t>& data, size_t offset = 0) {
    MachHeaderFields fields;
    if (offset + 4 > data.size()) return fields;
    uint32_t magic = load_le32(data.data() + offset);
    if (magic == MH_MAGIC || magic == MH_MAGIC_64) {
        fields.big = false;
        fields.magic = magic;
    } else if (magic == MH_CIGAM || magic == MH_CIGAM_64) {
        fields.big = true;
        fields.magic = swap32(magic);
    } else {
        return fields;
    }
    fields.is_64 = fields.magic == MH_MAGIC_64;
    fields.header_size = fields.is_64 ? 32 : 28;
    if (offset + fields.header_size > data.size()) return fields;
    const uint8_t* p = data.data() + offset;
    fields.cputype = static_cast<CPUType>(read_u32_file(p + 4, fields.big));
    fields.cpusubtype = read_u32_file(p + 8, fields.big);
    fields.filetype = read_u32_file(p + 12, fields.big);
    fields.ncmds = read_u32_file(p + 16, fields.big);
    fields.sizeofcmds = read_u32_file(p + 20, fields.big);
    fields.flags = read_u32_file(p + 24, fields.big);
    if (fields.is_64) {
        fields.reserved = read_u32_file(p + 28, fields.big);
    }
    fields.valid = true;
    return fields;
}

inline std::vector<LoadCommandRef> enumerate_load_commands(const std::vector<uint8_t>& data, const MachHeaderFields& header, size_t base = 0) {
    std::vector<LoadCommandRef> commands;
    if (!header.valid) return commands;
    size_t pos = base + header.header_size;
    for (uint32_t i = 0; i < header.ncmds; ++i) {
        if (pos + 8 > data.size()) break;
        uint32_t cmd = read_u32_file(data.data() + pos, header.big);
        uint32_t cmdsize = read_u32_file(data.data() + pos + 4, header.big);
        if (cmdsize < 8 || pos + cmdsize > data.size()) break;
        commands.push_back({cmd, cmdsize, pos});
        pos += cmdsize;
    }
    return commands;
}

inline MachoAnalysis analyze_thin(const std::vector<uint8_t>& data, size_t base = 0) {
    MachoAnalysis analysis;
    auto header = parse_header(data, base);
    if (!header.valid) return analysis;
    analysis.valid = true;
    analysis.is_fat = false;
    analysis.is_64 = header.is_64;
    analysis.big = header.big;
    analysis.cpu_type = header.cputype;
    analysis.cpu_subtype = header.cpusubtype;
    analysis.base = base;
    analysis.load_commands_offset = base + header.header_size;
    analysis.header_end = analysis.load_commands_offset + header.sizeofcmds;
    analysis.ncmds = header.ncmds;
    analysis.sizeofcmds = header.sizeofcmds;
    analysis.main_executable = header.filetype == 2U;
    bool exec_seg_is_text = false;
    auto commands = enumerate_load_commands(data, header, base);
    for (auto& command : commands) {
        if (command.cmd == 0x32 && command.cmdsize >= 24) {
            analysis.min_os_version = read_u32_file(data.data() + command.offset + 12, header.big);
            analysis.sdk_version = read_u32_file(data.data() + command.offset + 16, header.big);
        }
        if (command.cmd == 0x24 || command.cmd == 0x25 || command.cmd == 0x2F) {
            if (command.cmdsize >= 16) {
                analysis.min_os_version = read_u32_file(data.data() + command.offset + 8, header.big);
                analysis.sdk_version = read_u32_file(data.data() + command.offset + 12, header.big);
            }
        }
        if (command.cmd == LC_CODE_SIGNATURE && command.cmdsize >= 16) {
            analysis.code_signature_offset = base + read_u32_file(data.data() + command.offset + 8, header.big);
            analysis.code_signature_size = read_u32_file(data.data() + command.offset + 12, header.big);
        }
        if (command.cmd == LC_SEGMENT && command.cmdsize >= 56) {
            std::string name = read_c_string(data, command.offset + 8);
            uint64_t vmaddr = read_u32_file(data.data() + command.offset + 24, header.big);
            uint64_t vmsize = read_u32_file(data.data() + command.offset + 28, header.big);
            uint32_t fileoff = read_u32_file(data.data() + command.offset + 32, header.big);
            uint32_t filesize = read_u32_file(data.data() + command.offset + 36, header.big);
            uint32_t initprot = read_u32_file(data.data() + command.offset + 48, header.big);
            if (name == "__LINKEDIT") {
                analysis.linkedit_fileoff = base + fileoff;
                analysis.linkedit_filesize = filesize;
            }
            if ((initprot & 0x4U) != 0) {
                const bool prefer_text = name == "__TEXT";
                if (prefer_text || (!exec_seg_is_text && (analysis.exec_seg_limit == 0 || vmaddr < analysis.exec_seg_base))) {
                    analysis.exec_seg_base = vmaddr;
                    analysis.exec_seg_limit = vmaddr + vmsize;
                    exec_seg_is_text = prefer_text;
                }
            }
        }
        if (command.cmd == LC_SEGMENT_64 && command.cmdsize >= 72) {
            std::string name = read_c_string(data, command.offset + 8);
            uint64_t vmaddr = read_u64_file(data.data() + command.offset + 24, header.big);
            uint64_t vmsize = read_u64_file(data.data() + command.offset + 32, header.big);
            uint64_t fileoff = read_u64_file(data.data() + command.offset + 40, header.big);
            uint64_t filesize = read_u64_file(data.data() + command.offset + 48, header.big);
            uint32_t initprot = read_u32_file(data.data() + command.offset + 60, header.big);
            if (name == "__LINKEDIT") {
                analysis.linkedit_fileoff = base + static_cast<size_t>(fileoff);
                analysis.linkedit_filesize = static_cast<size_t>(filesize);
            }
            if ((initprot & 0x4U) != 0) {
                const bool prefer_text = name == "__TEXT";
                if (prefer_text || (!exec_seg_is_text && (analysis.exec_seg_limit == 0 || vmaddr < analysis.exec_seg_base))) {
                    analysis.exec_seg_base = vmaddr;
                    analysis.exec_seg_limit = vmaddr + vmsize;
                    exec_seg_is_text = prefer_text;
                }
            }
        }
    }
    return analysis;
}

inline bool is_macho_impl(const std::vector<uint8_t>& data) {
    if (data.size() < 4) return false;
    uint32_t le = load_le32(data.data());
    uint32_t be = load_be32(data.data());
    return is_thin_magic(le) || is_fat_magic(be);
}

inline std::vector<Slice> parse_slices_impl(const std::vector<uint8_t>& data) {
    std::vector<Slice> slices;
    if (data.size() < 8) return slices;
    uint32_t magic = load_be32(data.data());
    bool is64 = magic == FAT_MAGIC_64 || magic == FAT_CIGAM_64;
    bool cigam = magic == FAT_CIGAM || magic == FAT_CIGAM_64;
    if (magic == FAT_MAGIC || magic == FAT_CIGAM || magic == FAT_MAGIC_64 || magic == FAT_CIGAM_64) {
        auto load32 = [&](size_t offset) { return cigam ? load_le32(data.data() + offset) : load_be32(data.data() + offset); };
        auto load64 = [&](size_t offset) { return cigam ? load_le64(data.data() + offset) : load_be64(data.data() + offset); };
        uint32_t count = load32(4);
        size_t stride = is64 ? 32 : 20;
        if (count > (data.size() - 8) / stride) return slices;
        size_t pos = 8;
        for (uint32_t i = 0; i < count; ++i) {
            Slice slice;
            slice.cpu_type = static_cast<CPUType>(load32(pos));
            slice.cpu_subtype = load32(pos + 4);
            slice.fat64_container = is64;
            slice.fat_cigam_container = cigam;
            if (is64) {
                slice.offset = load64(pos + 8);
                slice.size = load64(pos + 16);
                slice.align = load32(pos + 24);
            } else {
                slice.offset = load32(pos + 8);
                slice.size = load32(pos + 12);
                slice.align = load32(pos + 16);
            }
            if (slice.offset <= data.size() && slice.size <= data.size() - slice.offset) slices.push_back(slice);
            pos += stride;
        }
        return slices;
    }
    auto header = parse_header(data, 0);
    if (!header.valid) return slices;
    Slice slice;
    slice.offset = 0;
    slice.size = data.size();
    slice.cpu_type = header.cputype;
    slice.cpu_subtype = header.cpusubtype;
    slice.align = 0;
    slices.push_back(slice);
    return slices;
}

inline CPUType cpu_type_from_arch(const std::string& arch, uint32_t& subtype, bool& has_subtype) {
    subtype = 0;
    has_subtype = false;
    auto colon = arch.find(':');
    if (colon != std::string::npos) {
        try {
            uint32_t cpu = static_cast<uint32_t>(std::stoul(arch.substr(0, colon)));
            subtype = static_cast<uint32_t>(std::stoul(arch.substr(colon + 1)));
            has_subtype = true;
            return static_cast<CPUType>(cpu);
        } catch (...) {
            return CPUType::ANY;
        }
    }
    if (arch == "arm64" || arch == "arm64e") return CPUType::ARM64;
    if (arch == "arm64_32") return CPUType::ARM64_32;
    if (arch.rfind("arm", 0) == 0) return CPUType::ARM;
    if (arch == "x86_64" || arch == "x86_64h") return CPUType::X86_64;
    if (arch == "i386" || arch == "x86") return CPUType::X86;
    if (arch == "ppc64") return CPUType::POWERPC64;
    if (arch == "ppc") return CPUType::POWERPC;
    return CPUType::ANY;
}

inline std::vector<uint8_t> select_slice_impl(const std::vector<uint8_t>& data, const std::string& arch) {
    if (arch.empty()) return data;
    auto slices = parse_slices_impl(data);
    if (slices.empty()) return {};
    if (slices.size() == 1 && slices[0].offset == 0 && slices[0].size == data.size()) {
        return data;
    }
    uint32_t subtype = 0;
    bool has_subtype = false;
    CPUType wanted = cpu_type_from_arch(arch, subtype, has_subtype);
    for (auto& slice : slices) {
        if (wanted == CPUType::ANY || slice.cpu_type == wanted) {
            if (!has_subtype || slice.cpu_subtype == subtype) {
                if (slice.offset + slice.size <= data.size()) {
                    return std::vector<uint8_t>(data.begin() + slice.offset, data.begin() + slice.offset + slice.size);
                }
            }
        }
    }
    throw std::invalid_argument("architecture not found");
}

inline std::vector<uint8_t> rebuild_fat_with_format_impl(const std::vector<std::vector<uint8_t>>& slices, bool use64, bool cigam) {
    if (slices.empty()) return {};
    struct FatEntry { CPUType cpu = CPUType::ANY; uint32_t subtype = 0; uint64_t offset = 0; uint64_t size = 0; uint32_t align = 0; };
    std::vector<FatEntry> entries(slices.size());
    for (size_t i = 0; i < slices.size(); ++i) {
        auto header = parse_header(slices[i], 0);
        if (!header.valid) throw std::invalid_argument("invalid Mach-O slice");
        entries[i].cpu = header.cputype;
        entries[i].subtype = header.cpusubtype;
        entries[i].align = (entries[i].cpu == CPUType::ARM64 || entries[i].cpu == CPUType::ARM64_32 || entries[i].cpu == CPUType::POWERPC64) ? 14 : 12;
    }
    auto build = [&](bool fat64) -> std::vector<uint8_t> {
        uint64_t offset = 8ULL + static_cast<uint64_t>(slices.size()) * (fat64 ? 32ULL : 20ULL);
        for (size_t i = 0; i < slices.size(); ++i) {
            entries[i].offset = align_up64(offset, 1ULL << entries[i].align);
            entries[i].size = slices[i].size();
            if (!fat64 && (entries[i].offset > 0xFFFFFFFFULL || entries[i].size > 0xFFFFFFFFULL)) return {};
            offset = entries[i].offset + entries[i].size;
        }
        std::vector<uint8_t> out(static_cast<size_t>(offset), 0);
        auto put32 = [&](size_t pos, uint32_t value) {
            if (cigam) { out[pos]=static_cast<uint8_t>(value); out[pos+1]=static_cast<uint8_t>(value>>8); out[pos+2]=static_cast<uint8_t>(value>>16); out[pos+3]=static_cast<uint8_t>(value>>24); }
            else { out[pos]=static_cast<uint8_t>(value>>24); out[pos+1]=static_cast<uint8_t>(value>>16); out[pos+2]=static_cast<uint8_t>(value>>8); out[pos+3]=static_cast<uint8_t>(value); }
        };
        auto put64 = [&](size_t pos, uint64_t value) {
            if (cigam) { for (size_t j=0;j<8;++j) out[pos+j]=static_cast<uint8_t>(value>>(8*j)); }
            else { out[pos]=static_cast<uint8_t>(value>>56); out[pos+1]=static_cast<uint8_t>(value>>48); out[pos+2]=static_cast<uint8_t>(value>>40); out[pos+3]=static_cast<uint8_t>(value>>32); out[pos+4]=static_cast<uint8_t>(value>>24); out[pos+5]=static_cast<uint8_t>(value>>16); out[pos+6]=static_cast<uint8_t>(value>>8); out[pos+7]=static_cast<uint8_t>(value); }
        };
        uint32_t magic = fat64 ? FAT_MAGIC_64 : FAT_MAGIC;
        put32(0, magic);
        put32(4, static_cast<uint32_t>(slices.size()));
        size_t pos = 8;
        for (const auto& entry : entries) {
            put32(pos, static_cast<uint32_t>(entry.cpu));
            put32(pos+4, entry.subtype);
            if (fat64) { put64(pos+8, entry.offset); put64(pos+16, entry.size); put32(pos+24, static_cast<uint32_t>(entry.align)); put32(pos+28, 0); }
            else { put32(pos+8, static_cast<uint32_t>(entry.offset)); put32(pos+12, static_cast<uint32_t>(entry.size)); put32(pos+16, static_cast<uint32_t>(entry.align)); }
            pos += fat64 ? 32 : 20;
        }
        for (size_t i=0;i<slices.size();++i) std::copy(slices[i].begin(), slices[i].end(), out.begin()+static_cast<size_t>(entries[i].offset));
        return out;
    };
    auto out = build(use64);
    if (out.empty()) throw std::length_error("unable to rebuild universal binary without changing fat format");
    return out;
}

inline std::vector<uint8_t> rebuild_fat_impl(const std::vector<std::vector<uint8_t>>& slices) {
    return rebuild_fat_with_format_impl(slices, false, false);
}

inline bool all_zero(const std::vector<uint8_t>& data, size_t offset, size_t length) {
    if (offset + length > data.size()) return false;
    for (size_t i = 0; i < length; ++i) {
        if (data[offset + i] != 0) return false;
    }
    return true;
}

inline void pad_to(std::vector<uint8_t>& data, size_t target) {
    if (data.size() < target) {
        data.insert(data.end(), target - data.size(), 0);
    }
}

inline void update_linkedit_size(std::vector<uint8_t>& data, const MachHeaderFields& header, size_t linkedit_fileoff) {
    if (linkedit_fileoff > data.size()) return;
    uint64_t filesize = static_cast<uint64_t>(data.size() - linkedit_fileoff);
    uint64_t vmsize = align_up64(filesize, 0x1000);
    auto commands = enumerate_load_commands(data, header, 0);
    for (const auto& command : commands) {
        if (command.cmd == LC_SEGMENT && command.cmdsize >= 56 && read_c_string(data, command.offset + 8) == "__LINKEDIT") {
            write_u32_file(data.data() + command.offset + 36, static_cast<uint32_t>(std::min<uint64_t>(filesize, 0xFFFFFFFFULL)), header.big);
            write_u32_file(data.data() + command.offset + 28, static_cast<uint32_t>(std::min<uint64_t>(vmsize, 0xFFFFFFFFULL)), header.big);
        } else if (command.cmd == LC_SEGMENT_64 && command.cmdsize >= 72 && read_c_string(data, command.offset + 8) == "__LINKEDIT") {
            write_u64_file(data.data() + command.offset + 48, filesize, header.big);
            write_u64_file(data.data() + command.offset + 32, vmsize, header.big);
        }
    }
}

inline std::vector<uint8_t> strip_signature_thin(const std::vector<uint8_t>& data) {
    auto analysis = analyze_thin(data, 0);
    if (!analysis.valid) return data;
    std::vector<uint8_t> out = data;
    auto header = parse_header(out, 0);
    auto commands = enumerate_load_commands(out, header, 0);
    bool removed = false;
    for (auto& command : commands) {
        if (command.cmd != LC_CODE_SIGNATURE) continue;
        size_t next = command.offset + command.cmdsize;
        size_t commands_end = analysis.load_commands_offset + analysis.sizeofcmds;
        if (next < commands_end) {
            std::memmove(out.data() + command.offset, out.data() + next, commands_end - next);
        }
        size_t new_commands_end = commands_end - command.cmdsize;
        if (new_commands_end < commands_end) {
            std::fill(out.begin() + new_commands_end, out.begin() + commands_end, 0);
        }
        write_u32_file(out.data() + 16, header.ncmds - 1, header.big);
        write_u32_file(out.data() + 20, header.sizeofcmds - command.cmdsize, header.big);
        removed = true;
        break;
    }
    if (removed && analysis.code_signature_offset != 0 && analysis.code_signature_size != 0) {
        if (analysis.code_signature_offset + analysis.code_signature_size == out.size()) {
            out.resize(analysis.code_signature_offset);
        } else if (analysis.code_signature_offset + analysis.code_signature_size <= out.size()) {
            std::fill(out.begin() + analysis.code_signature_offset,
                      out.begin() + analysis.code_signature_offset + analysis.code_signature_size,
                      0);
        }
    }
    if (removed) update_linkedit_size(out, header, analysis.linkedit_fileoff);
    return out;
}

inline std::vector<uint8_t> strip_signature_impl(const std::vector<uint8_t>& data) {
    if (data.size() < 8) return data;
    uint32_t be_magic = load_be32(data.data());
    if (is_fat_magic(be_magic)) {
        auto slices = parse_slices_impl(data);
        std::vector<std::vector<uint8_t>> stripped;
        stripped.reserve(slices.size());
        for (auto& slice : slices) {
            std::vector<uint8_t> slice_data(data.begin() + slice.offset, data.begin() + slice.offset + slice.size);
            stripped.push_back(strip_signature_thin(slice_data));
        }
        const bool use64 = be_magic == FAT_MAGIC_64 || be_magic == FAT_CIGAM_64;
        const bool cigam = be_magic == FAT_CIGAM || be_magic == FAT_CIGAM_64;
        return rebuild_fat_with_format_impl(stripped, use64, cigam);
    }
    return strip_signature_thin(data);
}

inline std::vector<uint8_t> embed_signature_thin(const std::vector<uint8_t>& data, const std::vector<uint8_t>& signature) {
    auto analysis = analyze_thin(data, 0);
    if (!analysis.valid) return data;
    std::vector<uint8_t> out = data;
    auto header = parse_header(out, 0);
    auto commands = enumerate_load_commands(out, header, 0);
    const LoadCommandRef* existing = nullptr;
    size_t used_commands = 0;
    size_t max_header = out.size();
    for (auto& command : commands) {
        used_commands += command.cmdsize;
        if (command.cmd == LC_CODE_SIGNATURE) {
            existing = &command;
        }
        if (command.cmd == LC_SEGMENT && command.cmdsize >= 40) {
            uint32_t fileoff = read_u32_file(out.data() + command.offset + 32, header.big);
            if (fileoff > analysis.header_end && fileoff < max_header) max_header = fileoff;
        }
        if (command.cmd == LC_SEGMENT_64 && command.cmdsize >= 56) {
            uint64_t fileoff = read_u64_file(out.data() + command.offset + 40, header.big);
            if (fileoff > analysis.header_end && fileoff < max_header) max_header = static_cast<size_t>(fileoff);
        }
    }
    size_t new_offset = 0;
    size_t new_size = signature.size();
    if (existing) {
        size_t old_offset = read_u32_file(out.data() + existing->offset + 8, header.big);
        size_t old_size = read_u32_file(out.data() + existing->offset + 12, header.big);
        if (old_offset + old_size == out.size()) {
            out.resize(old_offset);
            new_offset = align_up64(out.size(), 16);
            macho::pad_to(out, new_offset);
            out.insert(out.end(), signature.begin(), signature.end());
        } else if (old_offset < out.size() && new_size <= old_size) {
            new_offset = old_offset;
            std::copy(signature.begin(), signature.end(), out.begin() + new_offset);
            if (new_size < old_size) {
                std::fill(out.begin() + new_offset + new_size, out.begin() + new_offset + old_size, 0);
            }
        } else {
            new_offset = align_up64(out.size(), 16);
            macho::pad_to(out, new_offset);
            out.insert(out.end(), signature.begin(), signature.end());
        }
        write_u32_file(out.data() + existing->offset + 8, static_cast<uint32_t>(new_offset), header.big);
        write_u32_file(out.data() + existing->offset + 12, static_cast<uint32_t>(new_size), header.big);
        update_linkedit_size(out, header, analysis.linkedit_fileoff);
        return out;
    }
    size_t insert_pos = analysis.load_commands_offset + used_commands;
    if (insert_pos + 16 > max_header || !macho::all_zero(out, insert_pos, 16)) {
        throw std::runtime_error("no room for LC_CODE_SIGNATURE");
    }
    new_offset = align_up64(out.size(), 16);
    macho::pad_to(out, new_offset);
    out.insert(out.end(), signature.begin(), signature.end());
    write_u32_file(out.data() + insert_pos, LC_CODE_SIGNATURE, header.big);
    write_u32_file(out.data() + insert_pos + 4, 16, header.big);
    write_u32_file(out.data() + insert_pos + 8, static_cast<uint32_t>(new_offset), header.big);
    write_u32_file(out.data() + insert_pos + 12, static_cast<uint32_t>(new_size), header.big);
    write_u32_file(out.data() + 16, header.ncmds + 1, header.big);
    write_u32_file(out.data() + 20, header.sizeofcmds + 8, header.big);
    update_linkedit_size(out, header, analysis.linkedit_fileoff);
    return out;
}

inline std::vector<uint8_t> embed_signature_impl(const std::vector<uint8_t>& data, const std::vector<uint8_t>& signature) {
    if (data.size() < 8) return data;
    uint32_t be_magic = load_be32(data.data());
    if (is_fat_magic(be_magic)) {
        auto slices = parse_slices_impl(data);
        std::vector<std::vector<uint8_t>> signed_slices;
        signed_slices.reserve(slices.size());
        for (auto& slice : slices) {
            std::vector<uint8_t> slice_data(data.begin() + slice.offset, data.begin() + slice.offset + slice.size);
            signed_slices.push_back(embed_signature_thin(slice_data, signature));
        }
        const bool use64 = be_magic == FAT_MAGIC_64 || be_magic == FAT_CIGAM_64;
        const bool cigam = be_magic == FAT_CIGAM || be_magic == FAT_CIGAM_64;
        return rebuild_fat_with_format_impl(signed_slices, use64, cigam);
    }
    return embed_signature_thin(data, signature);
}

inline std::vector<uint8_t> blob_content(const std::vector<uint8_t>& signature, size_t offset) {
    if (offset + 8 > signature.size()) return {};
    uint32_t length = load_be32(signature.data() + offset + 4);
    if (offset + length > signature.size()) return {};
    return std::vector<uint8_t>(signature.begin() + offset + 8, signature.begin() + offset + length);
}

inline std::vector<uint8_t> whole_blob(const std::vector<uint8_t>& signature, size_t offset) {
    if (offset + 8 > signature.size()) return {};
    uint32_t length = load_be32(signature.data() + offset + 4);
    if (offset + length > signature.size()) return {};
    return std::vector<uint8_t>(signature.begin() + offset, signature.begin() + offset + length);
}

inline SignatureInfo get_signature_info_impl(const std::vector<uint8_t>& data) {
    SignatureInfo info;
    std::vector<uint8_t> slice_data = data;
    uint32_t be_magic = data.size() >= 8 ? load_be32(data.data()) : 0;
    if (is_fat_magic(be_magic)) {
        auto slices = parse_slices_impl(data);
        if (slices.empty()) return info;
        auto first = slices.front();
        slice_data.assign(data.begin() + first.offset, data.begin() + first.offset + first.size);
    }
    auto analysis = analyze_thin(slice_data, 0);
    if (!analysis.valid || analysis.code_signature_size == 0) return info;
    if (analysis.code_signature_offset + analysis.code_signature_size > slice_data.size()) return info;
    std::vector<uint8_t> signature(slice_data.begin() + analysis.code_signature_offset,
                                   slice_data.begin() + analysis.code_signature_offset + analysis.code_signature_size);
    if (signature.size() < 12 || load_be32(signature.data()) != SUPERBLOB_MAGIC) return info;
    uint32_t count = load_be32(signature.data() + 8);
    size_t pos = 12;
    for (uint32_t i = 0; i < count; ++i) {
        if (pos + 8 > signature.size()) break;
        uint32_t type = load_be32(signature.data() + pos);
        uint32_t offset = load_be32(signature.data() + pos + 4);
        pos += 8;
        if (offset >= signature.size()) continue;
        if (type == SLOT_CODEDIRECTORY && offset + 8 <= signature.size() && load_be32(signature.data() + offset) == CODEDIRECTORY_MAGIC) {
            auto cd = whole_blob(signature, offset);
            if (cd.size() < 44) continue;
            uint32_t version = load_be32(cd.data() + 8);
            uint32_t flags = load_be32(cd.data() + 12);
            uint32_t ident_offset = load_be32(cd.data() + 20);
            uint8_t hash_type = cd[37];
            info.version = version;
            info.flags = flags;
            info.hash_type = hash_type == 1 ? HashType::SHA1 : (hash_type == 2 ? HashType::SHA256 : (hash_type == 3 ? HashType::SHA256_TRUNCATED : HashType::SHA384));
            info.identifier = read_c_string(cd, ident_offset);
            if (version >= 0x20200 && cd.size() >= 52) {
                uint32_t team_offset = load_be32(cd.data() + 48);
                if (team_offset != 0 && team_offset < cd.size()) {
                    info.team_id = read_c_string(cd, team_offset);
                }
            }
            unsigned char digest[EVP_MAX_MD_SIZE];
            unsigned int digest_length = 0;
            const EVP_MD* md = info.hash_type == HashType::SHA1 ? EVP_sha1() : (info.hash_type == HashType::SHA384 ? EVP_sha384() : EVP_sha256());
            EVP_Digest(cd.data(), cd.size(), digest, &digest_length, md, nullptr);
            size_t cd_hash_length = std::min<size_t>(20, digest_length);
            info.cd_hash.assign(digest, digest + cd_hash_length);
            info.adhoc = (flags & static_cast<uint32_t>(CodeDirectoryFlag::ADHOC)) != 0;
            info.true_sign = false;
        }
        if (type == SLOT_ENTITLEMENTS && offset + 8 <= signature.size() && load_be32(signature.data() + offset) == ENTITLEMENTS_MAGIC) {
            auto content = blob_content(signature, offset);
            info.entitlements_xml.assign(content.begin(), content.end());
        }
        if (type == SLOT_DER_ENTITLEMENTS && offset + 8 <= signature.size() && load_be32(signature.data() + offset) == DER_ENTITLEMENTS_MAGIC) {
            info.entitlements_der = blob_content(signature, offset);
        }
        if (type == SLOT_REQUIREMENTS && offset + 8 <= signature.size() && load_be32(signature.data() + offset) == 0xfade0c01U) {
            info.requirements_blob = whole_blob(signature, offset);
        }
        if (type == SLOT_CMS_SIGNATURE && offset + 8 <= signature.size() && load_be32(signature.data() + offset) == BLOBWRAPPER_MAGIC) {
            info.cms_signature = blob_content(signature, offset);
            info.true_sign = !info.cms_signature.empty();
        }
    }
    return info;
}

}

}
#include "ldid.hpp"
#include <openssl/pem.h>
#include <openssl/objects.h>
#if defined(__APPLE__)
#include <TargetConditionals.h>
#if TARGET_OS_OSX
#include <Security/Security.h>
#include <CoreFoundation/CoreFoundation.h>
#endif
#endif
#include <openssl/asn1.h>
#include <openssl/obj_mac.h>

namespace ldid {

namespace crypto {
std::vector<uint8_t> hash_impl(HashType type, const std::vector<uint8_t>& data);
}

namespace blob {

constexpr uint32_t SUPERBLOB_MAGIC = 0xfade0cc0;
[[maybe_unused]] constexpr uint32_t REQUIREMENTS_SUPERBLOB_MAGIC = 0xfade0c01;
constexpr uint32_t REQUIREMENT_MAGIC = 0xfade0c00;
constexpr uint32_t CODEDIRECTORY_MAGIC = 0xfade0c02;
constexpr uint32_t ENTITLEMENTS_MAGIC = 0xfade7171;
constexpr uint32_t DER_ENTITLEMENTS_MAGIC = 0xfade7172;

inline void put_be32(std::vector<uint8_t>& out, size_t offset, uint32_t value) {
    out[offset + 0] = static_cast<uint8_t>(value >> 24);
    out[offset + 1] = static_cast<uint8_t>(value >> 16);
    out[offset + 2] = static_cast<uint8_t>(value >> 8);
    out[offset + 3] = static_cast<uint8_t>(value);
}

inline void put_be64(std::vector<uint8_t>& out, size_t offset, uint64_t value) {
    out[offset + 0] = static_cast<uint8_t>(value >> 56);
    out[offset + 1] = static_cast<uint8_t>(value >> 48);
    out[offset + 2] = static_cast<uint8_t>(value >> 40);
    out[offset + 3] = static_cast<uint8_t>(value >> 32);
    out[offset + 4] = static_cast<uint8_t>(value >> 24);
    out[offset + 5] = static_cast<uint8_t>(value >> 16);
    out[offset + 6] = static_cast<uint8_t>(value >> 8);
    out[offset + 7] = static_cast<uint8_t>(value);
}

inline void put_u8(std::vector<uint8_t>& out, size_t offset, uint8_t value) {
    out[offset] = value;
}

inline std::vector<uint8_t> make_blob_impl(uint32_t magic, const std::vector<uint8_t>& data) {
    if (data.size() > static_cast<size_t>(std::numeric_limits<uint32_t>::max()) - 8U) {
        throw std::length_error("code-signing blob too large");
    }
    const size_t total = data.size() + 8U;
    std::vector<uint8_t> out;
    out.reserve(total);
    append_be32(out, magic);
    append_be32(out, static_cast<uint32_t>(total));
    out.insert(out.end(), data.begin(), data.end());
    return out;
}

inline std::vector<uint8_t> build_superblob_impl(const std::map<uint32_t, std::vector<uint8_t>>& blobs) {
    size_t count = blobs.size();
    size_t header_size = 12 + 8 * count;
    size_t total = header_size;
    std::vector<std::pair<uint32_t, size_t>> indexes;
    indexes.reserve(count);
    for (auto& entry : blobs) {
        total = align_up64(total, 4);
        indexes.push_back({entry.first, total});
        total += entry.second.size();
    }
    std::vector<uint8_t> out(total, 0);
    put_be32(out, 0, SUPERBLOB_MAGIC);
    put_be32(out, 4, static_cast<uint32_t>(total));
    put_be32(out, 8, static_cast<uint32_t>(count));
    size_t pos = 12;
    size_t index = 0;
    for (auto& entry : blobs) {
        put_be32(out, pos, entry.first);
        put_be32(out, pos + 4, static_cast<uint32_t>(indexes[index].second));
        pos += 8;
        ++index;
    }
    index = 0;
    for (auto& entry : blobs) {
        size_t offset = indexes[index].second;
        std::copy(entry.second.begin(), entry.second.end(), out.begin() + offset);
        ++index;
    }
    return out;
}

struct CodeDirectoryInputs {
    std::vector<uint8_t> code;
    std::string identifier;
    std::string team_id;
    HashType hash_type = HashType::SHA256;
    uint32_t flags = 0;
    uint32_t version = 0x20200;
    uint32_t page_size = 4096;
    Platform platform = Platform::UNKNOWN;
    std::vector<std::vector<uint8_t>> special_slots;
    uint64_t exec_seg_base = 0;
    uint64_t exec_seg_limit = 0;
    uint64_t exec_seg_flags = 0;
    uint32_t runtime_version = 0;
    bool pre_encrypt = false;
};

inline uint8_t page_exponent(uint32_t page_size) {
    uint8_t exponent = 0;
    while (page_size > 1) {
        page_size >>= 1;
        ++exponent;
    }
    return exponent;
}

inline size_t code_directory_header_size(uint32_t version) {
    if (version < 0x20100) return 44;
    if (version < 0x20200) return 48;
    if (version < 0x20300) return 52;
    if (version < 0x20400) return 64;
    if (version < 0x20500) return 88;
    if (version < 0x20600) return 96;
    return 108;
}

inline std::vector<uint8_t> build_code_directory_full(const CodeDirectoryInputs& input) {
    HashType hash_type = input.hash_type == HashType::ANY ? HashType::SHA256 : input.hash_type;
    if (hash_type != HashType::SHA1 && hash_type != HashType::SHA256 && hash_type != HashType::SHA256_TRUNCATED && hash_type != HashType::SHA384) throw std::invalid_argument("unsupported CodeDirectory hash type");
    uint32_t version = std::max<uint32_t>(input.version, 0x20001);
    if (!input.team_id.empty()) version = std::max<uint32_t>(version, 0x20200);
    if (input.exec_seg_base != 0 || input.exec_seg_limit != 0 || input.exec_seg_flags != 0) version = std::max<uint32_t>(version, 0x20400);
    if (input.runtime_version != 0 || input.pre_encrypt) version = std::max<uint32_t>(version, 0x20500);
    if (version > 0x20600) throw std::invalid_argument("unsupported CodeDirectory version");
    size_t hash_size = hash_type == HashType::SHA1 ? 20 : (hash_type == HashType::SHA256_TRUNCATED ? 20 : (hash_type == HashType::SHA256 ? 32 : 48));
    uint8_t hash_type_byte = static_cast<uint8_t>(hash_type);
    uint64_t code_limit = input.code.size();
    uint32_t page_size = input.page_size == 0 ? 4096 : input.page_size;
    if ((page_size & (page_size - 1)) != 0) throw std::invalid_argument("CodeDirectory page size must be a power of two");
    uint8_t page_exp = page_exponent(page_size);
    uint64_t code_slots64 = code_limit == 0 ? 0 : (code_limit + page_size - 1) / page_size;
    if (code_slots64 > std::numeric_limits<uint32_t>::max()) throw std::length_error("too many CodeDirectory code slots");
    uint32_t code_slots = static_cast<uint32_t>(code_slots64);
    uint32_t special_slots = 0;
    for (size_t i = 1; i < input.special_slots.size() && i <= 7; ++i) {
        if (!input.special_slots[i].empty()) special_slots = static_cast<uint32_t>(i);
    }
    size_t header_size = code_directory_header_size(version);
    size_t identifier_size = input.identifier.size() + 1;
    size_t team_size = input.team_id.empty() ? 0 : input.team_id.size() + 1;
    size_t ident_offset = header_size;
    size_t team_offset = input.team_id.empty() ? 0 : ident_offset + identifier_size;
    size_t hashes_start = header_size + identifier_size + team_size;
    size_t hash_offset = hashes_start + static_cast<size_t>(special_slots) * hash_size;
    uint64_t total64 = static_cast<uint64_t>(hashes_start) + (static_cast<uint64_t>(special_slots) + code_slots64) * hash_size;
    if (total64 > std::numeric_limits<uint32_t>::max()) throw std::length_error("CodeDirectory too large");
    size_t total = static_cast<size_t>(total64);
    std::vector<uint8_t> out(total, 0);
    put_be32(out, 0, CODEDIRECTORY_MAGIC);
    put_be32(out, 4, static_cast<uint32_t>(total));
    put_be32(out, 8, version);
    put_be32(out, 12, input.flags);
    put_be32(out, 16, static_cast<uint32_t>(hash_offset));
    put_be32(out, 20, static_cast<uint32_t>(ident_offset));
    put_be32(out, 24, special_slots);
    put_be32(out, 28, code_slots);
    put_be32(out, 32, code_limit > 0xFFFFFFFFULL ? 0xFFFFFFFFU : static_cast<uint32_t>(code_limit));
    put_u8(out, 36, static_cast<uint8_t>(hash_size));
    put_u8(out, 37, hash_type_byte);
    put_u8(out, 38, static_cast<uint8_t>(input.platform));
    put_u8(out, 39, page_exp);
    put_be32(out, 40, 0);
    if (version >= 0x20100) put_be32(out, 44, 0);
    if (version >= 0x20200) put_be32(out, 48, static_cast<uint32_t>(team_offset));
    if (version >= 0x20300) {
        put_be32(out, 52, 0);
        put_be64(out, 56, code_limit);
    }
    if (version >= 0x20400) {
        put_be64(out, 64, input.exec_seg_base);
        put_be64(out, 72, input.exec_seg_limit);
        put_be64(out, 80, input.exec_seg_flags);
    }
    if (version >= 0x20500) {
        put_be32(out, 88, input.runtime_version);
        put_be32(out, 92, 0);
    }
    if (version >= 0x20600) {
        put_u8(out, 96, 0);
        put_u8(out, 97, 0);
        out[98] = 0; out[99] = 0;
        put_be32(out, 100, 0);
        put_be32(out, 104, 0);
    }
    std::copy(input.identifier.begin(), input.identifier.end(), out.begin() + ident_offset);
    out[ident_offset + input.identifier.size()] = 0;
    if (!input.team_id.empty()) {
        std::copy(input.team_id.begin(), input.team_id.end(), out.begin() + team_offset);
        out[team_offset + input.team_id.size()] = 0;
    }
    for (uint32_t slot = 1; slot <= special_slots; ++slot) {
        size_t position = hashes_start + static_cast<size_t>(special_slots - slot) * hash_size;
        if (slot < input.special_slots.size() && !input.special_slots[slot].empty()) {
            auto digest = crypto::hash_impl(hash_type, input.special_slots[slot]);
            if (digest.size() != hash_size) throw std::runtime_error("CodeDirectory special slot digest size mismatch");
            std::copy(digest.begin(), digest.end(), out.begin() + position);
        }
    }
    for (uint64_t page = 0; page < code_slots64; ++page) {
        size_t start = static_cast<size_t>(page * page_size);
        size_t end = std::min(input.code.size(), start + static_cast<size_t>(page_size));
        auto digest = crypto::hash_impl(hash_type, std::vector<uint8_t>(input.code.begin() + start, input.code.begin() + end));
        if (digest.size() != hash_size) throw std::runtime_error("CodeDirectory code digest size mismatch");
        size_t position = hash_offset + static_cast<size_t>(page) * hash_size;
        std::copy(digest.begin(), digest.end(), out.begin() + position);
    }
    return out;
}

inline std::vector<uint8_t> build_code_directory_impl(const std::vector<uint8_t>& code, const std::string& identifier, const std::string& team_id, HashType hash_type, uint32_t flags) {
    CodeDirectoryInputs input;
    input.code = code;
    input.identifier = identifier;
    input.team_id = team_id;
    input.hash_type = hash_type;
    input.flags = flags;
    input.version = 0x20100;
    return build_code_directory_full(input);
}

inline std::vector<uint8_t> build_cd_versioned_impl(const std::vector<uint8_t>& code, const std::string& identifier, const std::string& team_id, HashType hash_type, uint32_t flags, uint32_t version) {
    CodeDirectoryInputs input;
    input.code = code;
    input.identifier = identifier;
    input.team_id = team_id;
    input.hash_type = hash_type;
    input.flags = flags;
    input.version = version;
    return build_code_directory_full(input);
}

inline std::vector<uint8_t> build_entitlements_blob_impl(const std::string& xml) {
    return make_blob_impl(ENTITLEMENTS_MAGIC, std::vector<uint8_t>(xml.begin(), xml.end()));
}

inline std::vector<uint8_t> build_der_entitlements_blob_impl(const std::string& xml) {
    std::vector<uint8_t> xml_bytes(xml.begin(), xml.end());
    plist_t root = plist_from_xml_bytes(xml_bytes);
    if (!root) {
        return make_blob_impl(DER_ENTITLEMENTS_MAGIC, {});
    }
    std::vector<uint8_t> der = der_encode_plist_node(root);
    plist_free(root);
    return make_blob_impl(DER_ENTITLEMENTS_MAGIC, der);
}

inline void append_requirement_string(std::vector<uint8_t>& out, const std::string& value) {
    if (value.size() > std::numeric_limits<uint32_t>::max()) throw std::length_error("requirement string too large");
    append_be32(out, static_cast<uint32_t>(value.size()));
    out.insert(out.end(), value.begin(), value.end());
    while ((out.size() & 3U) != 0) out.push_back(0);
}

inline std::vector<uint8_t> requirement_ident_expression(const std::string& identifier) {
    std::vector<uint8_t> out;
    append_be32(out, 2);
    append_requirement_string(out, identifier);
    return out;
}

inline std::vector<uint8_t> requirement_anchor_expression() {
    std::vector<uint8_t> out;
    append_be32(out, 15);
    return out;
}

inline std::vector<uint8_t> requirement_team_expression(const std::string& team_id) {
    std::vector<uint8_t> out;
    append_be32(out, 11);
    append_be32(out, 0);
    append_requirement_string(out, "subject.OU");
    append_be32(out, 1);
    append_requirement_string(out, team_id);
    return out;
}

inline std::vector<uint8_t> requirement_and_expression(const std::vector<uint8_t>& lhs, const std::vector<uint8_t>& rhs) {
    std::vector<uint8_t> out;
    append_be32(out, 6);
    out.insert(out.end(), lhs.begin(), lhs.end());
    out.insert(out.end(), rhs.begin(), rhs.end());
    return out;
}

inline std::vector<uint8_t> build_dr_impl(const std::string& identifier, const std::string& team_id) {
    if (identifier.empty()) throw std::invalid_argument("designated requirement identifier is empty");
    std::vector<uint8_t> expression = requirement_ident_expression(identifier);
    if (!team_id.empty()) {
        expression = requirement_and_expression(expression, requirement_anchor_expression());
        expression = requirement_and_expression(expression, requirement_team_expression(team_id));
    }
    return make_blob_impl(REQUIREMENT_MAGIC, [&] {
        std::vector<uint8_t> body;
        append_be32(body, 1);
        body.insert(body.end(), expression.begin(), expression.end());
        return body;
    }());
}

inline std::vector<uint8_t> build_requirements_blob_impl(const std::string& identifier, const std::string& team_id) {
    auto designated = build_dr_impl(identifier, team_id);
    std::vector<uint8_t> out;
    append_be32(out, 0xfade0c01U);
    append_be32(out, 20U + static_cast<uint32_t>(designated.size()));
    append_be32(out, 1);
    append_be32(out, 3);
    append_be32(out, 20);
    out.insert(out.end(), designated.begin(), designated.end());
    return out;
}

inline std::string extract_quoted_value(const std::string& text, const std::string& marker) {
    size_t pos = text.find(marker);
    if (pos == std::string::npos) return {};
    size_t first = text.find('\"', pos + marker.size());
    if (first == std::string::npos) return {};
    size_t second = text.find('\"', first + 1);
    if (second == std::string::npos) return {};
    return text.substr(first + 1, second - first - 1);
}

inline std::vector<uint8_t> requirement_match_expression(uint32_t opcode, uint32_t cert_index, const std::string& field, uint32_t match, const std::string& value) {
    std::vector<uint8_t> out;
    append_be32(out, opcode);
    if (opcode == 11) append_be32(out, cert_index);
    append_requirement_string(out, field);
    append_be32(out, match);
    if (match != 0 && match != 14) append_requirement_string(out, value);
    return out;
}

inline std::vector<uint8_t> requirement_cdhash_expression(const std::vector<uint8_t>& hash) {
    if (hash.size() != 20) throw std::invalid_argument("cdhash requirement must contain exactly 20 bytes");
    std::vector<uint8_t> out;
    append_be32(out, 8);
    out.insert(out.end(), hash.begin(), hash.end());
    return out;
}

inline std::vector<uint8_t> requirement_not_expression(const std::vector<uint8_t>& value) {
    std::vector<uint8_t> out;
    append_be32(out, 9);
    out.insert(out.end(), value.begin(), value.end());
    return out;
}

inline std::vector<uint8_t> requirement_or_expression(const std::vector<uint8_t>& lhs, const std::vector<uint8_t>& rhs) {
    std::vector<uint8_t> out;
    append_be32(out, 7);
    out.insert(out.end(), lhs.begin(), lhs.end());
    out.insert(out.end(), rhs.begin(), rhs.end());
    return out;
}

inline std::vector<uint8_t> requirement_info_field_expression(const std::string& key, uint32_t match, const std::string& value) {
    return requirement_match_expression(10, 0, key, match, value);
}

inline std::vector<uint8_t> requirement_entitlement_field_expression(const std::string& key, uint32_t match, const std::string& value) {
    return requirement_match_expression(16, 0, key, match, value);
}

inline uint32_t requirement_cert_index(const std::string& name) {
    if (name == "leaf") return 0;
    if (name == "root" || name == "anchor") return 0xFFFFFFFFU;
    size_t value = 0;
    try {
        value = std::stoul(name);
    } catch (...) {
        throw std::invalid_argument("invalid certificate index in requirement");
    }
    if (value > std::numeric_limits<uint32_t>::max()) throw std::invalid_argument("certificate index out of range");
    return static_cast<uint32_t>(value);
}

inline std::vector<uint8_t> oid_content_from_dotted(const std::string& dotted) {
    std::vector<uint64_t> arcs;
    size_t start = 0;
    while (start <= dotted.size()) {
        size_t end = dotted.find('.', start);
        std::string part = dotted.substr(start, end == std::string::npos ? std::string::npos : end - start);
        if (part.empty()) throw std::invalid_argument("invalid certificate OID");
        uint64_t n = 0;
        for (char c : part) {
            if (c < '0' || c > '9') throw std::invalid_argument("invalid certificate OID");
            n = n * 10 + static_cast<uint64_t>(c - '0');
            if (n > 0xFFFFFFFFULL) throw std::invalid_argument("certificate OID arc too large");
        }
        arcs.push_back(n);
        if (end == std::string::npos) break;
        start = end + 1;
    }
    if (arcs.size() < 2 || arcs[0] > 2 || (arcs[0] < 2 && arcs[1] > 39)) throw std::invalid_argument("invalid certificate OID");
    std::vector<uint8_t> out;
    auto emit_base128 = [&](uint64_t value) {
        uint8_t bytes[10]; size_t n = 0;
        do { bytes[n++] = static_cast<uint8_t>(value & 0x7f); value >>= 7; } while (value != 0);
        while (n != 0) {
            uint8_t b = bytes[--n];
            if (n != 0) b |= 0x80;
            out.push_back(b);
        }
    };
    emit_base128(arcs[0] * 40 + arcs[1]);
    for (size_t i = 2; i < arcs.size(); ++i) emit_base128(arcs[i]);
    return out;
}

class RequirementTextParser {
public:
    explicit RequirementTextParser(const std::string& text) : text_(text) {}

    std::vector<uint8_t> parse() {
        skip();
        auto result = parse_or();
        skip();
        if (pos_ != text_.size()) throw std::invalid_argument("unexpected trailing requirement expression near: " + text_.substr(pos_, std::min<size_t>(32, text_.size() - pos_)));
        return result;
    }

private:
    const std::string& text_;
    size_t pos_ = 0;

    void skip() {
        while (pos_ < text_.size() && std::isspace(static_cast<unsigned char>(text_[pos_]))) ++pos_;
    }
    bool consume_word(const char* word) {
        skip();
        const size_t n = std::strlen(word);
        if (text_.compare(pos_, n, word) != 0) return false;
        if (pos_ + n < text_.size() && (std::isalnum(static_cast<unsigned char>(text_[pos_ + n])) || text_[pos_ + n] == '_' || text_[pos_ + n] == '.')) return false;
        pos_ += n; return true;
    }
    void expect_word(const char* word) {
        if (!consume_word(word)) throw std::invalid_argument(std::string("expected '") + word + "' in requirement");
    }
    std::string quoted() {
        skip();
        if (pos_ >= text_.size() || text_[pos_] != '"') throw std::invalid_argument("expected quoted string in requirement");
        ++pos_;
        std::string out;
        while (pos_ < text_.size()) {
            char c = text_[pos_++];
            if (c == '"') return out;
            if (c == '\\' && pos_ < text_.size()) {
                char e = text_[pos_++];
                if (e == 'n') out.push_back('\n'); else if (e == 'r') out.push_back('\r'); else if (e == 't') out.push_back('\t'); else out.push_back(e);
            } else out.push_back(c);
        }
        throw std::invalid_argument("unterminated quoted string in requirement");
    }
    std::string bracket_field() {
        skip();
        if (pos_ >= text_.size() || text_[pos_] != '[') throw std::invalid_argument("expected '[' in requirement");
        ++pos_; skip();
        std::string out;
        while (pos_ < text_.size() && text_[pos_] != ']') out.push_back(text_[pos_++]);
        if (pos_ >= text_.size()) throw std::invalid_argument("unterminated certificate field in requirement");
        ++pos_;
        while (!out.empty() && std::isspace(static_cast<unsigned char>(out.back()))) out.pop_back();
        return out;
    }
    uint32_t match_operation() {
        skip();
        if (consume_word("exists")) return 0;
        if (consume_word("absent")) return 14;
        if (text_.compare(pos_, 2, "==") == 0 || text_.compare(pos_, 1, "=") == 0) { pos_ += text_.compare(pos_, 2, "==") == 0 ? 2 : 1; return 1; }
        if (text_.compare(pos_, 2, "*=") == 0) { pos_ += 2; return 2; }
        if (text_.compare(pos_, 2, "^=") == 0) { pos_ += 2; return 3; }
        if (text_.compare(pos_, 2, "$=") == 0) { pos_ += 2; return 4; }
        if (text_.compare(pos_, 2, "<=" ) == 0) { pos_ += 2; return 6; }
        if (text_.compare(pos_, 2, ">=" ) == 0) { pos_ += 2; return 8; }
        if (text_.compare(pos_, 1, "<") == 0) { ++pos_; return 5; }
        if (text_.compare(pos_, 1, ">") == 0) { ++pos_; return 7; }
        throw std::invalid_argument("unsupported requirement match operator");
    }
    std::vector<uint8_t> parse_or() {
        auto lhs = parse_and();
        for (;;) {
            size_t save = pos_; if (!consume_word("or")) { pos_ = save; return lhs; }
            auto rhs = parse_and(); lhs = requirement_or_expression(lhs, rhs);
        }
    }
    std::vector<uint8_t> parse_and() {
        auto lhs = parse_unary();
        for (;;) {
            size_t save = pos_; if (!consume_word("and")) { pos_ = save; return lhs; }
            auto rhs = parse_unary(); lhs = requirement_and_expression(lhs, rhs);
        }
    }
    std::vector<uint8_t> parse_unary() {
        skip();
        if (consume_word("not")) return requirement_not_expression(parse_unary());
        if (pos_ < text_.size() && text_[pos_] == '(') { ++pos_; auto e = parse_or(); skip(); if (pos_ >= text_.size() || text_[pos_] != ')') throw std::invalid_argument("unclosed requirement expression"); ++pos_; return e; }
        return parse_atom();
    }
    std::vector<uint8_t> parse_atom() {
        skip();
        if (consume_word("true")) { return std::vector<uint8_t>{0,0,0,1}; }
        if (consume_word("false")) { return std::vector<uint8_t>{0,0,0,0}; }
        if (consume_word("anchor")) {
            if (consume_word("apple")) {
                if (consume_word("generic")) { std::vector<uint8_t> out; append_be32(out, 15); return out; }
                std::vector<uint8_t> out; append_be32(out, 3); return out;
            }
            throw std::invalid_argument("unsupported anchor requirement");
        }
        if (consume_word("identifier")) return requirement_ident_expression(quoted());
        if (consume_word("cdhash")) {
            skip(); size_t begin = pos_; while (pos_ < text_.size() && std::isxdigit(static_cast<unsigned char>(text_[pos_]))) ++pos_;
            auto hash = hex_decode(text_.substr(begin, pos_ - begin)); return requirement_cdhash_expression(hash);
        }
        if (consume_word("info")) {
            std::string field = bracket_field(); uint32_t match = match_operation(); std::string value = match == 0 || match == 14 ? std::string() : quoted();
            return requirement_info_field_expression(field, match, value);
        }
        if (consume_word("entitlement")) {
            std::string field = bracket_field(); uint32_t match = match_operation(); std::string value = match == 0 || match == 14 ? std::string() : quoted();
            return requirement_entitlement_field_expression(field, match, value);
        }
        if (consume_word("platform")) {
            uint32_t match = match_operation(); if (match != 1) throw std::invalid_argument("platform requirement requires equality");
            skip(); size_t begin = pos_; while (pos_ < text_.size() && (std::isalnum(static_cast<unsigned char>(text_[pos_])) || text_[pos_] == '_')) ++pos_;
            std::string name = text_.substr(begin, pos_ - begin); uint32_t platform = 0;
            if (name == "macOS" || name == "macos") platform = 1; else if (name == "iOS" || name == "ios") platform = 2; else if (name == "tvOS" || name == "tvos") platform = 3; else if (name == "watchOS" || name == "watchos") platform = 4; else if (name == "bridgeOS" || name == "bridgeos") platform = 5; else if (name == "macCatalyst" || name == "maccatalyst") platform = 6; else { try { platform = std::stoul(name); } catch (...) { throw std::invalid_argument("unknown platform requirement"); } }
            std::vector<uint8_t> out; append_be32(out, 20); append_be32(out, platform); return out;
        }
        if (consume_word("certificate")) {
            skip(); size_t begin = pos_; while (pos_ < text_.size() && (std::isalnum(static_cast<unsigned char>(text_[pos_])) || text_[pos_] == '_')) ++pos_;
            std::string index_name = text_.substr(begin, pos_ - begin); uint32_t index = requirement_cert_index(index_name); std::string field = bracket_field();
            uint32_t match = match_operation(); std::string value = match == 0 || match == 14 ? std::string() : quoted();
            if (field.rfind("field.", 0) == 0) {
                auto oid = oid_content_from_dotted(field.substr(6)); std::vector<uint8_t> out; append_be32(out, 14); append_be32(out, index); append_requirement_string(out, std::string(reinterpret_cast<const char*>(oid.data()), oid.size())); append_be32(out, match); if (match != 0 && match != 14) append_requirement_string(out, value); return out;
            }
            return requirement_match_expression(11, index, field, match, value);
        }
        throw std::invalid_argument("unsupported requirement expression near: " + text_.substr(pos_, std::min<size_t>(48, text_.size() - pos_)));
    }
};

inline std::vector<uint8_t> compile_requirements_impl(const std::string& text) {
    if (text.size() >= 12 && load_be32(reinterpret_cast<const uint8_t*>(text.data())) == 0xfade0c01U) return std::vector<uint8_t>(text.begin(), text.end());
    if (text.size() >= 8 && load_be32(reinterpret_cast<const uint8_t*>(text.data())) == REQUIREMENT_MAGIC) {
        std::vector<uint8_t> out;
        append_be32(out, 0xfade0c01U);
        append_be32(out, 20U + static_cast<uint32_t>(text.size()));
        append_be32(out, 1); append_be32(out, 3); append_be32(out, 20);
        out.insert(out.end(), text.begin(), text.end());
        return out;
    }
    RequirementTextParser parser(text);
    auto expression = parser.parse();
    std::vector<uint8_t> requirement_body;
    append_be32(requirement_body, 1);
    requirement_body.insert(requirement_body.end(), expression.begin(), expression.end());
    auto requirement = make_blob_impl(REQUIREMENT_MAGIC, requirement_body);
    if (requirement.size() > std::numeric_limits<uint32_t>::max() - 20U) throw std::length_error("requirements blob too large");
    std::vector<uint8_t> out;
    append_be32(out, 0xfade0c01U);
    append_be32(out, 20U + static_cast<uint32_t>(requirement.size()));
    append_be32(out, 1); append_be32(out, 3); append_be32(out, 20);
    out.insert(out.end(), requirement.begin(), requirement.end());
    return out;
}

}

namespace crypto {

inline std::vector<uint8_t> sha1_impl(const std::vector<uint8_t>& data) {
    std::vector<uint8_t> out(20);
    unsigned int length = 0;
    EVP_Digest(data.data(), data.size(), out.data(), &length, EVP_sha1(), nullptr);
    out.resize(length);
    return out;
}

inline std::vector<uint8_t> sha256_impl(const std::vector<uint8_t>& data) {
    std::vector<uint8_t> out(32);
    unsigned int length = 0;
    EVP_Digest(data.data(), data.size(), out.data(), &length, EVP_sha256(), nullptr);
    out.resize(length);
    return out;
}

inline std::vector<uint8_t> sha384_impl(const std::vector<uint8_t>& data) {
    std::vector<uint8_t> out(48);
    unsigned int length = 0;
    EVP_Digest(data.data(), data.size(), out.data(), &length, EVP_sha384(), nullptr);
    out.resize(length);
    return out;
}

inline std::vector<uint8_t> hash_impl(HashType type, const std::vector<uint8_t>& data) {
    if (type == HashType::SHA1) return sha1_impl(data);
    if (type == HashType::SHA384) return sha384_impl(data);
    auto out = sha256_impl(data);
    if (type == HashType::SHA256_TRUNCATED && out.size() > 20) out.resize(20);
    return out;
}

inline std::vector<uint8_t> build_apple_cdhash_attr_impl(const std::vector<uint8_t>& cd_hash, HashType hash_type) {
    std::vector<uint8_t> oid;
    if (hash_type == HashType::SHA1) oid = {0x2B, 0x0E, 0x03, 0x02, 0x1A};
    else if (hash_type == HashType::SHA384) oid = {0x60, 0x86, 0x48, 0x01, 0x65, 0x03, 0x04, 0x02, 0x02};
    else oid = {0x60, 0x86, 0x48, 0x01, 0x65, 0x03, 0x04, 0x02, 0x01};
    return der_sequence({der_wrap(0x06, oid), der_oct(cd_hash)});
}

inline std::vector<uint8_t> build_cdhashes_plist_xml_impl(const std::vector<std::pair<HashType, std::vector<uint8_t>>>& hashes) {
    plist_t root = plist_new_dict();
    plist_t array = plist_new_array();
    if (!root || !array) {
        if (root) plist_free(root);
        if (array) plist_free(array);
        return {};
    }
    for (const auto& item : hashes) {
        auto digest = item.second;
        if (digest.size() > 20) digest.resize(20);
        plist_array_append_item(array, plist_new_data(reinterpret_cast<const char*>(digest.data()), static_cast<uint64_t>(digest.size())));
    }
    plist_dict_set_item(root, "cdhashes", array);
    auto xml = plist_xml_bytes(root);
    plist_free(root);
    if (xml.empty() || xml.back() != '\n') xml.push_back('\n');
    return xml;
}

inline void remove_signing_time_attribute_impl(PKCS7_SIGNER_INFO* signer_info) {
    if (!signer_info || !signer_info->auth_attr) return;
    for (int i = sk_X509_ATTRIBUTE_num(signer_info->auth_attr) - 1; i >= 0; --i) {
        X509_ATTRIBUTE* attribute = sk_X509_ATTRIBUTE_value(signer_info->auth_attr, i);
        ASN1_OBJECT* object = X509_ATTRIBUTE_get0_object(attribute);
        if (object && OBJ_obj2nid(object) == NID_pkcs9_signingTime) {
            attribute = sk_X509_ATTRIBUTE_delete(signer_info->auth_attr, i);
            X509_ATTRIBUTE_free(attribute);
        }
    }
}

inline bool add_apple_cdhash_attributes_impl(PKCS7_SIGNER_INFO* signer_info, const std::vector<std::pair<HashType, std::vector<uint8_t>>>& hashes) {
    if (!signer_info || hashes.empty()) return false;
    int plist_nid = OBJ_txt2nid("1.2.840.113635.100.9.1");
    if (plist_nid == NID_undef) plist_nid = OBJ_create("1.2.840.113635.100.9.1", "appleCdHashes", "Apple Code Directory Hashes");
    int v2_nid = OBJ_txt2nid("1.2.840.113635.100.9.2");
    if (v2_nid == NID_undef) v2_nid = OBJ_create("1.2.840.113635.100.9.2", "appleCdHashes2", "Apple Code Directory Hashes 2");
    if (plist_nid == NID_undef || v2_nid == NID_undef) return false;
    auto plist_xml = build_cdhashes_plist_xml_impl(hashes);
    if (plist_xml.empty()) return false;
    ASN1_OCTET_STRING* plist_value = ASN1_OCTET_STRING_new();
    if (!plist_value) return false;
    if (ASN1_OCTET_STRING_set(plist_value, plist_xml.data(), static_cast<int>(plist_xml.size())) != 1) {
        ASN1_OCTET_STRING_free(plist_value);
        return false;
    }
    if (PKCS7_add_signed_attribute(signer_info, plist_nid, V_ASN1_OCTET_STRING, plist_value) != 1) {
        ASN1_OCTET_STRING_free(plist_value);
        return false;
    }
    std::vector<uint8_t> sequence_body;
    for (const auto& item : hashes) {
        auto sequence = build_apple_cdhash_attr_impl(item.second, item.first);
        if (sequence.size() < 2 || sequence[0] != 0x30) return false;
        size_t length = sequence[1];
        size_t header = 2;
        if ((sequence[1] & 0x80U) != 0) {
            size_t length_octets = sequence[1] & 0x7FU;
            if (length_octets == 0 || length_octets > sizeof(size_t) || 2 + length_octets > sequence.size()) return false;
            length = 0;
            for (size_t i = 0; i < length_octets; ++i) length = (length << 8) | sequence[2 + i];
            header += length_octets;
        }
        if (header + length != sequence.size()) return false;
        sequence_body.insert(sequence_body.end(), sequence.begin() + static_cast<std::ptrdiff_t>(header), sequence.end());
    }
    auto sequence_der = der_wrap(0x30, sequence_body);
    ASN1_STRING* raw = ASN1_STRING_new();
    if (!raw) return false;
    if (ASN1_STRING_set(raw, sequence_der.data(), static_cast<int>(sequence_der.size())) != 1) {
        ASN1_STRING_free(raw);
        return false;
    }
    if (PKCS7_add_signed_attribute(signer_info, v2_nid, V_ASN1_SEQUENCE, raw) != 1) {
        ASN1_STRING_free(raw);
        return false;
    }
    return true;
}

inline X509Ptr load_certificate_der(const std::vector<uint8_t>& der) {
    const unsigned char* p = der.data();
    return X509Ptr(d2i_X509(nullptr, &p, static_cast<long>(der.size())));
}

inline PkeyPtr load_private_key_der(const std::vector<uint8_t>& der) {
    const unsigned char* p = der.data();
    return PkeyPtr(d2i_AutoPrivateKey(nullptr, &p, static_cast<long>(der.size())));
}

inline X509Ptr load_certificate_file(const std::string& path) {
    BioPtr bio(BIO_new_file(path.c_str(), "r"));
    if (!bio.get()) return X509Ptr(nullptr);
    X509* cert = PEM_read_bio_X509(bio.get(), nullptr, nullptr, nullptr);
    if (cert) return X509Ptr(cert);
    BioPtr der_bio(BIO_new_file(path.c_str(), "r"));
    if (!der_bio.get()) return X509Ptr(nullptr);
    return X509Ptr(d2i_X509_bio(der_bio.get(), nullptr));
}

inline PkeyPtr load_private_key_file(const std::string& path, const std::string& password) {
    BioPtr bio(BIO_new_file(path.c_str(), "r"));
    if (!bio.get()) return PkeyPtr(nullptr);
    return PkeyPtr(PEM_read_bio_PrivateKey(bio.get(), nullptr, nullptr, const_cast<char*>(password.c_str())));
}

inline bool load_p12_impl(const std::string& path, const std::string& password, std::vector<uint8_t>& cert_der, std::vector<uint8_t>& key_der) {
    BioPtr bio(BIO_new_file(path.c_str(), "rb"));
    if (!bio.get()) return false;
    P12Ptr p12(d2i_PKCS12_bio(bio.get(), nullptr));
    if (!p12.get()) return false;
    EVP_PKEY* key = nullptr;
    X509* cert = nullptr;
    STACK_OF(X509)* ca = nullptr;
    if (PKCS12_parse(p12.get(), password.c_str(), &key, &cert, &ca) != 1) {
        return false;
    }
    StackPtr ca_ptr(ca);
    X509Ptr cert_ptr(cert);
    PkeyPtr key_ptr(key);
    if (cert_ptr.get()) {
        unsigned char* buffer = nullptr;
        int length = i2d_X509(cert_ptr.get(), &buffer);
        if (length > 0 && buffer) {
            cert_der.assign(buffer, buffer + length);
            OPENSSL_free(buffer);
        }
    }
    if (key_ptr.get()) {
        unsigned char* buffer = nullptr;
        int length = i2d_PrivateKey(key_ptr.get(), &buffer);
        if (length > 0 && buffer) {
            key_der.assign(buffer, buffer + length);
            OPENSSL_free(buffer);
        }
    }
    return !cert_der.empty() && !key_der.empty();
}


struct CurlBuffer {
    std::vector<uint8_t> data;
};

inline size_t curl_write_callback(char* ptr, size_t size, size_t nmemb, void* userdata) {
    auto* buffer = static_cast<CurlBuffer*>(userdata);
    size_t total = size * nmemb;
    buffer->data.insert(buffer->data.end(), reinterpret_cast<uint8_t*>(ptr), reinterpret_cast<uint8_t*>(ptr) + total);
    return total;
}

inline std::vector<uint8_t> make_timestamp_request(const std::vector<uint8_t>& signature, const std::string& policy) {
    TS_REQ* req = TS_REQ_new();
    if (!req) return {};
    bool ok = TS_REQ_set_version(req, 1) == 1;
    TS_MSG_IMPRINT* imprint = nullptr;
    X509_ALGOR* algorithm = nullptr;
    ASN1_INTEGER* nonce = nullptr;
    if (ok) imprint = TS_MSG_IMPRINT_new();
    if (ok && !imprint) ok = false;
    if (ok) algorithm = X509_ALGOR_new();
    if (ok && !algorithm) ok = false;
    if (ok) {
        ASN1_OBJECT* sha256 = OBJ_nid2obj(NID_sha256);
        if (!sha256 || !X509_ALGOR_set0(algorithm, sha256, V_ASN1_NULL, nullptr)) ok = false;
    }
    auto digest = sha256_impl(signature);
    if (ok && TS_MSG_IMPRINT_set_algo(imprint, algorithm) != 1) ok = false;
    if (ok) algorithm = nullptr;
    if (ok && TS_MSG_IMPRINT_set_msg(imprint, digest.data(), static_cast<int>(digest.size())) != 1) ok = false;
    if (ok && TS_REQ_set_msg_imprint(req, imprint) != 1) ok = false;
    if (ok) imprint = nullptr;
    if (ok && !policy.empty()) {
        ASN1_OBJECT* policy_obj = OBJ_txt2obj(policy.c_str(), 1);
        if (!policy_obj || TS_REQ_set_policy_id(req, policy_obj) != 1) ok = false;
        ASN1_OBJECT_free(policy_obj);
    }
    if (ok) {
        unsigned char random_bytes[16];
        nonce = ASN1_INTEGER_new();
        if (!nonce || RAND_bytes(random_bytes, sizeof(random_bytes)) != 1) ok = false;
        if (ok) {
            BIGNUM* bn = BN_bin2bn(random_bytes, sizeof(random_bytes), nullptr);
            if (!bn || !BN_to_ASN1_INTEGER(bn, nonce)) ok = false;
            BN_free(bn);
        }
    }
    if (ok && TS_REQ_set_nonce(req, nonce) != 1) ok = false;
    if (ok && TS_REQ_set_cert_req(req, 1) != 1) ok = false;
    ASN1_INTEGER_free(nonce);
    if (!ok) { X509_ALGOR_free(algorithm); TS_MSG_IMPRINT_free(imprint); TS_REQ_free(req); return {}; }
    unsigned char* der = nullptr;
    int len = i2d_TS_REQ(req, &der);
    TS_REQ_free(req);
    if (len <= 0 || !der) return {};
    std::vector<uint8_t> out(der, der + len);
    OPENSSL_free(der);
    return out;
}

inline std::vector<uint8_t> request_timestamp_token(const std::vector<uint8_t>& signature, const std::string& url, const std::string& policy) {
    if (url.empty()) return {};
    auto request = make_timestamp_request(signature, policy);
    if (request.empty()) return {};
    static std::once_flag curl_once;
    std::call_once(curl_once, [] { curl_global_init(CURL_GLOBAL_DEFAULT); });
    CURL* curl = curl_easy_init();
    if (!curl) return {};
    CurlBuffer response;
    curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
    curl_easy_setopt(curl, CURLOPT_POST, 1L);
    curl_easy_setopt(curl, CURLOPT_POSTFIELDS, request.data());
    curl_easy_setopt(curl, CURLOPT_POSTFIELDSIZE, static_cast<long>(request.size()));
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, curl_write_callback);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &response);
    curl_slist* headers = nullptr;
    headers = curl_slist_append(headers, "Content-Type: application/timestamp-query");
    headers = curl_slist_append(headers, "Accept: application/timestamp-reply");
    curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
    curl_easy_setopt(curl, CURLOPT_TIMEOUT, 30L);
    curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1L);
    CURLcode rc = curl_easy_perform(curl);
    curl_slist_free_all(headers);
    curl_easy_cleanup(curl);
    if (rc != CURLE_OK || response.data.empty()) return {};
    const unsigned char* p = response.data.data();
    TS_RESP* resp = d2i_TS_RESP(nullptr, &p, static_cast<long>(response.data.size()));
    if (!resp) return {};
    PKCS7* token = TS_RESP_get_token(resp);
    if (!token) { TS_RESP_free(resp); return {}; }
    unsigned char* token_der = nullptr;
    int token_len = i2d_PKCS7(token, &token_der);
    TS_RESP_free(resp);
    if (token_len <= 0 || !token_der) return {};
    std::vector<uint8_t> out(token_der, token_der + token_len);
    OPENSSL_free(token_der);
    return out;
}

inline std::vector<uint8_t> sign_pkcs7_detached_impl(const std::vector<uint8_t>& data, const std::vector<std::pair<HashType, std::vector<uint8_t>>>& cd_hashes, const std::string& cert_path, const std::string& key_path, const std::string& password, bool emit_signing_time, bool emit_cdhashes, const std::string& timestamp_url, bool timestamp_required, const std::string& timestamp_policy) {
    if (timestamp_required && timestamp_url.empty()) {
        throw std::invalid_argument("timestamp is required but no timestamp URL was provided");
    }
    X509Ptr cert(nullptr);
    PkeyPtr key(nullptr);
    if (!key_path.empty()) {
        cert = load_certificate_file(cert_path);
        key = load_private_key_file(key_path, password);
    } else {
        std::vector<uint8_t> cert_der;
        std::vector<uint8_t> key_der;
        if (!load_p12_impl(cert_path, password, cert_der, key_der)) return {};
        cert = load_certificate_der(cert_der);
        key = load_private_key_der(key_der);
    }
    if (!cert.get() || !key.get()) return {};
    BioPtr data_bio(BIO_new_mem_buf(data.data(), static_cast<int>(data.size())));
    if (!data_bio.get()) return {};
    int flags = PKCS7_BINARY | PKCS7_DETACHED | PKCS7_NOSMIMECAP | PKCS7_PARTIAL;
    Pkcs7Ptr p7(PKCS7_sign(cert.get(), key.get(), nullptr, data_bio.get(), flags));
    if (!p7.get()) return {};
    auto* signer_infos = PKCS7_get_signer_info(p7.get());
    if (!signer_infos || sk_PKCS7_SIGNER_INFO_num(signer_infos) != 1) return {};
    PKCS7_SIGNER_INFO* signer_info = sk_PKCS7_SIGNER_INFO_value(signer_infos, 0);
    if (!signer_info) return {};
    if (!emit_signing_time) remove_signing_time_attribute_impl(signer_info);
    if (emit_cdhashes && !cd_hashes.empty() && !add_apple_cdhash_attributes_impl(signer_info, cd_hashes)) return {};
    if (BIO_reset(data_bio.get()) != 1) return {};
    if (PKCS7_final(p7.get(), data_bio.get(), PKCS7_BINARY | PKCS7_DETACHED | PKCS7_NOSMIMECAP) != 1) return {};
    if (!timestamp_url.empty()) {
        if (!signer_info->enc_digest) return {};
        const unsigned char* signature_bytes = ASN1_STRING_get0_data(signer_info->enc_digest);
        int signature_length = ASN1_STRING_length(signer_info->enc_digest);
        if (!signature_bytes || signature_length <= 0) return {};
        std::vector<uint8_t> signature_value(signature_bytes, signature_bytes + signature_length);
        auto timestamp_token = request_timestamp_token(signature_value, timestamp_url, timestamp_policy);
        if (timestamp_token.empty()) {
            if (timestamp_required) throw std::runtime_error("timestamp server did not return a valid RFC 3161 token");
        } else {
            int timestamp_nid = OBJ_txt2nid("1.2.840.113549.1.9.16.2.14");
            if (timestamp_nid == NID_undef) timestamp_nid = OBJ_create("1.2.840.113549.1.9.16.2.14", "id-aa-signatureTimeStampToken", "Signature Time-Stamp Token");
            if (timestamp_nid == NID_undef) return {};
            ASN1_STRING* timestamp_value = ASN1_STRING_new();
            if (!timestamp_value) return {};
            bool set_ok = ASN1_STRING_set(timestamp_value, timestamp_token.data(), static_cast<int>(timestamp_token.size())) == 1;
            if (!set_ok || PKCS7_add_attribute(signer_info, timestamp_nid, V_ASN1_SEQUENCE, timestamp_value) != 1) {
                ASN1_STRING_free(timestamp_value);
                return {};
            }
        }
    }
    unsigned char* der = nullptr;
    int length = i2d_PKCS7(p7.get(), &der);
    if (length <= 0 || !der) return {};
    std::vector<uint8_t> out(der, der + length);
    OPENSSL_free(der);
    return out;
}

inline std::vector<uint8_t> sign_pkcs7_impl(const std::vector<uint8_t>& data, const std::string& cert_path, const std::string& key_path, const std::string& password) {
    return sign_pkcs7_detached_impl(data, {}, cert_path, key_path, password, true, false, {}, false, {});
}

inline bool verify_pkcs7_impl(const std::vector<uint8_t>& data, const std::vector<uint8_t>& signature) {
    const unsigned char* p = signature.data();
    Pkcs7Ptr p7(d2i_PKCS7(nullptr, &p, static_cast<long>(signature.size())));
    if (!p7.get()) return false;
    BioPtr data_bio(BIO_new_mem_buf(data.data(), static_cast<int>(data.size())));
    if (!data_bio.get()) return false;
    X509_STORE* store = X509_STORE_new();
    if (!store) return false;
    int result = PKCS7_verify(p7.get(), nullptr, store, data_bio.get(), nullptr, PKCS7_NOVERIFY | PKCS7_NOCHAIN);
    X509_STORE_free(store);
    return result == 1;
}

inline std::vector<std::vector<uint8_t>> extract_certs_raw_impl(const std::string& cert_path) {
    std::vector<std::vector<uint8_t>> out;
    BioPtr bio(BIO_new_file(cert_path.c_str(), "r"));
    if (!bio.get()) return out;
    for (;;) {
        X509* cert = PEM_read_bio_X509(bio.get(), nullptr, nullptr, nullptr);
        if (!cert) break;
        X509Ptr cert_ptr(cert);
        unsigned char* buffer = nullptr;
        int length = i2d_X509(cert_ptr.get(), &buffer);
        if (length > 0 && buffer) {
            out.emplace_back(buffer, buffer + length);
            OPENSSL_free(buffer);
        }
    }
    if (out.empty()) {
        BioPtr der_bio(BIO_new_file(cert_path.c_str(), "r"));
        if (der_bio.get()) {
            X509Ptr cert(d2i_X509_bio(der_bio.get(), nullptr));
            if (cert.get()) {
                unsigned char* buffer = nullptr;
                int length = i2d_X509(cert.get(), &buffer);
                if (length > 0 && buffer) {
                    out.emplace_back(buffer, buffer + length);
                    OPENSSL_free(buffer);
                }
            }
        }
    }
    if (out.empty()) {
        std::vector<uint8_t> cert_der;
        std::vector<uint8_t> key_der;
        if (load_p12_impl(cert_path, "", cert_der, key_der)) {
            out.push_back(cert_der);
        }
    }
    return out;
}

inline std::string extract_team_id_from_certificate_der_impl(const std::vector<uint8_t>& der) {
    X509Ptr cert = load_certificate_der(der);
    if (!cert.get()) return {};
    char buffer[256] = {0};
    int length = X509_NAME_get_text_by_NID(X509_get_subject_name(cert.get()), NID_organizationalUnitName, buffer, sizeof(buffer));
    if (length < 0) return {};
    return std::string(buffer, static_cast<size_t>(length));
}

inline std::string extract_team_id_from_certificate_file_impl(const std::string& cert_path) {
    X509Ptr cert = load_certificate_file(cert_path);
    if (!cert.get()) return {};
    char buffer[256] = {0};
    int length = X509_NAME_get_text_by_NID(X509_get_subject_name(cert.get()), NID_organizationalUnitName, buffer, sizeof(buffer));
    if (length < 0) return {};
    return std::string(buffer, static_cast<size_t>(length));
}

inline std::string extract_team_id_from_p12_impl(const std::string& p12_path, const std::string& password) {
    std::vector<uint8_t> cert_der;
    std::vector<uint8_t> key_der;
    if (!load_p12_impl(p12_path, password, cert_der, key_der)) return {};
    return extract_team_id_from_certificate_der_impl(cert_der);
}

inline std::vector<uint8_t> get_public_key_hash_impl(const std::string& cert_path) {
    X509Ptr cert = load_certificate_file(cert_path);
    if (!cert.get()) return {};
    unsigned char digest[EVP_MAX_MD_SIZE];
    unsigned int length = 0;
    if (X509_pubkey_digest(cert.get(), EVP_sha256(), digest, &length) != 1) return {};
    return std::vector<uint8_t>(digest, digest + length);
}

}

}
namespace ldid {

namespace signer {
void sign_file_impl(const std::filesystem::path& path, const SignOptions& options);
std::vector<uint8_t> sign_macho_memory_impl(const std::vector<uint8_t>& data, const SignOptions& options, const std::filesystem::path& source_path = {}, const std::vector<std::vector<uint8_t>>& extra_special_slots = {});
ArchiveSignPlan build_sign_plan_impl(const std::filesystem::path& dir);
void sign_plan_impl(const ArchiveSignPlan& plan, const SignOptions& options);
}

namespace archive {

struct ArchiveReader {
    ::archive* handle;
    ArchiveReader() {
        handle = archive_read_new();
        if (handle) {
            archive_read_support_format_all(handle);
            archive_read_support_filter_all(handle);
        }
    }
    ~ArchiveReader() {
        if (handle) archive_read_free(handle);
    }
};

struct ArchiveWriter {
    ::archive* handle;
    ArchiveWriter() {
        handle = archive_write_new();
    }
    ~ArchiveWriter() {
        if (handle) archive_write_free(handle);
    }
};

inline std::string sanitize_relative_path(const std::string& raw) {
    std::filesystem::path input(raw);
    std::filesystem::path out;
    for (const auto& part : input) {
        if (part == ".." || part == "." || part == "/") continue;
        out /= part;
    }
    return out.generic_string();
}

inline bool is_archive_impl(const std::filesystem::path& path) {
    ArchiveReader reader;
    if (!reader.handle) return false;
    if (archive_read_open_filename(reader.handle, path.string().c_str(), 10240) != ARCHIVE_OK) return false;
    ::archive_entry* entry = nullptr;
    return archive_read_next_header(reader.handle, &entry) == ARCHIVE_OK;
}

inline ArchiveFormat detect_format_impl(const std::filesystem::path& path) {
    auto extension = path.extension().string();
    std::transform(extension.begin(), extension.end(), extension.begin(), [](unsigned char c) {
        return static_cast<char>(std::tolower(c));
    });
    if (extension == ".ipa") return ArchiveFormat::IPA;
    if (extension == ".zip") return ArchiveFormat::ZIP;
    if (extension == ".tar" || extension == ".tgz" || extension == ".gz") return ArchiveFormat::TAR;
    if (is_archive_impl(path)) return ArchiveFormat::ZIP;
    return ArchiveFormat::UNKNOWN;
}

inline std::vector<ArchiveEntryInfo> list_contents_impl(const std::filesystem::path& path) {
    std::vector<ArchiveEntryInfo> entries;
    ArchiveReader reader;
    if (!reader.handle) return entries;
    if (archive_read_open_filename(reader.handle, path.string().c_str(), 10240) != ARCHIVE_OK) return entries;
    for (;;) {
        ::archive_entry* entry = nullptr;
        int result = archive_read_next_header(reader.handle, &entry);
        if (result != ARCHIVE_OK) break;
        ArchiveEntryInfo info;
        const char* name = archive_entry_pathname(entry);
        info.path = name ? name : "";
        int64_t size = archive_entry_size(entry);
        info.size = size < 0 ? 0 : static_cast<uint64_t>(size);
        mode_t type = archive_entry_filetype(entry);
        info.is_directory = (type == AE_IFDIR);
        info.is_symlink = (type == AE_IFLNK);
        info.is_executable = false;
        info.is_signable = false;
        entries.push_back(info);
    }
    return entries;
}

inline void extract_archive_impl(const std::filesystem::path& archive_path, const std::filesystem::path& out_dir) {
    std::filesystem::create_directories(out_dir);
    ArchiveReader reader;
    if (!reader.handle) throw std::runtime_error("archive reader allocation failed");
    if (archive_read_open_filename(reader.handle, archive_path.string().c_str(), 10240) != ARCHIVE_OK) {
        throw std::runtime_error("archive open failed");
    }
    for (;;) {
        ::archive_entry* entry = nullptr;
        int result = archive_read_next_header(reader.handle, &entry);
        if (result == ARCHIVE_EOF) break;
        if (result != ARCHIVE_OK) throw std::runtime_error("archive read failed");
        const char* raw_name = archive_entry_pathname(entry);
        std::string safe_name = sanitize_relative_path(raw_name ? raw_name : "");
        if (safe_name.empty()) continue;
        std::filesystem::path full_path = out_dir / safe_name;
        archive_entry_set_pathname(entry, full_path.string().c_str());
        int extract_result = archive_read_extract(reader.handle, entry, ARCHIVE_EXTRACT_TIME | ARCHIVE_EXTRACT_PERM | ARCHIVE_EXTRACT_UNLINK);
        if (extract_result != ARCHIVE_OK && extract_result != ARCHIVE_WARN) {
            throw std::runtime_error("archive extract failed");
        }
    }
}

inline void configure_write_format_impl(::archive* handle, ArchiveFormat format) {
    if (format == ArchiveFormat::ZIP || format == ArchiveFormat::IPA) {
        archive_write_set_format_zip(handle);
    } else {
        archive_write_set_format_pax(handle);
    }
}

inline void add_directory_recursive_impl(const std::filesystem::path& dir, ::archive* handle) {
    for (auto iterator = std::filesystem::recursive_directory_iterator(dir, std::filesystem::directory_options::skip_permission_denied);
         iterator != std::filesystem::recursive_directory_iterator();
         ++iterator) {
        auto& item = *iterator;
        std::string relative = std::filesystem::relative(item.path(), dir).generic_string();
        if (relative.empty()) continue;
        ::archive_entry* entry = archive_entry_new();
        if (!entry) continue;
        archive_entry_set_pathname(entry, relative.c_str());
        auto status = std::filesystem::symlink_status(item.path());
        if (std::filesystem::is_symlink(status)) {
            archive_entry_set_filetype(entry, AE_IFLNK);
            archive_entry_set_perm(entry, 0777);
            std::filesystem::path target = std::filesystem::read_symlink(item.path());
            archive_entry_set_symlink(entry, target.generic_string().c_str());
        } else if (std::filesystem::is_directory(status)) {
            archive_entry_set_filetype(entry, AE_IFDIR);
            archive_entry_set_perm(entry, 0755);
        } else if (std::filesystem::is_regular_file(status)) {
            archive_entry_set_filetype(entry, AE_IFREG);
            auto permissions = std::filesystem::status(item.path()).permissions();
            bool executable = (permissions & std::filesystem::perms::owner_exec) != std::filesystem::perms::none;
            archive_entry_set_perm(entry, executable ? 0755 : 0644);
            archive_entry_set_size(entry, static_cast<int64_t>(std::filesystem::file_size(item.path())));
        } else {
            archive_entry_free(entry);
            continue;
        }
        if (archive_write_header(handle, entry) != ARCHIVE_OK) {
            archive_entry_free(entry);
            continue;
        }
        if (std::filesystem::is_regular_file(status)) {
            std::ifstream input(item.path(), std::ios::binary);
            std::vector<char> buffer(65536);
            while (input.read(buffer.data(), static_cast<std::streamsize>(buffer.size()))) {
                archive_write_data(handle, buffer.data(), static_cast<size_t>(input.gcount()));
            }
            if (input.gcount() > 0) {
                archive_write_data(handle, buffer.data(), static_cast<size_t>(input.gcount()));
            }
        }
        archive_entry_free(entry);
    }
}

inline void create_archive_impl(const std::filesystem::path& dir, const std::filesystem::path& out, ArchiveFormat format) {
    if (out.has_parent_path()) {
        std::filesystem::create_directories(out.parent_path());
    }
    ArchiveWriter writer;
    if (!writer.handle) throw std::runtime_error("archive writer allocation failed");
    configure_write_format_impl(writer.handle, format);
    if (archive_write_open_filename(writer.handle, out.string().c_str()) != ARCHIVE_OK) {
        throw std::runtime_error("archive write open failed");
    }
    add_directory_recursive_impl(dir, writer.handle);
}

inline void create_ipa_impl(const std::filesystem::path& dir, const std::filesystem::path& out) {
    create_archive_impl(dir, out, ArchiveFormat::IPA);
}

inline void create_zip_impl(const std::filesystem::path& dir, const std::filesystem::path& out) {
    create_archive_impl(dir, out, ArchiveFormat::ZIP);
}

inline void create_tar_impl(const std::filesystem::path& dir, const std::filesystem::path& out) {
    create_archive_impl(dir, out, ArchiveFormat::TAR);
}

inline void extract_ipa_impl(const std::filesystem::path& ipa, const std::filesystem::path& dir) {
    extract_archive_impl(ipa, dir);
}

inline void repack_ipa_impl(const std::filesystem::path& dir, const std::filesystem::path& out) {
    create_archive_impl(dir, out, ArchiveFormat::IPA);
}

inline bool is_signable_bundle_extension(const std::filesystem::path& path) {
    auto extension = path.extension().string();
    std::transform(extension.begin(), extension.end(), extension.begin(), [](unsigned char c) {
        return static_cast<char>(std::tolower(c));
    });
    return extension == ".app" || extension == ".framework" ||
           extension == ".xpc" || extension == ".appex" || extension == ".kext" ||
           extension == ".plugin";
}

inline bool is_macho_file_impl(const std::filesystem::path& path) {
    std::ifstream input(path, std::ios::binary);
    if (!input) return false;
    std::vector<uint8_t> head(8);
    input.read(reinterpret_cast<char*>(head.data()), static_cast<std::streamsize>(head.size()));
    auto count = input.gcount();
    if (count < 4) return false;
    head.resize(static_cast<size_t>(count));
    return macho::is_macho_impl(head);
}

inline std::filesystem::path find_app_bundle_impl(const std::filesystem::path& dir) {
    if (!std::filesystem::exists(dir)) return {};
    for (auto iterator = std::filesystem::recursive_directory_iterator(dir, std::filesystem::directory_options::skip_permission_denied);
         iterator != std::filesystem::recursive_directory_iterator();
         ++iterator) {
        if (iterator->is_directory() && iterator->path().extension() == ".app") {
            return iterator->path();
        }
    }
    return {};
}

inline std::filesystem::path find_executable_in_bundle_impl(const std::filesystem::path& bundle) {
    std::filesystem::path info_plist = bundle / "Info.plist";
    if (std::filesystem::exists(info_plist)) {
        std::ifstream input(info_plist, std::ios::binary);
        std::vector<uint8_t> data((std::istreambuf_iterator<char>(input)), std::istreambuf_iterator<char>());
        plist_t root = plist_from_xml_bytes(data);
        if (root) {
            plist_t item = plist_dict_get_item(root, "CFBundleExecutable");
            if (item) {
                char* raw = nullptr;
                plist_get_string_val(item, &raw);
                if (raw) {
                    std::string executable_name = raw;
                    free(raw);
                    std::filesystem::path candidate = bundle / executable_name;
                    if (std::filesystem::exists(candidate)) {
                        plist_free(root);
                        return candidate;
                    }
                }
            }
            plist_free(root);
        }
    }
    std::string fallback = bundle.stem().string();
    if (!fallback.empty()) {
        std::filesystem::path candidate = bundle / fallback;
        if (std::filesystem::exists(candidate)) return candidate;
    }
    for (auto& item : std::filesystem::directory_iterator(bundle)) {
        if (item.is_regular_file()) {
            auto permissions = item.status().permissions();
            if ((permissions & std::filesystem::perms::owner_exec) != std::filesystem::perms::none) {
                return item.path();
            }
        }
    }
    return {};
}

inline bool path_is_under(const std::filesystem::path& child, const std::filesystem::path& root) {
    auto child_string = child.lexically_normal().generic_string();
    auto root_string = root.lexically_normal().generic_string();
    if (child_string == root_string) return true;
    if (root_string.empty()) return false;
    if (root_string.back() != '/') root_string.push_back('/');
    return child_string.rfind(root_string, 0) == 0;
}

inline std::vector<ArchiveEntryInfo> scan_for_signables_impl(const std::filesystem::path& dir) {
    std::vector<ArchiveEntryInfo> result;
    if (!std::filesystem::exists(dir)) return result;
    std::vector<std::filesystem::path> candidates;
    for (auto iterator = std::filesystem::recursive_directory_iterator(dir, std::filesystem::directory_options::skip_permission_denied);
         iterator != std::filesystem::recursive_directory_iterator();
         ++iterator) {
        if (iterator->is_directory() && is_signable_bundle_extension(iterator->path())) {
            candidates.push_back(iterator->path());
        }
    }
    std::sort(candidates.begin(), candidates.end(), [](const auto& a, const auto& b) {
        return a.generic_string().size() < b.generic_string().size();
    });
    std::vector<std::filesystem::path> selected_bundles;
    for (auto& candidate : candidates) {
        bool nested = false;
        for (auto& selected : selected_bundles) {
            if (path_is_under(candidate, selected)) {
                nested = true;
                break;
            }
        }
        if (!nested) selected_bundles.push_back(candidate);
    }
    for (auto& bundle : selected_bundles) {
        ArchiveEntryInfo info;
        info.path = bundle.generic_string();
        info.size = 0;
        info.is_directory = true;
        info.is_executable = false;
        info.is_symlink = false;
        info.is_signable = true;
        result.push_back(info);
    }
    for (auto iterator = std::filesystem::recursive_directory_iterator(dir, std::filesystem::directory_options::skip_permission_denied);
         iterator != std::filesystem::recursive_directory_iterator();
         ++iterator) {
        if (!iterator->is_regular_file()) continue;
        bool inside_bundle = false;
        for (auto& bundle : selected_bundles) {
            if (path_is_under(iterator->path(), bundle)) {
                inside_bundle = true;
                break;
            }
        }
        if (inside_bundle) continue;
        if (is_macho_file_impl(iterator->path())) {
            ArchiveEntryInfo info;
            info.path = iterator->path().generic_string();
            info.size = static_cast<uint64_t>(std::filesystem::file_size(iterator->path()));
            info.is_directory = false;
            info.is_symlink = false;
            info.is_executable = (std::filesystem::status(iterator->path()).permissions() & std::filesystem::perms::owner_exec) != std::filesystem::perms::none;
            info.is_signable = true;
            result.push_back(info);
        }
    }
    return result;
}

inline bool archive_path_contains_bundle(const std::string& name) {
    std::filesystem::path path(name);
    for (const auto& component : path) {
        std::string part = component.string();
        std::string lower = part;
        std::transform(lower.begin(), lower.end(), lower.begin(), [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
        for (const char* suffix : {".app", ".framework", ".appex", ".bundle", ".xpc", ".plugin", ".kext"}) {
            if (lower.size() >= std::strlen(suffix) && lower.compare(lower.size() - std::strlen(suffix), std::strlen(suffix), suffix) == 0) return true;
        }
    }
    return false;
}

inline bool read_archive_chunk(struct archive* reader, std::vector<uint8_t>& buffer, size_t max_size) {
    buffer.clear();
    buffer.resize(max_size);
    la_ssize_t n = archive_read_data(reader, buffer.data(), max_size);
    if (n < 0) throw std::runtime_error("archive entry read failed");
    buffer.resize(static_cast<size_t>(n));
    return n != 0;
}

inline void write_archive_all(struct archive* writer, const uint8_t* data, size_t size) {
    size_t written = 0;
    while (written < size) {
        la_ssize_t n = archive_write_data(writer, data + written, size - written);
        if (n <= 0) throw std::runtime_error("archive entry write failed");
        written += static_cast<size_t>(n);
    }
}

inline void stream_sign_passthrough_impl(const std::filesystem::path& in, const std::filesystem::path& out, const SignOptions& options) {
    ArchiveReader reader;
    if (!reader.handle || archive_read_open_filename(reader.handle, in.string().c_str(), 10240) != ARCHIVE_OK) throw std::runtime_error("archive open failed");
    ArchiveFormat format = detect_format_impl(in);
    ArchiveWriter writer;
    if (!writer.handle) throw std::runtime_error("archive writer allocation failed");
    configure_write_format_impl(writer.handle, format);
    std::filesystem::path target = out.empty() ? in : out;
    bool replace_original = target == in;
    std::filesystem::path temporary = replace_original ? make_unique_temp_path(target, ".ldid-streaming-signed") : target;
    if (archive_write_open_filename(writer.handle, temporary.string().c_str()) != ARCHIVE_OK) throw std::runtime_error("archive output open failed");

    constexpr size_t chunk_size = 1024 * 1024;
    for (;;) {
        ::archive_entry* entry = nullptr;
        int status = archive_read_next_header(reader.handle, &entry);
        if (status == ARCHIVE_EOF) break;
        if (status != ARCHIVE_OK) throw std::runtime_error("archive read failed");
        const char* raw_name = archive_entry_pathname(entry);
        std::string name = sanitize_relative_path(raw_name ? raw_name : "");
        if (name.empty()) { archive_read_data_skip(reader.handle); continue; }
        auto cloned = archive_entry_clone(entry);
        if (!cloned) throw std::runtime_error("archive entry clone failed");
        archive_entry_set_pathname(cloned, name.c_str());
        mode_t type = archive_entry_filetype(entry);

        if (type == AE_IFLNK) {
            archive_entry_set_filetype(cloned, AE_IFLNK);
            const char* link = archive_entry_symlink(entry);
            archive_entry_set_symlink(cloned, link ? link : "");
            archive_read_data_skip(reader.handle);
            if (archive_write_header(writer.handle, cloned) != ARCHIVE_OK) {
                archive_entry_free(cloned);
                throw std::runtime_error("archive header write failed");
            }
            archive_entry_free(cloned);
            continue;
        }

        if (type != AE_IFREG) {
            archive_read_data_skip(reader.handle);
            if (archive_write_header(writer.handle, cloned) != ARCHIVE_OK) {
                archive_entry_free(cloned);
                throw std::runtime_error("archive header write failed");
            }
            archive_entry_free(cloned);
            continue;
        }

        std::vector<uint8_t> prefix;
        prefix.reserve(8);
        while (prefix.size() < 8) {
            std::vector<uint8_t> chunk;
            if (!read_archive_chunk(reader.handle, chunk, 8 - prefix.size())) break;
            prefix.insert(prefix.end(), chunk.begin(), chunk.end());
        }
        bool is_macho = prefix.size() >= 4 && macho::is_macho_impl(prefix);
        std::vector<uint8_t> content;
        std::filesystem::path spool;
        std::ofstream spool_stream;
        struct SpoolCleanup {
            std::filesystem::path path;
            ~SpoolCleanup() {
                if (!path.empty()) {
                    std::error_code ec;
                    std::filesystem::remove(path, ec);
                }
            }
        } spool_cleanup;
        const la_int64_t entry_size = archive_entry_size(entry);
        const bool known_size = entry_size >= 0;

        if (is_macho) {
            content = std::move(prefix);
            std::vector<uint8_t> chunk;
            while (read_archive_chunk(reader.handle, chunk, chunk_size)) content.insert(content.end(), chunk.begin(), chunk.end());
            content = signer::sign_macho_memory_impl(content, options, std::filesystem::path(name), {});
            archive_entry_set_size(cloned, static_cast<la_int64_t>(content.size()));
            if (archive_write_header(writer.handle, cloned) != ARCHIVE_OK) {
                archive_entry_free(cloned);
                throw std::runtime_error("archive header write failed");
            }
            write_archive_all(writer.handle, content.data(), content.size());
        } else if (known_size) {
            if (archive_write_header(writer.handle, cloned) != ARCHIVE_OK) {
                archive_entry_free(cloned);
                throw std::runtime_error("archive header write failed");
            }
            write_archive_all(writer.handle, prefix.data(), prefix.size());
            std::vector<uint8_t> chunk;
            while (read_archive_chunk(reader.handle, chunk, chunk_size)) write_archive_all(writer.handle, chunk.data(), chunk.size());
        } else {
            spool = make_unique_temp_path(std::filesystem::temp_directory_path() / "ldid-archive-entry", ".spool");
            spool_cleanup.path = spool;
            spool_stream.open(spool, std::ios::binary | std::ios::trunc);
            if (!spool_stream) {
                archive_entry_free(cloned);
                throw std::runtime_error("archive spool open failed");
            }
            if (!prefix.empty()) spool_stream.write(reinterpret_cast<const char*>(prefix.data()), static_cast<std::streamsize>(prefix.size()));
            std::vector<uint8_t> chunk;
            while (read_archive_chunk(reader.handle, chunk, chunk_size)) {
                if (!chunk.empty()) spool_stream.write(reinterpret_cast<const char*>(chunk.data()), static_cast<std::streamsize>(chunk.size()));
            }
            spool_stream.close();
            std::error_code ec;
            const auto actual_size = std::filesystem::file_size(spool, ec);
            if (ec || actual_size > static_cast<uintmax_t>(std::numeric_limits<la_int64_t>::max())) {
                archive_entry_free(cloned);
                throw std::runtime_error("archive spool size invalid");
            }
            archive_entry_set_size(cloned, static_cast<la_int64_t>(actual_size));
            if (archive_write_header(writer.handle, cloned) != ARCHIVE_OK) {
                archive_entry_free(cloned);
                throw std::runtime_error("archive header write failed");
            }
            std::ifstream spool_input(spool, std::ios::binary);
            if (!spool_input) {
                archive_entry_free(cloned);
                throw std::runtime_error("archive spool read failed");
            }
            std::vector<uint8_t> chunk_buf(chunk_size);
            while (spool_input) {
                spool_input.read(reinterpret_cast<char*>(chunk_buf.data()), static_cast<std::streamsize>(chunk_buf.size()));
                const auto got = spool_input.gcount();
                if (got > 0) write_archive_all(writer.handle, chunk_buf.data(), static_cast<size_t>(got));
            }
            spool_input.close();
        }
        archive_entry_free(cloned);
    }
    archive_write_close(writer.handle);
    if (replace_original) {
        std::error_code ec;
        std::filesystem::rename(temporary, target, ec);
        if (ec) {
            std::filesystem::remove(temporary, ec);
            throw std::runtime_error("failed to replace archive: " + ec.message());
        }
    }
}
inline void stream_sign_impl(const std::filesystem::path& in, const std::filesystem::path& out, const SignOptions& options) {
    if (!is_archive_impl(in)) {
        signer::sign_file_impl(in, options);
        return;
    }
    if (!options.deep && !options.super_deep) {
        bool has_bundle = false;
        for (const auto& item : list_contents_impl(in)) {
            if (archive_path_contains_bundle(item.path)) { has_bundle = true; break; }
        }
        if (!has_bundle) {
            stream_sign_passthrough_impl(in, out, options);
            return;
        }
    }
    std::string work_dir = make_temp_dir();
    extract_archive_impl(in, work_dir);
    ArchiveSignPlan plan = signer::build_sign_plan_impl(work_dir);
    signer::sign_plan_impl(plan, options);
    std::filesystem::path target = out.empty() ? in : out;
    std::filesystem::path temporary_output = target;
    bool replace_original = false;
    if (target == in) {
        temporary_output = target;
        temporary_output += ".ldid-signed";
        replace_original = true;
    }
    create_archive_impl(work_dir, temporary_output, detect_format_impl(in));
    std::error_code ec;
    std::filesystem::remove_all(work_dir, ec);
    if (replace_original) {
        std::filesystem::rename(temporary_output, target, ec);
    }
}

}

namespace signer {

inline std::vector<uint8_t> read_bytes_local(const std::filesystem::path& path) {
    std::ifstream input(path, std::ios::binary);
    return std::vector<uint8_t>((std::istreambuf_iterator<char>(input)), std::istreambuf_iterator<char>());
}

inline std::string read_text_local(const std::filesystem::path& path) {
    std::vector<uint8_t> bytes = read_bytes_local(path);
    return std::string(bytes.begin(), bytes.end());
}

inline bool write_bytes_local(const std::filesystem::path& path, const std::vector<uint8_t>& data) {
    if (path.has_parent_path()) {
        std::error_code ec;
        std::filesystem::create_directories(path.parent_path(), ec);
    }
    std::ofstream output(path, std::ios::binary | std::ios::trunc);
    if (!output) return false;
    output.write(reinterpret_cast<const char*>(data.data()), static_cast<std::streamsize>(data.size()));
    return static_cast<bool>(output);
}

inline std::string identifier_from_path(const std::filesystem::path& path) {
    if (path.empty()) return "ldid-binary";
    auto filename = path.filename().string();
    if (filename.empty()) return "ldid-binary";
    auto dot = filename.find_last_of('.');
    if (dot != std::string::npos && dot != 0) {
        return filename.substr(0, dot);
    }
    return filename;
}

inline std::string merge_entitlements_xml(const std::string& base_xml, const std::string& overlay_xml) {
    std::vector<uint8_t> base_bytes(base_xml.begin(), base_xml.end());
    std::vector<uint8_t> overlay_bytes(overlay_xml.begin(), overlay_xml.end());
    plist_t base = plist_from_xml_bytes(base_bytes);
    plist_t overlay = plist_from_xml_bytes(overlay_bytes);
    if (!base && overlay) return overlay_xml;
    if (base && !overlay) return base_xml;
    if (!base || !overlay) return {};
    if (plist_get_node_type(base) != PLIST_DICT || plist_get_node_type(overlay) != PLIST_DICT) {
        plist_free(base);
        plist_free(overlay);
        return overlay_xml;
    }
    plist_dict_iter iterator = nullptr;
    plist_dict_new_iter(overlay, &iterator);
    if (iterator) {
        for (;;) {
            char* key = nullptr;
            plist_t value = nullptr;
            plist_dict_next_item(overlay, iterator, &key, &value);
            if (!key || !value) {
                free(key);
                break;
            }
            plist_dict_set_item(base, key, plist_copy(value));
            free(key);
        }
        free(iterator);
    }
    auto merged = plist_xml_bytes(base);
    plist_free(base);
    plist_free(overlay);
    return std::string(merged.begin(), merged.end());
}

inline std::string resolve_team_id(const SignOptions& options) {
    if (!options.team_id.empty()) return options.team_id;
    if (!options.p12_path.empty()) {
        return crypto::extract_team_id_from_p12_impl(options.p12_path, options.key_password);
    }
    if (!options.certificate_path.empty()) {
        if (options.private_key_path.empty()) {
            auto from_p12 = crypto::extract_team_id_from_p12_impl(options.certificate_path, options.key_password);
            if (!from_p12.empty()) return from_p12;
        }
        return crypto::extract_team_id_from_certificate_file_impl(options.certificate_path);
    }
    return {};
}

inline std::string resolve_entitlements_xml(const SignOptions& options, const std::string& existing_xml) {
    std::string new_xml;
    if (!options.entitlements_path.empty()) {
        new_xml = read_text_local(options.entitlements_path);
    }
    if (!options.merge_entitlements_path.empty()) {
        std::string overlay = read_text_local(options.merge_entitlements_path);
        std::string base = existing_xml;
        if (base.empty()) base = new_xml;
        return merge_entitlements_xml(base, overlay);
    }
    if (!new_xml.empty()) {
        if (options.preserve_entitlements && !existing_xml.empty()) {
            return merge_entitlements_xml(existing_xml, new_xml);
        }
        return new_xml;
    }
    if (options.preserve_entitlements) return existing_xml;
    return {};
}

inline uint32_t resolve_cd_flags(const SignOptions& options) {
    uint32_t flags = options.cd_flags;
    if (options.adhoc) flags |= static_cast<uint32_t>(CodeDirectoryFlag::ADHOC);
    if (options.runtime) flags |= static_cast<uint32_t>(CodeDirectoryFlag::RUNTIME);
    if (options.library_validation) flags |= static_cast<uint32_t>(CodeDirectoryFlag::LIBRARY_VALIDATION);
    if (options.linker_signed) flags |= static_cast<uint32_t>(CodeDirectoryFlag::LINKER_SIGNED);
    return flags;
}

inline bool entitlement_bool_value(const std::string& xml, const char* key) {
    auto plist = plist_from_xml_bytes(std::vector<uint8_t>(xml.begin(), xml.end()));
    if (!plist || plist_get_node_type(plist) != PLIST_DICT) {
        if (plist) plist_free(plist);
        return false;
    }
    plist_t item = plist_dict_get_item(plist, key);
    bool result = false;
    if (item && plist_get_node_type(item) == PLIST_BOOLEAN) {
        uint8_t value = 0;
        plist_get_bool_val(item, &value);
        result = value != 0;
    }
    plist_free(plist);
    return result;
}

inline uint64_t resolve_exec_seg_flags(const macho::MachoAnalysis& analysis, const std::string& entitlements_xml) {
    constexpr uint64_t CS_EXECSEG_MAIN_BINARY = 0x1ULL;
    constexpr uint64_t CS_EXECSEG_ALLOW_UNSIGNED = 0x10ULL;
    constexpr uint64_t CS_EXECSEG_DEBUGGER = 0x20ULL;
    constexpr uint64_t CS_EXECSEG_JIT = 0x40ULL;
    uint64_t flags = analysis.main_executable ? CS_EXECSEG_MAIN_BINARY : 0ULL;
    if (entitlement_bool_value(entitlements_xml, "get-task-allow")) flags |= CS_EXECSEG_ALLOW_UNSIGNED;
    if (entitlement_bool_value(entitlements_xml, "com.apple.security.cs.allow-jit")) flags |= CS_EXECSEG_JIT;
    if (entitlement_bool_value(entitlements_xml, "com.apple.security.cs.debugger")) flags |= CS_EXECSEG_DEBUGGER;
    return flags;
}

inline std::vector<uint8_t> embed_signature_placeholder(const std::vector<uint8_t>& data, size_t signature_size) {
    auto analysis = macho::analyze_thin(data, 0);
    if (!analysis.valid) throw std::invalid_argument("invalid Mach-O");
    std::vector<uint8_t> out = data;
    auto header = macho::parse_header(out, 0);
    auto commands = macho::enumerate_load_commands(out, header, 0);
    const macho::LoadCommandRef* existing = nullptr;
    size_t used_commands = 0;
    size_t max_header = out.size();
    for (const auto& command : commands) {
        used_commands += command.cmdsize;
        if (command.cmd == macho::LC_CODE_SIGNATURE) existing = &command;
        if (command.cmd == macho::LC_SEGMENT && command.cmdsize >= 40) {
            uint32_t fileoff = read_u32_file(out.data() + command.offset + 32, header.big);
            if (fileoff > analysis.header_end && fileoff < max_header) max_header = fileoff;
        }
        if (command.cmd == macho::LC_SEGMENT_64 && command.cmdsize >= 56) {
            uint64_t fileoff = read_u64_file(out.data() + command.offset + 40, header.big);
            if (fileoff > analysis.header_end && fileoff < max_header) max_header = static_cast<size_t>(fileoff);
        }
    }
    if (existing) {
        size_t old_offset = read_u32_file(out.data() + existing->offset + 8, header.big);
        size_t old_size = read_u32_file(out.data() + existing->offset + 12, header.big);
        if (old_offset + old_size == out.size()) out.resize(old_offset);
        else if (old_offset + old_size <= out.size()) std::fill(out.begin() + static_cast<std::ptrdiff_t>(old_offset), out.begin() + static_cast<std::ptrdiff_t>(old_offset + old_size), 0);
        size_t new_offset = align_up64(out.size(), 16);
        macho::pad_to(out, new_offset);
        out.resize(new_offset + signature_size, 0);
        write_u32_file(out.data() + existing->offset + 8, static_cast<uint32_t>(new_offset), header.big);
        write_u32_file(out.data() + existing->offset + 12, static_cast<uint32_t>(signature_size), header.big);
        macho::update_linkedit_size(out, header, analysis.linkedit_fileoff);
        return out;
    }
    size_t insert_pos = analysis.load_commands_offset + used_commands;
    if (insert_pos + 16 > max_header || !macho::all_zero(out, insert_pos, 16)) throw std::runtime_error("no room for LC_CODE_SIGNATURE");
    size_t new_offset = align_up64(out.size(), 16);
    macho::pad_to(out, new_offset);
    out.resize(new_offset + signature_size, 0);
    write_u32_file(out.data() + insert_pos, macho::LC_CODE_SIGNATURE, header.big);
    write_u32_file(out.data() + insert_pos + 4, 16, header.big);
    write_u32_file(out.data() + insert_pos + 8, static_cast<uint32_t>(new_offset), header.big);
    write_u32_file(out.data() + insert_pos + 12, static_cast<uint32_t>(signature_size), header.big);
    write_u32_file(out.data() + 16, header.ncmds + 1, header.big);
    write_u32_file(out.data() + 20, header.sizeofcmds + 16, header.big);
    macho::update_linkedit_size(out, header, analysis.linkedit_fileoff);
    return out;
}

inline std::vector<uint8_t> sign_thin_memory_with_slots(const std::vector<uint8_t>& data, const SignOptions& options, const std::filesystem::path& source_path, const std::vector<std::vector<uint8_t>>& extra_special_slots) {
    auto analysis = macho::analyze_thin(data, 0);
    if (!analysis.valid) return data;
    auto stripped = macho::strip_signature_impl(data);
    auto existing = macho::get_signature_info_impl(data);
    std::string identifier = options.identifier;
    if (identifier.empty()) identifier = existing.identifier;
    if (identifier.empty()) identifier = identifier_from_path(source_path);
    std::string team_id = resolve_team_id(options);
    if (team_id.empty() && options.preserve_entitlements) team_id = existing.team_id;
    std::string entitlements_xml = resolve_entitlements_xml(options, existing.entitlements_xml);
    std::vector<uint8_t> requirements_blob;
    if (!options.requirements_xml.empty()) requirements_blob = blob::compile_requirements_impl(options.requirements_xml);
    else if (!options.requirements_path.empty()) requirements_blob = blob::compile_requirements_impl(read_text_local(options.requirements_path));
    else if (options.preserve_entitlements && !existing.requirements_blob.empty()) requirements_blob = existing.requirements_blob;
    else requirements_blob = blob::build_requirements_blob_impl(identifier, team_id);
    if (requirements_blob.empty()) throw std::runtime_error("failed to build designated requirement");
    std::vector<uint8_t> entitlements_blob;
    std::vector<uint8_t> der_entitlements_blob;
    if (!entitlements_xml.empty()) {
        entitlements_blob = blob::build_entitlements_blob_impl(entitlements_xml);
        bool emit_der = options.platform == Platform::IOS || options.platform == Platform::TVOS || options.platform == Platform::WATCHOS || options.platform == Platform::BRIDGEOS || options.platform == Platform::IOSSIMULATOR || options.platform == Platform::TVOSSIMULATOR || options.platform == Platform::WATCHOSSIMULATOR;
        if (options.platform == Platform::UNKNOWN && !existing.entitlements_der.empty()) emit_der = true;
        if (emit_der) der_entitlements_blob = blob::build_der_entitlements_blob_impl(entitlements_xml);
    }
    std::vector<std::vector<uint8_t>> special_slots(8);
    for (size_t i = 0; i < extra_special_slots.size() && i < special_slots.size(); ++i) special_slots[i] = extra_special_slots[i];
    if (special_slots[1].empty()) {
        std::filesystem::path cursor = source_path.parent_path();
        bool inside_bundle = false;
        std::filesystem::path bundle_root;
        for (size_t depth = 0; depth < 16 && !cursor.empty(); ++depth) {
            if (archive::is_signable_bundle_extension(cursor)) {
                inside_bundle = true;
                bundle_root = cursor;
                break;
            }
            if (cursor == cursor.parent_path()) break;
            cursor = cursor.parent_path();
        }
        if (inside_bundle) {
            auto candidate = bundle_root / "Info.plist";
            if (std::filesystem::is_regular_file(candidate)) special_slots[1] = read_bytes_local(candidate);
        }
    }
    special_slots[2] = requirements_blob;
    special_slots[5] = entitlements_blob;
    special_slots[7] = der_entitlements_blob;
    HashType primary_hash = options.hash_type == HashType::ANY ? HashType::SHA256 : options.hash_type;
    HashType alternate_hash = (primary_hash == HashType::SHA1 || primary_hash == HashType::SHA256_TRUNCATED || primary_hash == HashType::SHA384) ? HashType::SHA256 : HashType::SHA1;
    bool has_certificate = !options.p12_path.empty() || !options.certificate_path.empty();
    std::string signing_certificate = !options.p12_path.empty() ? options.p12_path : options.certificate_path;
    std::string signing_key = !options.p12_path.empty() ? std::string() : options.private_key_path;
    std::vector<uint8_t> signature;
    for (size_t iteration = 0; iteration < 8; ++iteration) {
        size_t placeholder_size = signature.empty() ? 65536 : signature.size();
        auto signing_image = embed_signature_placeholder(stripped, placeholder_size);
        auto signing_analysis = macho::analyze_thin(signing_image, 0);
        if (!signing_analysis.valid || signing_analysis.code_signature_offset == 0) throw std::runtime_error("failed to prepare code signature command");
        size_t signing_limit = signing_analysis.code_signature_offset;
        blob::CodeDirectoryInputs inputs;
        inputs.code.assign(signing_image.begin(), signing_image.begin() + static_cast<std::ptrdiff_t>(signing_limit));
        inputs.identifier = identifier;
        inputs.team_id = team_id;
        inputs.hash_type = primary_hash;
        inputs.flags = resolve_cd_flags(options);
        inputs.version = 0x20200;
        inputs.platform = options.platform;
        inputs.special_slots = special_slots;
        inputs.exec_seg_base = analysis.exec_seg_base;
        inputs.exec_seg_limit = analysis.exec_seg_limit;
        inputs.exec_seg_flags = resolve_exec_seg_flags(analysis, entitlements_xml);
        inputs.runtime_version = options.runtime ? (options.min_os_version != 0 ? options.min_os_version : analysis.min_os_version) : 0U;
        auto primary_cd = blob::build_code_directory_full(inputs);
        blob::CodeDirectoryInputs alternate_inputs = inputs;
        alternate_inputs.hash_type = alternate_hash;
        auto alternate_cd = blob::build_code_directory_full(alternate_inputs);
        std::map<uint32_t, std::vector<uint8_t>> slots;
        slots[static_cast<uint32_t>(CodeSignSlot::CODEDIRECTORY)] = primary_cd;
        slots[static_cast<uint32_t>(CodeSignSlot::ALTERNATE_BASE)] = alternate_cd;
        slots[static_cast<uint32_t>(CodeSignSlot::REQUIREMENTS)] = requirements_blob;
        if (!entitlements_blob.empty()) slots[static_cast<uint32_t>(CodeSignSlot::ENTITLEMENTS)] = entitlements_blob;
        if (!der_entitlements_blob.empty()) slots[static_cast<uint32_t>(CodeSignSlot::DER_ENTITLEMENTS)] = der_entitlements_blob;
        if (!options.adhoc && has_certificate) {
            std::vector<std::pair<HashType, std::vector<uint8_t>>> cd_hashes;
            cd_hashes.emplace_back(primary_hash, crypto::hash_impl(primary_hash, primary_cd));
            cd_hashes.emplace_back(alternate_hash, crypto::hash_impl(alternate_hash, alternate_cd));
            auto cms = crypto::sign_pkcs7_detached_impl(primary_cd, cd_hashes, signing_certificate, signing_key, options.key_password, options.emit_signing_time, options.true_sign, options.timestamp_enabled ? options.timestamp_url : std::string{}, options.timestamp_required, options.timestamp_policy);
            if (cms.empty()) throw std::runtime_error("CMS signing failed");
            slots[static_cast<uint32_t>(CodeSignSlot::CMS_SIGNATURE)] = blob::make_blob_impl(static_cast<uint32_t>(BlobMagic::CSMAGIC_BLOBWRAPPER), cms);
        } else {
            slots[static_cast<uint32_t>(CodeSignSlot::CMS_SIGNATURE)] = blob::make_blob_impl(static_cast<uint32_t>(BlobMagic::CSMAGIC_BLOBWRAPPER), {});
        }
        auto superblob = blob::build_superblob_impl(slots);
        signature = superblob;
        if (signature.size() == placeholder_size) break;
        if (iteration == 7) throw std::runtime_error("code signature size did not converge");
    }
    auto final_image = embed_signature_placeholder(stripped, signature.size());
    auto final_analysis = macho::analyze_thin(final_image, 0);
    if (!final_analysis.valid || final_analysis.code_signature_offset + signature.size() > final_image.size()) throw std::runtime_error("final code signature placement failed");
    std::copy(signature.begin(), signature.end(), final_image.begin() + static_cast<std::ptrdiff_t>(final_analysis.code_signature_offset));
    return final_image;
}

inline std::vector<uint8_t> sign_thin_memory_impl(const std::vector<uint8_t>& data, const SignOptions& options, const std::filesystem::path& source_path) {
    return sign_thin_memory_with_slots(data, options, source_path, {});
}

inline bool slice_matches_arch(const Slice& slice, const std::string& arch) {
    uint32_t subtype = 0;
    bool has_subtype = false;
    CPUType wanted = macho::cpu_type_from_arch(arch, subtype, has_subtype);
    if (wanted == CPUType::ANY) return true;
    if (slice.cpu_type != wanted) return false;
    if (has_subtype && slice.cpu_subtype != subtype) return false;
    return true;
}

inline std::vector<uint8_t> sign_macho_memory_impl(const std::vector<uint8_t>& data, const SignOptions& options, const std::filesystem::path& source_path, const std::vector<std::vector<uint8_t>>& extra_special_slots) {
    if (data.size() < 8) return data;
    uint32_t be_magic = load_be32(data.data());
    if (be_magic == macho::FAT_MAGIC || be_magic == macho::FAT_MAGIC_64 || be_magic == macho::FAT_CIGAM || be_magic == macho::FAT_CIGAM_64) {
        auto slices = macho::parse_slices_impl(data);
        std::vector<std::vector<uint8_t>> signed_slices;
        signed_slices.reserve(slices.size());
        for (auto& slice : slices) {
            std::vector<uint8_t> slice_data(data.begin() + slice.offset, data.begin() + slice.offset + slice.size);
            if (options.arch.empty() || slice_matches_arch(slice, options.arch)) {
                signed_slices.push_back(sign_thin_memory_with_slots(slice_data, options, source_path, extra_special_slots));
            } else {
                signed_slices.push_back(slice_data);
            }
        }
        auto original_slices = macho::parse_slices_impl(data);
        bool fat64 = false;
        bool cigam = false;
        if (!original_slices.empty()) {
            fat64 = original_slices.front().fat64_container;
            cigam = original_slices.front().fat_cigam_container;
        }
        return macho::rebuild_fat_with_format_impl(signed_slices, fat64, cigam);
    }
    return sign_thin_memory_impl(data, options, source_path);
}

inline std::filesystem::path resolve_output_path(const std::filesystem::path& input, const SignOptions& options) {
    if (!options.output_path.empty()) return options.output_path;
    if (options.output_stdout) return {};
    if (options.no_overwrite || options.write_copy) {
        std::filesystem::path candidate = input;
        candidate += ".signed";
        int counter = 1;
        while (std::filesystem::exists(candidate)) {
            candidate = input;
            candidate += "-" + std::to_string(counter) + ".signed";
            ++counter;
        }
        return candidate;
    }
    return input;
}

inline void write_result(const std::filesystem::path& input, const std::vector<uint8_t>& signed_data, const SignOptions& options) {
    if (options.output_stdout) {
        std::cout.write(reinterpret_cast<const char*>(signed_data.data()), static_cast<std::streamsize>(signed_data.size()));
        return;
    }
    auto output = resolve_output_path(input, options);
    if (output.empty()) output = input;
    std::error_code ec;
    auto original_permissions = std::filesystem::status(output, ec).permissions();
    bool changed_permissions = false;
    if (options.force && !ec) {
        auto writable = original_permissions | std::filesystem::perms::owner_write;
        if (writable != original_permissions) {
            std::filesystem::permissions(output, writable, std::filesystem::perm_options::replace, ec);
            changed_permissions = !ec;
        }
    }
    if (!write_bytes_local(output, signed_data)) throw std::runtime_error("failed to write signed output: " + output.string());
    if (changed_permissions) {
        std::error_code restore_ec;
        std::filesystem::permissions(output, original_permissions, std::filesystem::perm_options::replace, restore_ec);
    }
}

inline void sign_file_with_slots_impl(const std::filesystem::path& path, const SignOptions& options, const std::vector<std::vector<uint8_t>>& extra_special_slots) {
    auto data = read_bytes_local(path);
    if (data.empty()) return;
    std::vector<uint8_t> signed_data;
    uint32_t be_magic = data.size() >= 8 ? load_be32(data.data()) : 0;
    if (be_magic == macho::FAT_MAGIC || be_magic == macho::FAT_MAGIC_64 || be_magic == macho::FAT_CIGAM || be_magic == macho::FAT_CIGAM_64) {
        signed_data = sign_macho_memory_impl(data, options, path, extra_special_slots);
    } else {
        signed_data = sign_thin_memory_with_slots(data, options, path, extra_special_slots);
    }
    write_result(path, signed_data, options);
}

inline void sign_file_impl(const std::filesystem::path& path, const SignOptions& options) {
    sign_file_with_slots_impl(path, options, {});
}

inline std::string requirement_display_string(const SignatureInfo& info) {
    if (info.identifier.empty()) return {};
    std::string result = "identifier \"" + info.identifier + "\"";
    if (!info.team_id.empty() && !info.adhoc) result += " and anchor apple generic and certificate leaf[subject.OU] = \"" + info.team_id + "\"";
    return result;
}

inline void generate_code_resources_full_impl(const std::filesystem::path& bundle) {
    std::filesystem::path executable = archive::find_executable_in_bundle_impl(bundle);
    std::vector<std::filesystem::path> nested_bundles;
    for (auto iterator = std::filesystem::recursive_directory_iterator(bundle, std::filesystem::directory_options::skip_permission_denied); iterator != std::filesystem::recursive_directory_iterator(); ++iterator) {
        if (!iterator->is_directory() || iterator->path() == bundle || !archive::is_signable_bundle_extension(iterator->path())) continue;
        bool nested = false;
        for (const auto& existing : nested_bundles) if (archive::path_is_under(iterator->path(), existing)) { nested = true; break; }
        if (!nested) nested_bundles.push_back(iterator->path());
    }
    plist_t root = plist_new_dict();
    plist_t files = plist_new_dict();
    plist_t files2 = plist_new_dict();
    plist_t rules = plist_new_dict();
    plist_t rules2 = plist_new_dict();
    plist_dict_set_item(rules, ".*", plist_new_bool(1));
    plist_t lproj_rule = plist_new_dict();
    plist_dict_set_item(lproj_rule, "optional", plist_new_bool(1));
    plist_dict_set_item(lproj_rule, "weight", plist_new_uint(1000));
    plist_dict_set_item(rules, "^.*\\.lproj/", lproj_rule);
    plist_dict_set_item(rules2, ".*", plist_new_bool(1));
    plist_t ds_rule = plist_new_dict();
    plist_dict_set_item(ds_rule, "omit", plist_new_bool(1));
    plist_dict_set_item(ds_rule, "weight", plist_new_uint(2000));
    plist_dict_set_item(rules2, "^(.*/)?\\.DS_Store$", ds_rule);
    plist_t info_rule = plist_new_dict();
    plist_dict_set_item(info_rule, "omit", plist_new_bool(1));
    plist_dict_set_item(info_rule, "weight", plist_new_uint(1000));
    plist_dict_set_item(rules2, "^Info.plist$", info_rule);
    plist_t pkginfo_rule = plist_new_dict();
    plist_dict_set_item(pkginfo_rule, "omit", plist_new_bool(1));
    plist_dict_set_item(pkginfo_rule, "weight", plist_new_uint(1000));
    plist_dict_set_item(rules2, "^PkgInfo$", pkginfo_rule);
    plist_t lproj_rule2 = plist_new_dict();
    plist_dict_set_item(lproj_rule2, "optional", plist_new_bool(1));
    plist_dict_set_item(lproj_rule2, "weight", plist_new_uint(1000));
    plist_dict_set_item(rules2, "^.*\\.lproj/", lproj_rule2);
    plist_t nested_rule = plist_new_dict();
    plist_dict_set_item(nested_rule, "nested", plist_new_bool(1));
    plist_dict_set_item(nested_rule, "weight", plist_new_uint(10));
    plist_dict_set_item(rules2, "^(Frameworks|SharedFrameworks|PlugIns|Plug-ins|XPCServices|Helpers|MacOS|Library/(Automator|Spotlight|LoginItems))/", nested_rule);
    plist_t top_rule = plist_new_dict();
    plist_dict_set_item(top_rule, "top", plist_new_bool(1));
    plist_dict_set_item(top_rule, "weight", plist_new_uint(0));
    plist_dict_set_item(rules2, "^[^/]+$", top_rule);
    for (auto iterator = std::filesystem::recursive_directory_iterator(bundle, std::filesystem::directory_options::skip_permission_denied); iterator != std::filesystem::recursive_directory_iterator(); ++iterator) {
        const auto path = iterator->path();
        if (!iterator->is_regular_file() && !iterator->is_symlink()) continue;
        if (path == executable || archive::path_is_under(path, bundle / "_CodeSignature")) continue;
        bool inside_nested = false;
        for (const auto& nested : nested_bundles) if (archive::path_is_under(path, nested)) { inside_nested = true; break; }
        if (inside_nested) continue;
        std::string relative = std::filesystem::relative(path, bundle).generic_string();
        if (relative == ".DS_Store" || relative.rfind(".DS_Store/", 0) == 0) continue;
        bool optional = relative.find(".lproj/") != std::string::npos || (relative.size() >= 6 && relative.compare(relative.size() - 6, 6, ".lproj") == 0);
        plist_t v1 = nullptr;
        plist_t v2 = plist_new_dict();
        if (iterator->is_symlink()) {
            auto target = std::filesystem::read_symlink(path).generic_string();
            v1 = plist_new_dict();
            plist_dict_set_item(v1, "symlink", plist_new_string(target.c_str()));
            plist_dict_set_item(v2, "symlink", plist_new_string(target.c_str()));
        } else {
            auto data = read_bytes_local(path);
            auto sha1 = crypto::sha1_impl(data);
            auto sha256 = crypto::sha256_impl(data);
            v1 = plist_new_data(reinterpret_cast<const char*>(sha1.data()), static_cast<uint64_t>(sha1.size()));
            plist_dict_set_item(v2, "hash", plist_new_data(reinterpret_cast<const char*>(sha1.data()), static_cast<uint64_t>(sha1.size())));
            plist_dict_set_item(v2, "hash2", plist_new_data(reinterpret_cast<const char*>(sha256.data()), static_cast<uint64_t>(sha256.size())));
        }
        plist_dict_set_item(files, relative.c_str(), v1);
        if (optional) plist_dict_set_item(v2, "optional", plist_new_bool(1));
        if (relative != "Info.plist" && relative != "PkgInfo") plist_dict_set_item(files2, relative.c_str(), v2); else plist_free(v2);
    }
    for (const auto& nested : nested_bundles) {
            auto nested_exec = archive::find_executable_in_bundle_impl(nested);
            if (nested_exec.empty()) continue;
            auto nested_data = read_bytes_local(nested_exec);
            auto nested_info = macho::get_signature_info_impl(nested_data);
            if (nested_info.cd_hash.empty()) continue;
            auto relative = std::filesystem::relative(nested, bundle).generic_string();
            plist_t entry = plist_new_dict();
            plist_dict_set_item(entry, "cdhash", plist_new_data(reinterpret_cast<const char*>(nested_info.cd_hash.data()), static_cast<uint64_t>(nested_info.cd_hash.size())));
            auto requirement = requirement_display_string(nested_info);
            if (!requirement.empty()) plist_dict_set_item(entry, "requirement", plist_new_string(requirement.c_str()));
            plist_dict_set_item(files2, relative.c_str(), entry);
        }
    plist_dict_set_item(root, "files", files);
    plist_dict_set_item(root, "files2", files2);
    plist_dict_set_item(root, "rules", rules);
    plist_dict_set_item(root, "rules2", rules2);
    auto xml = plist_xml_bytes(root);
    plist_free(root);
    if (xml.empty()) throw std::runtime_error("failed to serialize CodeResources");
    std::filesystem::path code_resources = bundle / "_CodeSignature" / "CodeResources";
    if (!write_bytes_local(code_resources, xml)) throw std::runtime_error("failed to write CodeResources");
}

inline SignOptions nested_sign_options_for_bundle(const std::filesystem::path& bundle, const SignOptions& options) {
    SignOptions nested = options;
    std::string extension = bundle.extension().string();
    std::transform(extension.begin(), extension.end(), extension.begin(), [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
    const bool carries_application_entitlements = extension == ".app" || extension == ".appex" || extension == ".xpc";
    if (!carries_application_entitlements) {
        nested.entitlements_path.clear();
        nested.merge_entitlements_path.clear();
        nested.preserve_entitlements = false;
    }
    return nested;
}

inline void sign_bundle_tree_impl_depth(const std::filesystem::path& bundle, const SignOptions& options, size_t remaining_depth) {
    const SignOptions effective_options = nested_sign_options_for_bundle(bundle, options);
    std::vector<std::filesystem::path> nested_bundles;
    for (auto iterator = std::filesystem::recursive_directory_iterator(bundle, std::filesystem::directory_options::skip_permission_denied); iterator != std::filesystem::recursive_directory_iterator(); ++iterator) {
        if (!iterator->is_directory() || iterator->path() == bundle || !archive::is_signable_bundle_extension(iterator->path())) continue;
        bool nested = false;
        for (const auto& existing : nested_bundles) if (archive::path_is_under(iterator->path(), existing)) { nested = true; break; }
        if (!nested) nested_bundles.push_back(iterator->path());
    }
    if (remaining_depth != 0) {
        const size_t child_depth = remaining_depth == std::numeric_limits<size_t>::max() ? remaining_depth : remaining_depth - 1;
        for (const auto& nested : nested_bundles) sign_bundle_tree_impl_depth(nested, options, child_depth);
    }
    std::filesystem::path executable = archive::find_executable_in_bundle_impl(bundle);
    for (auto iterator = std::filesystem::recursive_directory_iterator(bundle, std::filesystem::directory_options::skip_permission_denied); iterator != std::filesystem::recursive_directory_iterator(); ++iterator) {
        if (!iterator->is_regular_file()) continue;
        auto path = iterator->path();
        if (path == executable) continue;
        if (archive::path_is_under(path, bundle / "_CodeSignature")) continue;
        bool inside_nested = false;
        for (const auto& nested : nested_bundles) if (archive::path_is_under(path, nested)) { inside_nested = true; break; }
        if (inside_nested) continue;
        if (archive::is_macho_file_impl(path)) {
            if (options.sign_executables_only) {
                auto permissions = std::filesystem::status(path).permissions();
                if ((permissions & std::filesystem::perms::owner_exec) == std::filesystem::perms::none) continue;
            }
            sign_file_impl(path, effective_options);
        }
    }
    if (!executable.empty()) sign_file_impl(executable, effective_options);
    generate_code_resources_full_impl(bundle);
    if (!executable.empty()) {
        std::filesystem::path code_resources = bundle / "_CodeSignature" / "CodeResources";
        std::vector<std::vector<uint8_t>> extra_slots(8);
        if (std::filesystem::exists(code_resources)) extra_slots[3] = read_bytes_local(code_resources);
        sign_file_with_slots_impl(executable, effective_options, extra_slots);
    }
}

inline void sign_bundle_tree_impl(const std::filesystem::path& bundle, const SignOptions& options) {
    const size_t remaining_depth = options.super_deep ? std::numeric_limits<size_t>::max() : (options.deep ? 1 : 0);
    sign_bundle_tree_impl_depth(bundle, options, remaining_depth);
}
inline ArchiveSignPlan build_sign_plan_impl(const std::filesystem::path& dir) {
    ArchiveSignPlan plan;
    plan.root_dir = dir.generic_string();
    auto entries = archive::scan_for_signables_impl(dir);
    for (auto& entry : entries) {
        std::filesystem::path path(entry.path);
        if (entry.is_directory) {
            auto extension = path.extension().string();
            std::transform(extension.begin(), extension.end(), extension.begin(), [](unsigned char c) {
                return static_cast<char>(std::tolower(c));
            });
            if (extension == ".app") {
                plan.bundle_paths.push_back(entry.path);
                plan.requires_code_resources = true;
            } else if (extension == ".framework") {
                plan.framework_paths.push_back(entry.path);
            } else {
                plan.nested_bundle_paths.push_back(entry.path);
            }
        } else {
            plan.macho_paths.push_back(entry.path);
        }
    }
    return plan;
}

inline void sign_plan_impl(const ArchiveSignPlan& plan, const SignOptions& options) {
    for (auto& framework : plan.framework_paths) {
        sign_bundle_tree_impl(framework, options);
    }
    for (auto& nested : plan.nested_bundle_paths) {
        sign_bundle_tree_impl(nested, options);
    }
    for (auto& bundle : plan.bundle_paths) {
        sign_bundle_tree_impl(bundle, options);
    }
    for (auto& macho : plan.macho_paths) {
        if (options.sign_executables_only) {
            auto permissions = std::filesystem::status(macho).permissions();
            if ((permissions & std::filesystem::perms::owner_exec) == std::filesystem::perms::none) {
                continue;
            }
        }
        sign_file_impl(macho, options);
    }
}

inline void sign_impl(const std::filesystem::path& path, const SignOptions& options) {
    if (options.merge_only) {
        if (std::filesystem::is_directory(path) || archive::is_archive_impl(path)) {
            throw std::invalid_argument("-M merge-only currently requires a single Mach-O file");
        }
        auto current = read_bytes_local(path);
        if (!macho::is_macho_impl(current)) throw std::invalid_argument("-M requires a Mach-O input");
        auto existing = macho::get_signature_info_impl(current);
        if (existing.entitlements_xml.empty()) throw std::invalid_argument("-M requires existing XML entitlements");
        if (options.entitlements_path.empty() && options.merge_entitlements_path.empty()) throw std::invalid_argument("-M requires an entitlement source");
        SignOptions merged = options;
        merged.preserve_entitlements = true;
        merged.identifier.clear();
        merged.team_id.clear();
        merged.requirements_path.clear();
        merged.requirements_xml.clear();
        merged.merge_entitlements_path = !options.merge_entitlements_path.empty() ? options.merge_entitlements_path : options.entitlements_path;
        merged.entitlements_path.clear();
        merged.merge_only = false;
        sign_file_impl(path, merged);
        return;
    }
    if (std::filesystem::is_directory(path)) {
        if (archive::is_signable_bundle_extension(path)) {
            sign_bundle_tree_impl(path, options);
        } else {
            auto plan = build_sign_plan_impl(path);
            sign_plan_impl(plan, options);
        }
        return;
    }
    if (archive::is_archive_impl(path)) {
        archive::stream_sign_impl(path, resolve_output_path(path, options), options);
        return;
    }
    sign_file_impl(path, options);
}

inline std::vector<uint8_t> unsign_memory_impl(const std::vector<uint8_t>& data) {
    return macho::strip_signature_impl(data);
}

inline void reset_cryptid_impl(const std::filesystem::path& path) {
    auto data = read_bytes_local(path);
    auto slices = macho::parse_slices_impl(data);
    if (slices.empty()) throw std::invalid_argument("invalid Mach-O");
    std::vector<std::vector<uint8_t>> rewritten;
    rewritten.reserve(slices.size());
    for (const auto& slice : slices) {
        auto slice_data = std::vector<uint8_t>(data.begin() + static_cast<std::ptrdiff_t>(slice.offset), data.begin() + static_cast<std::ptrdiff_t>(slice.offset + slice.size));
        auto header = macho::parse_header(slice_data, 0);
        if (!header.valid) throw std::invalid_argument("invalid Mach-O slice");
        auto commands = macho::enumerate_load_commands(slice_data, header, 0);
        for (const auto& command : commands) {
            if (command.cmd == 0x21U && command.cmdsize >= 20) write_u32_file(slice_data.data() + command.offset + 16, 0, header.big);
            if (command.cmd == 0x2CU && command.cmdsize >= 24) write_u32_file(slice_data.data() + command.offset + 16, 0, header.big);
        }
        rewritten.push_back(std::move(slice_data));
    }
    std::vector<uint8_t> output;
    if (slices.size() == 1 && slices.front().offset == 0 && slices.front().size == data.size()) output = std::move(rewritten.front());
    else output = macho::rebuild_fat_with_format_impl(rewritten, slices.front().fat64_container, slices.front().fat_cigam_container);
    if (!write_bytes_local(path, output)) throw std::runtime_error("failed to write cryptid reset");
}

inline void unsign_impl(const std::filesystem::path& path) {
    auto data = read_bytes_local(path);
    auto stripped = unsign_memory_impl(data);
    write_bytes_local(path, stripped);
}

inline void deep_sign_impl(const std::filesystem::path& path, const SignOptions& options) {
    sign_impl(path, options);
}

inline void super_deep_sign_impl(const std::filesystem::path& path, const SignOptions& options) {
    SignOptions adjusted = options;
    adjusted.deep = true;
    adjusted.super_deep = true;
    sign_impl(path, adjusted);
}

inline void merge_entitlements_impl(const std::filesystem::path& path, const SignOptions& options) {
    SignOptions adjusted = options;
    adjusted.preserve_entitlements = true;
    adjusted.merge_only = true;
    sign_impl(path, adjusted);
}

inline void sign_ipa_impl(const std::filesystem::path& ipa, const std::filesystem::path& out, const SignOptions& options) {
    std::string work_dir = make_temp_dir();
    archive::extract_ipa_impl(ipa, work_dir);
    auto plan = build_sign_plan_impl(work_dir);
    sign_plan_impl(plan, options);
    archive::repack_ipa_impl(work_dir, out.empty() ? ipa : out);
    std::error_code ec;
    std::filesystem::remove_all(work_dir, ec);
}

inline void sign_archive_impl(const std::filesystem::path& archive_path, const std::filesystem::path& out, const SignOptions& options) {
    std::string work_dir = make_temp_dir();
    archive::extract_archive_impl(archive_path, work_dir);
    auto plan = build_sign_plan_impl(work_dir);
    sign_plan_impl(plan, options);
    archive::create_archive_impl(work_dir, out.empty() ? archive_path : out, archive::detect_format_impl(archive_path));
    std::error_code ec;
    std::filesystem::remove_all(work_dir, ec);
}

inline void sign_bundle_impl(const std::filesystem::path& bundle, const SignOptions& options) {
    sign_bundle_tree_impl(bundle, options);
}

}

}
#include "ldid.hpp"
#include <openssl/x509_vfy.h>

namespace ldid {

namespace verifier {

struct SuperBlobParseResult {
    bool valid = false;
    std::map<uint32_t, std::vector<uint8_t>> slots;
    std::vector<uint8_t> cms;
};

inline SuperBlobParseResult parse_superblob(const std::vector<uint8_t>& signature) {
    SuperBlobParseResult result;
    if (signature.size() < 12 || load_be32(signature.data()) != macho::SUPERBLOB_MAGIC) return result;
    uint32_t length = load_be32(signature.data() + 4);
    uint32_t count = load_be32(signature.data() + 8);
    if (length < 12 || length > signature.size() || count > (length - 12) / 8) return result;
    size_t pos = 12;
    for (uint32_t i = 0; i < count; ++i) {
        uint32_t type = load_be32(signature.data() + pos);
        uint32_t offset = load_be32(signature.data() + pos + 4);
        pos += 8;
        if (offset < 12 || offset + 8 > length) return result;
        uint32_t blob_length = load_be32(signature.data() + offset + 4);
        if (blob_length < 8 || offset + blob_length > length) return result;
        if (result.slots.find(type) != result.slots.end()) return result;
        auto whole = macho::whole_blob(signature, offset);
        if (whole.size() != blob_length) return result;
        result.slots.emplace(type, std::move(whole));
        if (type == macho::SLOT_CMS_SIGNATURE) result.cms = macho::blob_content(signature, offset);
    }
    result.valid = true;
    return result;
}

struct CodeDirectoryView {
    std::vector<uint8_t> blob;
    uint32_t version = 0;
    uint32_t flags = 0;
    uint32_t hash_offset = 0;
    uint32_t ident_offset = 0;
    uint32_t n_special = 0;
    uint32_t n_code = 0;
    uint64_t code_limit = 0;
    uint8_t hash_size = 0;
    uint8_t hash_type = 0;
    uint8_t page_size_exp = 0;
    uint32_t team_offset = 0;
};

inline std::optional<CodeDirectoryView> parse_code_directory(const std::vector<uint8_t>& blob) {
    if (blob.size() < 44 || load_be32(blob.data()) != macho::CODEDIRECTORY_MAGIC) return std::nullopt;
    CodeDirectoryView view;
    view.blob = blob;
    view.version = load_be32(blob.data() + 8);
    view.flags = load_be32(blob.data() + 12);
    view.hash_offset = load_be32(blob.data() + 16);
    view.ident_offset = load_be32(blob.data() + 20);
    view.n_special = load_be32(blob.data() + 24);
    view.n_code = load_be32(blob.data() + 28);
    view.code_limit = load_be32(blob.data() + 32);
    view.hash_size = blob[36];
    view.hash_type = blob[37];
    view.page_size_exp = blob[39];
    if (view.version >= 0x20200 && blob.size() >= 52) view.team_offset = load_be32(blob.data() + 48);
    if (view.version >= 0x20300 && blob.size() >= 64) view.code_limit = load_be64(blob.data() + 56);
    const uint8_t expected_hash_size = view.hash_type == 1 ? 20 : (view.hash_type == 2 ? 32 : (view.hash_type == 3 ? 20 : (view.hash_type == 4 ? 48 : 0)));
    if (expected_hash_size == 0 || view.hash_size != expected_hash_size) return std::nullopt;
    if (view.hash_offset > blob.size()) return std::nullopt;
    const uint64_t special_bytes = static_cast<uint64_t>(view.n_special) * view.hash_size;
    const uint64_t code_bytes = static_cast<uint64_t>(view.n_code) * view.hash_size;
    if (special_bytes > view.hash_offset ||
        static_cast<uint64_t>(view.hash_offset) + code_bytes > blob.size() ||
        view.ident_offset >= blob.size()) return std::nullopt;
    const size_t special_start = static_cast<size_t>(static_cast<uint64_t>(view.hash_offset) - special_bytes);
    if (special_start < view.ident_offset) return std::nullopt;
    const auto ident_end = std::find(blob.begin() + view.ident_offset, blob.begin() + special_start, static_cast<uint8_t>(0));
    if (ident_end == blob.begin() + special_start) return std::nullopt;
    return view;
}

inline bool stored_hash_is_zero(const std::vector<uint8_t>& blob, size_t offset, size_t size) {
    if (offset + size > blob.size()) return true;
    for (size_t i = 0; i < size; ++i) {
        if (blob[offset + i] != 0) return false;
    }
    return true;
}

struct RequirementFacts {
    bool valid = false;
    bool has_identifier = false;
    bool has_team = false;
    std::string identifier;
    std::string team_id;
};

inline bool parse_requirement_expression_facts(const std::vector<uint8_t>& data, size_t& pos, RequirementFacts& facts) {
    if (pos + 4 > data.size()) return false;
    uint32_t op = load_be32(data.data() + pos); pos += 4;
    auto read_string = [&](std::string& out) -> bool {
        if (pos + 4 > data.size()) return false;
        uint32_t len = load_be32(data.data() + pos); pos += 4;
        if (len > data.size() - pos) return false;
        out.assign(reinterpret_cast<const char*>(data.data() + pos), len);
        pos += len;
        while ((pos & 3U) != 0) { if (pos >= data.size()) return false; ++pos; }
        return true;
    };
    if (op == 0 || op == 1 || op == 3 || op == 15 || op == 17 || op == 18 || op == 21 || op == 23) return true;
    if (op == 2) {
        std::string value; if (!read_string(value)) return false;
        facts.identifier = value; facts.has_identifier = true; return true;
    }
    if (op == 4 || op == 8) {
        if (pos + 20 > data.size()) return false;
        pos += 20; return true;
    }
    if (op == 6 || op == 7) {
        RequirementFacts left, right;
        if (!parse_requirement_expression_facts(data, pos, left) || !parse_requirement_expression_facts(data, pos, right)) return false;
        if (op == 6) {
            if (left.has_identifier) { facts.identifier = left.identifier; facts.has_identifier = true; }
            if (right.has_identifier) { facts.identifier = right.identifier; facts.has_identifier = true; }
            if (left.has_team) { facts.team_id = left.team_id; facts.has_team = true; }
            if (right.has_team) { facts.team_id = right.team_id; facts.has_team = true; }
        } else {
            if (left.has_identifier && right.has_identifier && left.identifier == right.identifier) { facts.identifier = left.identifier; facts.has_identifier = true; }
            if (left.has_team && right.has_team && left.team_id == right.team_id) { facts.team_id = left.team_id; facts.has_team = true; }
        }
        return true;
    }
    if (op == 9) return parse_requirement_expression_facts(data, pos, facts);
    if (op == 5) {
        std::string key, value; if (!read_string(key) || !read_string(value)) return false; return true;
    }
    if (op == 10 || op == 16) {
        std::string field; if (!read_string(field) || pos + 4 > data.size()) return false;
        uint32_t match = load_be32(data.data() + pos); pos += 4;
        if (match != 0 && match != 14) { std::string value; if (!read_string(value)) return false; }
        return true;
    }
    if (op == 11) {
        if (pos + 4 > data.size()) return false;
        uint32_t cert_index = load_be32(data.data() + pos); pos += 4;
        std::string field; if (!read_string(field) || pos + 4 > data.size()) return false;
        uint32_t match = load_be32(data.data() + pos); pos += 4;
        std::string value; if (match != 0 && match != 14 && !read_string(value)) return false;
        if (cert_index == 0 && field == "subject.OU" && match == 1) { facts.team_id = value; facts.has_team = true; }
        return true;
    }
    if (op == 12 || op == 13) { if (pos + 4 > data.size()) return false; pos += 4; return true; }
    if (op == 14 || op == 17) {
        if (pos + 4 > data.size()) return false; pos += 4;
        std::string oid; if (!read_string(oid) || pos + 4 > data.size()) return false;
        uint32_t match = load_be32(data.data() + pos); pos += 4;
        if (match != 0 && match != 14) { std::string value; if (!read_string(value)) return false; }
        return true;
    }
    if (op == 19) { std::string name; return read_string(name); }
    if (op == 20) { if (pos + 4 > data.size()) return false; pos += 4; return true; }
    if (op == 22) {
        if (pos + 4 > data.size()) return false; pos += 4;
        std::string field; if (!read_string(field) || pos + 4 > data.size()) return false;
        uint32_t match = load_be32(data.data() + pos); pos += 4;
        if (match != 0 && match != 14) { std::string value; if (!read_string(value)) return false; }
        return true;
    }
    return false;
}

inline RequirementFacts parse_designated_requirement_facts(const std::vector<uint8_t>& blob) {
    RequirementFacts facts;
    if (blob.size() < 20 || load_be32(blob.data()) != macho::REQUIREMENTS_MAGIC) return facts;
    uint32_t count = load_be32(blob.data() + 8);
    if (count == 0 || count > (blob.size() - 12) / 8) return facts;
    bool found = false;
    for (uint32_t i = 0; i < count; ++i) {
        size_t entry = 12 + static_cast<size_t>(i) * 8;
        if (entry + 8 > blob.size()) return facts;
        uint32_t type = load_be32(blob.data() + entry);
        uint32_t offset = load_be32(blob.data() + entry + 4);
        if (type != 3 || offset + 12 > blob.size()) continue;
        uint32_t magic = load_be32(blob.data() + offset);
        uint32_t length = load_be32(blob.data() + offset + 4);
        uint32_t kind = load_be32(blob.data() + offset + 8);
        if (magic != 0xfade0c00U || kind != 1 || length < 12 || offset + length > blob.size()) return facts;
        size_t pos = offset + 12;
        if (!parse_requirement_expression_facts(blob, pos, facts) || pos != offset + length) return facts;
        found = true;
        break;
    }
    facts.valid = found;
    return facts;
}

inline VerificationResult verify_thin_memory(const std::vector<uint8_t>& data) {
    VerificationResult result;
    result.ok = false;
    auto analysis = macho::analyze_thin(data, 0);
    if (!analysis.valid) {
        result.message = "invalid Mach-O";
        result.errors.push_back("invalid Mach-O");
        return result;
    }
    if (analysis.code_signature_size == 0 || analysis.code_signature_offset == 0) {
        result.message = "no embedded signature";
        result.errors.push_back("no embedded signature");
        return result;
    }
    if (analysis.code_signature_offset + analysis.code_signature_size > data.size()) {
        result.message = "signature out of bounds";
        result.errors.push_back("signature out of bounds");
        return result;
    }
    std::vector<uint8_t> signature(data.begin() + analysis.code_signature_offset,
                                   data.begin() + analysis.code_signature_offset + analysis.code_signature_size);
    auto parsed = parse_superblob(signature);
    if (!parsed.valid) {
        result.message = "invalid superblob";
        result.errors.push_back("invalid superblob");
        return result;
    }
    auto cd_iterator = parsed.slots.find(macho::SLOT_CODEDIRECTORY);
    if (cd_iterator == parsed.slots.end()) {
        result.message = "missing CodeDirectory";
        result.errors.push_back("missing CodeDirectory");
        return result;
    }
    auto cd_optional = parse_code_directory(cd_iterator->second);
    if (!cd_optional) {
        result.message = "invalid CodeDirectory";
        result.errors.push_back("invalid CodeDirectory");
        return result;
    }
    auto cd = *cd_optional;
    HashType hash_type = cd.hash_type == 1 ? HashType::SHA1 : (cd.hash_type == 2 ? HashType::SHA256 : (cd.hash_type == 3 ? HashType::SHA256_TRUNCATED : HashType::SHA384));
    if (cd.code_limit > analysis.code_signature_offset || cd.code_limit > data.size()) {
        result.message = "code limit out of bounds";
        result.errors.push_back("code limit out of bounds");
        return result;
    }
    uint64_t page_size = cd.page_size_exp == 0 ? 4096 : (1ULL << cd.page_size_exp);
    uint64_t expected_slots = (cd.code_limit + page_size - 1) / page_size;
    if (expected_slots != cd.n_code) {
        result.message = "code slot count mismatch";
        result.errors.push_back("code slot count mismatch");
        return result;
    }
    for (uint64_t slot = 0; slot < cd.n_code; ++slot) {
        size_t start = static_cast<size_t>(slot * page_size);
        size_t end = std::min(static_cast<size_t>(cd.code_limit), start + static_cast<size_t>(page_size));
        std::vector<uint8_t> block(data.begin() + start, data.begin() + end);
        auto digest = crypto::hash_impl(hash_type, block);
        size_t offset = cd.hash_offset + static_cast<size_t>(slot * cd.hash_size);
        if (offset + cd.hash_size > cd.blob.size() || digest.size() < cd.hash_size ||
            !std::equal(digest.begin(), digest.begin() + cd.hash_size, cd.blob.begin() + offset)) {
            result.message = "code hash mismatch";
            result.errors.push_back("code hash mismatch at slot " + std::to_string(slot));
            return result;
        }
    }
    auto verify_code_directory = [&](const std::vector<uint8_t>& directory) -> bool {
        auto alternate = parse_code_directory(directory);
        if (!alternate) return false;
        auto av = *alternate;
        HashType alternate_hash = av.hash_type == 1 ? HashType::SHA1 : (av.hash_type == 2 ? HashType::SHA256 : (av.hash_type == 3 ? HashType::SHA256_TRUNCATED : HashType::SHA384));
        if (av.code_limit > analysis.code_signature_offset || av.code_limit > data.size()) return false;
        uint64_t alternate_page_size = av.page_size_exp == 0 ? 4096 : (1ULL << av.page_size_exp);
        if ((av.code_limit + alternate_page_size - 1) / alternate_page_size != av.n_code) return false;
        for (uint64_t slot = 0; slot < av.n_code; ++slot) {
            size_t start = static_cast<size_t>(slot * alternate_page_size);
            size_t end = std::min(static_cast<size_t>(av.code_limit), start + static_cast<size_t>(alternate_page_size));
            auto digest = crypto::hash_impl(alternate_hash, std::vector<uint8_t>(data.begin() + start, data.begin() + end));
            size_t offset = av.hash_offset + static_cast<size_t>(slot * av.hash_size);
            if (offset + av.hash_size > av.blob.size() || digest.size() < av.hash_size || !std::equal(digest.begin(), digest.begin() + av.hash_size, av.blob.begin() + offset)) return false;
        }
        return true;
    };
    auto alternate_iterator = parsed.slots.find(static_cast<uint32_t>(CodeSignSlot::ALTERNATE_BASE));
    if (alternate_iterator != parsed.slots.end() && !verify_code_directory(alternate_iterator->second)) {
        result.message = "alternate CodeDirectory verification failed";
        result.errors.push_back("alternate CodeDirectory verification failed");
        return result;
    }
    auto req_iterator = parsed.slots.find(macho::SLOT_REQUIREMENTS);
    if (req_iterator != parsed.slots.end()) {
        auto facts = parse_designated_requirement_facts(req_iterator->second);
        auto signature_info = macho::get_signature_info_impl(data);
        if (!facts.valid) {
            result.message = "invalid designated requirement";
            result.errors.push_back("invalid designated requirement");
            return result;
        }
        if (facts.has_identifier && facts.identifier != signature_info.identifier) {
            result.message = "designated requirement identifier mismatch";
            result.errors.push_back("designated requirement identifier mismatch");
            return result;
        }
        if (!signature_info.team_id.empty() && facts.has_team && facts.team_id != signature_info.team_id) {
            result.message = "designated requirement team mismatch";
            result.errors.push_back("designated requirement team mismatch");
            return result;
        }
    }

    auto check_special = [&](uint32_t slot_type, uint32_t special_index) {
        auto iterator = parsed.slots.find(slot_type);
        if (iterator == parsed.slots.end()) return;
        if (special_index == 0 || special_index > cd.n_special || cd.hash_size == 0 ||
            cd.hash_offset < static_cast<uint64_t>(special_index) * cd.hash_size) {
            result.message = "special slot missing";
            result.errors.push_back("special slot missing for type " + std::to_string(slot_type));
            return;
        }
        size_t offset = cd.hash_offset - static_cast<size_t>(special_index) * cd.hash_size;
        if (offset > cd.blob.size() || cd.hash_size > cd.blob.size() - offset) {
            result.message = "special slot out of bounds";
            result.errors.push_back("special slot out of bounds for type " + std::to_string(slot_type));
            return;
        }
        if (stored_hash_is_zero(cd.blob, offset, cd.hash_size)) return;
        auto digest = crypto::hash_impl(hash_type, iterator->second);
        if (digest.size() < cd.hash_size ||
            !std::equal(digest.begin(), digest.begin() + cd.hash_size, cd.blob.begin() + offset)) {
            result.message = "special slot hash mismatch";
            result.errors.push_back("special slot hash mismatch for type " + std::to_string(slot_type));
        }
    };
    check_special(macho::SLOT_REQUIREMENTS, 2);
    check_special(macho::SLOT_ENTITLEMENTS, 5);
    check_special(macho::SLOT_DER_ENTITLEMENTS, 7);
    if (!result.errors.empty()) {
        result.ok = false;
        return result;
    }
    if (!parsed.cms.empty()) {
        if (!crypto::verify_pkcs7_impl(cd.blob, parsed.cms)) {
            result.message = "CMS verification failed";
            result.errors.push_back("CMS verification failed");
            return result;
        }
    }
    result.ok = true;
    result.message = "valid";
    return result;
}

inline VerificationResult verify_memory_impl(const std::vector<uint8_t>& data) {
    VerificationResult result;
    result.ok = true;
    result.message = "valid";
    if (data.size() < 8) {
        result.ok = false;
        result.message = "file too small";
        result.errors.push_back("file too small");
        return result;
    }
    uint32_t be_magic = load_be32(data.data());
    if (be_magic == macho::FAT_MAGIC || be_magic == macho::FAT_MAGIC_64 || be_magic == macho::FAT_CIGAM || be_magic == macho::FAT_CIGAM_64) {
        auto slices = macho::parse_slices_impl(data);
        if (slices.empty()) {
            result.ok = false;
            result.message = "no slices";
            result.errors.push_back("no slices");
            return result;
        }
        size_t index = 0;
        for (auto& slice : slices) {
            std::vector<uint8_t> slice_data(data.begin() + slice.offset, data.begin() + slice.offset + slice.size);
            auto slice_result = verify_thin_memory(slice_data);
            if (!slice_result.ok) {
                result.ok = false;
                result.message = "fat verification failed";
                for (auto& error : slice_result.errors) {
                    result.errors.push_back("slice " + std::to_string(index) + ": " + error);
                }
            }
            ++index;
        }
        return result;
    }
    return verify_thin_memory(data);
}

inline bool verify_bundle_resources_impl(const std::filesystem::path& bundle, const std::vector<uint8_t>& executable_data, std::vector<std::string>& errors) {
    std::filesystem::path code_resources = bundle / "_CodeSignature" / "CodeResources";
    auto resource_data = read_file(code_resources);
    if (resource_data.empty()) { errors.push_back("CodeResources unreadable"); return false; }
    auto plist = plist_from_xml_bytes(resource_data);
    if (!plist || plist_get_node_type(plist) != PLIST_DICT) { if (plist) plist_free(plist); errors.push_back("invalid CodeResources plist"); return false; }
    plist_t files2 = plist_dict_get_item(plist, "files2");
    if (!files2 || plist_get_node_type(files2) != PLIST_DICT) { plist_free(plist); errors.push_back("CodeResources files2 missing"); return false; }
    auto signature_info = macho::get_signature_info_impl(executable_data);
    bool ok = true;
    auto add_error = [&](const std::string& value) { ok = false; errors.push_back(value); };
    std::set<std::string> sealed_resources;
    plist_dict_iter iterator = nullptr;
    plist_dict_new_iter(files2, &iterator);
    if (iterator) {
        for (;;) {
            char* key = nullptr;
            plist_t value = nullptr;
            plist_dict_next_item(files2, iterator, &key, &value);
            if (!key || !value) {
                free(key);
                break;
            }
            std::filesystem::path relative(key);
            sealed_resources.insert(relative.generic_string());
            std::filesystem::path target = bundle / relative;
            bool optional = false;
            if (plist_get_node_type(value) == PLIST_DICT) optional = plist_dict_bool(value, "optional");
            if (!std::filesystem::exists(target) && !std::filesystem::is_symlink(target)) {
                if (!optional) add_error("missing sealed resource: " + relative.generic_string());
                free(key);
                continue;
            }
            if (plist_get_node_type(value) == PLIST_DICT) {
                plist_t hash = plist_dict_get_item(value, "hash");
                if (hash) {
                    char* bytes = nullptr; uint64_t length = 0;
                    plist_get_data_val(hash, &bytes, &length);
                    if (!bytes || length != 20) add_error("invalid hash: " + relative.generic_string());
                    else {
                        auto actual = crypto::sha1_impl(read_file(target));
                        if (!std::equal(actual.begin(), actual.end(), reinterpret_cast<uint8_t*>(bytes))) add_error("resource SHA-1 mismatch: " + relative.generic_string());
                    }
                    if (bytes) free(bytes);
                }
                plist_t hash2 = plist_dict_get_item(value, "hash2");
                if (hash2) {
                    char* bytes = nullptr; uint64_t length = 0;
                    plist_get_data_val(hash2, &bytes, &length);
                    if (!bytes || length != 32) add_error("invalid hash2: " + relative.generic_string());
                    else {
                        auto actual = crypto::sha256_impl(read_file(target));
                        if (!std::equal(actual.begin(), actual.end(), reinterpret_cast<uint8_t*>(bytes))) add_error("resource SHA-256 mismatch: " + relative.generic_string());
                    }
                    if (bytes) free(bytes);
                }
                plist_t symlink = plist_dict_get_item(value, "symlink");
                if (symlink) {
                    char* expected = nullptr; plist_get_string_val(symlink, &expected);
                    if (!expected || !std::filesystem::is_symlink(target) || std::filesystem::read_symlink(target).generic_string() != expected) add_error("symlink mismatch: " + relative.generic_string());
                    if (expected) free(expected);
                }
                plist_t cdhash = plist_dict_get_item(value, "cdhash");
                if (cdhash) {
                    char* bytes = nullptr; uint64_t length = 0; plist_get_data_val(cdhash, &bytes, &length);
                    auto nested_exec = std::filesystem::is_directory(target) ? archive::find_executable_in_bundle_impl(target) : target;
                    auto nested_info = nested_exec.empty() ? SignatureInfo{} : macho::get_signature_info_impl(read_file(nested_exec));
                    if (!bytes || length != nested_info.cd_hash.size() || (!nested_info.cd_hash.empty() && !std::equal(nested_info.cd_hash.begin(), nested_info.cd_hash.end(), reinterpret_cast<uint8_t*>(bytes)))) add_error("nested code hash mismatch: " + relative.generic_string());
                    if (bytes) free(bytes);
                }
            }
            free(key);
        }
        free(iterator);
    }
    for (auto it = std::filesystem::recursive_directory_iterator(bundle, std::filesystem::directory_options::skip_permission_denied); it != std::filesystem::recursive_directory_iterator(); ++it) {
        if (!it->is_regular_file() && !it->is_symlink()) continue;
        const auto path = it->path();
        if (archive::path_is_under(path, bundle / "_CodeSignature")) continue;
        if (path == bundle / "Info.plist" || path == bundle / "PkgInfo") continue;
        const auto relative = std::filesystem::relative(path, bundle).generic_string();
        if (relative == ".DS_Store" || relative.rfind(".DS_Store/", 0) == 0) continue;
        bool inside_nested = false;
        for (const auto& entry : sealed_resources) {
            std::filesystem::path sealed(entry);
            if (archive::path_is_under(path, bundle / sealed) && std::filesystem::is_directory(bundle / sealed)) { inside_nested = true; break; }
        }
        if (inside_nested) continue;
        if (path != archive::find_executable_in_bundle_impl(bundle) && sealed_resources.find(relative) == sealed_resources.end()) {
            add_error("unsealed resource: " + relative);
        }
    }
    plist_free(plist);
    auto signature = macho::get_signature_info_impl(executable_data);
    if (signature.cd_hash.empty()) add_error("executable CodeDirectory missing");
    auto analysis = macho::analyze_thin(executable_data, 0);
    if (analysis.valid && analysis.code_signature_size != 0) {
        std::vector<uint8_t> sig(executable_data.begin() + analysis.code_signature_offset, executable_data.begin() + analysis.code_signature_offset + analysis.code_signature_size);
        auto parsed = parse_superblob(sig);
        auto cd = parsed.slots.find(macho::SLOT_CODEDIRECTORY);
        if (cd != parsed.slots.end()) {
            auto view = parse_code_directory(cd->second);
            if (view) {
                if (view->n_special < 3 || view->hash_offset < static_cast<uint64_t>(3) * view->hash_size) {
                    add_error("CodeResources special slot layout invalid");
                } else {
                    size_t offset = view->hash_offset - static_cast<size_t>(3ULL * view->hash_size);
                    auto expected = crypto::hash_impl(view->hash_type == 1 ? HashType::SHA1 : (view->hash_type == 2 ? HashType::SHA256 : (view->hash_type == 3 ? HashType::SHA256_TRUNCATED : HashType::SHA384)), resource_data);
                    if (offset > cd->second.size() || view->hash_size > cd->second.size() - offset || expected.size() < view->hash_size || !std::equal(expected.begin(), expected.begin() + view->hash_size, cd->second.begin() + offset)) add_error("CodeResources special slot mismatch");
                }
            }
        }
    }
    return ok;
}

inline VerificationResult verify_bundle_impl_depth(const std::filesystem::path& bundle, size_t depth) {
    VerificationResult result;
    if (depth > 64) {
        result.ok = false;
        result.message = "nested bundle depth exceeded";
        result.errors.push_back("nested bundle depth exceeded");
        return result;
    }
    result.ok = true;
    result.message = "valid";
    if (!std::filesystem::exists(bundle) || !std::filesystem::is_directory(bundle)) {
        result.ok = false;
        result.message = "bundle missing";
        result.errors.push_back("bundle missing");
        return result;
    }
    std::filesystem::path code_resources = bundle / "_CodeSignature" / "CodeResources";
    if (!std::filesystem::exists(code_resources)) {
        result.ok = false;
        result.message = "CodeResources missing";
        result.errors.push_back("CodeResources missing");
        return result;
    }
    auto executable = archive::find_executable_in_bundle_impl(bundle);
    if (executable.empty()) {
        result.ok = false;
        result.message = "executable missing";
        result.errors.push_back("executable missing");
        return result;
    }
    std::vector<std::filesystem::path> nested_bundles;
    for (auto iterator = std::filesystem::recursive_directory_iterator(bundle, std::filesystem::directory_options::skip_permission_denied);
         iterator != std::filesystem::recursive_directory_iterator();
         ++iterator) {
        if (iterator->is_directory() && iterator->path() != bundle && archive::is_signable_bundle_extension(iterator->path())) {
            bool nested = false;
            for (auto& existing : nested_bundles) {
                if (archive::path_is_under(iterator->path(), existing)) {
                    nested = true;
                    break;
                }
            }
            if (!nested) nested_bundles.push_back(iterator->path());
        }
    }
    for (auto& nested : nested_bundles) {
        auto nested_result = verify_bundle_impl_depth(nested, depth + 1);
        if (!nested_result.ok) {
            result.ok = false;
            result.message = "nested bundle verification failed";
            for (auto& error : nested_result.errors) {
                result.errors.push_back(nested.generic_string() + ": " + error);
            }
        }
    }
    for (auto iterator = std::filesystem::recursive_directory_iterator(bundle, std::filesystem::directory_options::skip_permission_denied);
         iterator != std::filesystem::recursive_directory_iterator();
         ++iterator) {
        if (!iterator->is_regular_file()) continue;
        auto path = iterator->path();
        if (path == executable) continue;
        if (archive::path_is_under(path, bundle / "_CodeSignature")) continue;
        bool inside_nested = false;
        for (auto& nested : nested_bundles) {
            if (archive::path_is_under(path, nested)) {
                inside_nested = true;
                break;
            }
        }
        if (inside_nested) continue;
        if (archive::is_macho_file_impl(path)) {
            std::ifstream input(path, std::ios::binary);
            std::vector<uint8_t> data((std::istreambuf_iterator<char>(input)), std::istreambuf_iterator<char>());
            auto file_result = verify_memory_impl(data);
            if (!file_result.ok) {
                result.ok = false;
                result.message = "bundle member verification failed";
                for (auto& error : file_result.errors) {
                    result.errors.push_back(path.generic_string() + ": " + error);
                }
            }
        }
    }
    std::ifstream executable_input(executable, std::ios::binary);
    std::vector<uint8_t> executable_data((std::istreambuf_iterator<char>(executable_input)), std::istreambuf_iterator<char>());
    auto executable_result = verify_memory_impl(executable_data);
    if (!executable_result.ok) {
        result.ok = false;
        result.message = "executable verification failed";
        for (auto& error : executable_result.errors) result.errors.push_back(executable.generic_string() + ": " + error);
    }
    std::vector<std::string> resource_errors;
    if (!verify_bundle_resources_impl(bundle, executable_data, resource_errors)) {
        result.ok = false;
        result.message = "resource seal verification failed";
        for (auto& error : resource_errors) result.errors.push_back(bundle.generic_string() + ": " + error);
    }
    return result;
}

inline VerificationResult verify_bundle_impl(const std::filesystem::path& bundle) {
    return verify_bundle_impl_depth(bundle, 0);
}

inline VerificationResult verify_archive_impl(const std::filesystem::path& archive_path) {
    VerificationResult result;
    result.ok = true;
    result.message = "valid";
    std::string work_dir = make_temp_dir();
    try {
        archive::extract_archive_impl(archive_path, work_dir);
    } catch (const std::exception& e) {
        result.ok = false;
        result.message = "archive extraction failed";
        result.errors.push_back(e.what());
        return result;
    }
    auto entries = archive::scan_for_signables_impl(work_dir);
    for (auto& entry : entries) {
        std::filesystem::path path(entry.path);
        VerificationResult entry_result;
        if (entry.is_directory) {
            entry_result = verify_bundle_impl(path);
        } else {
            std::ifstream input(path, std::ios::binary);
            std::vector<uint8_t> data((std::istreambuf_iterator<char>(input)), std::istreambuf_iterator<char>());
            entry_result = verify_memory_impl(data);
        }
        if (!entry_result.ok) {
            result.ok = false;
            result.message = "archive verification failed";
            for (auto& error : entry_result.errors) {
                result.errors.push_back(entry.path + ": " + error);
            }
        }
    }
    std::error_code ec;
    std::filesystem::remove_all(work_dir, ec);
    return result;
}

inline VerificationResult verify_path_impl(const std::filesystem::path& path) {
    if (!std::filesystem::exists(path)) {
        VerificationResult result;
        result.ok = false;
        result.message = "path missing";
        result.errors.push_back("path missing");
        return result;
    }
    if (std::filesystem::is_directory(path)) {
        if (archive::is_signable_bundle_extension(path)) {
            return verify_bundle_impl(path);
        }
        VerificationResult result;
        result.ok = true;
        result.message = "valid";
        auto entries = archive::scan_for_signables_impl(path);
        for (auto& entry : entries) {
            std::filesystem::path entry_path(entry.path);
            VerificationResult entry_result;
            if (entry.is_directory) {
                entry_result = verify_bundle_impl(entry_path);
            } else {
                std::ifstream input(entry_path, std::ios::binary);
                std::vector<uint8_t> data((std::istreambuf_iterator<char>(input)), std::istreambuf_iterator<char>());
                entry_result = verify_memory_impl(data);
            }
            if (!entry_result.ok) {
                result.ok = false;
                result.message = "directory verification failed";
                for (auto& error : entry_result.errors) {
                    result.errors.push_back(entry.path + ": " + error);
                }
            }
        }
        return result;
    }
    if (archive::is_archive_impl(path)) {
        return verify_archive_impl(path);
    }
    std::ifstream input(path, std::ios::binary);
    std::vector<uint8_t> data((std::istreambuf_iterator<char>(input)), std::istreambuf_iterator<char>());
    return verify_memory_impl(data);
}

inline bool verify_cms_with_system(const std::vector<uint8_t>& cd_blob, const std::vector<uint8_t>& cms) {
    const unsigned char* p = cms.data();
    Pkcs7Ptr p7(d2i_PKCS7(nullptr, &p, static_cast<long>(cms.size())));
    if (!p7.get()) return false;
    BioPtr data_bio(BIO_new_mem_buf(cd_blob.data(), static_cast<int>(cd_blob.size())));
    if (!data_bio.get()) return false;
    X509_STORE* store = X509_STORE_new();
    if (!store) return false;
    const bool store_ok = X509_STORE_set_default_paths(store) == 1;
    int result = store_ok ? PKCS7_verify(p7.get(), nullptr, store, data_bio.get(), nullptr, PKCS7_BINARY | PKCS7_DETACHED) : 0;
    X509_STORE_free(store);
    return result == 1;
}

#if defined(__APPLE__) && TARGET_OS_OSX
inline bool verify_with_apple_system(const std::filesystem::path& path) {
    const std::string native = path.string();
    CFURLRef url = CFURLCreateFromFileSystemRepresentation(kCFAllocatorDefault, reinterpret_cast<const UInt8*>(native.data()), native.size(), std::filesystem::is_directory(path));
    if (!url) return false;
    SecStaticCodeRef code = nullptr;
    OSStatus status = SecStaticCodeCreateWithPath(url, kSecCSDefaultFlags, &code);
    CFRelease(url);
    if (status != errSecSuccess || !code) return false;
    status = SecStaticCodeCheckValidity(code, kSecCSStrictValidate, nullptr);
    CFRelease(code);
    return status == errSecSuccess;
}
#endif

inline VerificationResult verify_with_system_impl(const std::filesystem::path& path) {
#if defined(__APPLE__) && TARGET_OS_OSX
    VerificationResult result;
    result.ok = verify_with_apple_system(path);
    result.message = result.ok ? "valid" : "Apple system trust/validation failed";
    if (!result.ok) result.errors.push_back(result.message);
    return result;
#else
    auto result = verify_path_impl(path);
    if (!result.ok) return result;
    if (!std::filesystem::is_regular_file(path) || archive::is_archive_impl(path)) return result;
    std::ifstream input(path, std::ios::binary);
    std::vector<uint8_t> data((std::istreambuf_iterator<char>(input)), std::istreambuf_iterator<char>());
    if (!macho::is_macho_impl(data)) return result;
    auto analysis = macho::analyze_thin(data, 0);
    if (!analysis.valid || analysis.code_signature_size == 0) return result;
    std::vector<uint8_t> signature(data.begin() + analysis.code_signature_offset, data.begin() + analysis.code_signature_offset + analysis.code_signature_size);
    auto parsed = parse_superblob(signature);
    if (!parsed.valid || parsed.cms.empty()) return result;
    auto cd_iterator = parsed.slots.find(macho::SLOT_CODEDIRECTORY);
    if (cd_iterator == parsed.slots.end()) return result;
    if (!verify_cms_with_system(cd_iterator->second, parsed.cms)) {
        result.ok = false;
        result.message = "system CMS verification failed";
        result.errors.push_back("system CMS verification failed");
    }
    return result;
#endif
}

}

std::vector<uint8_t> CryptoEngine::sha1(const std::vector<uint8_t>& data) {
    return crypto::sha1_impl(data);
}

std::vector<uint8_t> CryptoEngine::sha256(const std::vector<uint8_t>& data) {
    return crypto::sha256_impl(data);
}

std::vector<uint8_t> CryptoEngine::hash(HashType type, const std::vector<uint8_t>& data) {
    return crypto::hash_impl(type, data);
}

std::vector<uint8_t> CryptoEngine::sign_pkcs7(const std::vector<uint8_t>& data, const std::string& cert_path, const std::string& key_path, const std::string& password) {
    return crypto::sign_pkcs7_impl(data, cert_path, key_path, password);
}

bool CryptoEngine::verify_pkcs7(const std::vector<uint8_t>& data, const std::vector<uint8_t>& signature) {
    return crypto::verify_pkcs7_impl(data, signature);
}

std::vector<uint8_t> CryptoEngine::build_apple_cdhash_attr(const std::vector<uint8_t>& cd_hash, HashType hash_type) {
    return crypto::build_apple_cdhash_attr_impl(cd_hash, hash_type);
}

std::vector<std::vector<uint8_t>> CryptoEngine::extract_certs_raw(const std::string& cert_path) {
    return crypto::extract_certs_raw_impl(cert_path);
}

bool KeychainManager::load_p12(const std::string& path, const std::string& password, std::vector<uint8_t>& cert_der, std::vector<uint8_t>& key_der) {
    return crypto::load_p12_impl(path, password, cert_der, key_der);
}

std::string KeychainManager::extract_team_id_from_certificate_file(const std::string& cert_path) {
    return crypto::extract_team_id_from_certificate_file_impl(cert_path);
}

std::string KeychainManager::extract_team_id_from_p12(const std::string& p12_path, const std::string& password) {
    return crypto::extract_team_id_from_p12_impl(p12_path, password);
}

std::vector<uint8_t> KeychainManager::get_public_key_hash(const std::string& cert_path) {
    return crypto::get_public_key_hash_impl(cert_path);
}

bool MachOParser::is_macho(const std::vector<uint8_t>& data) {
    return macho::is_macho_impl(data);
}

std::vector<Slice> MachOParser::parse_slices(const std::vector<uint8_t>& data) {
    return macho::parse_slices_impl(data);
}

std::vector<uint8_t> MachOParser::select_slice(const std::vector<uint8_t>& data, const std::string& arch) {
    return macho::select_slice_impl(data, arch);
}

SignatureInfo MachOParser::get_signature_info(const std::vector<uint8_t>& data) {
    return macho::get_signature_info_impl(data);
}

std::vector<uint8_t> MachOParser::strip_signature(const std::vector<uint8_t>& data) {
    return macho::strip_signature_impl(data);
}

std::vector<uint8_t> MachOParser::embed_signature(const std::vector<uint8_t>& data, const std::vector<uint8_t>& signature) {
    return macho::embed_signature_impl(data, signature);
}

std::vector<uint8_t> MachOParser::rebuild_fat(const std::vector<std::vector<uint8_t>>& slices) {
    return macho::rebuild_fat_impl(slices);
}

std::vector<uint8_t> BlobBuilder::make_blob(BlobMagic magic, const std::vector<uint8_t>& data) {
    return blob::make_blob_impl(static_cast<uint32_t>(magic), data);
}

std::vector<uint8_t> BlobBuilder::build_superblob(const std::map<uint32_t, std::vector<uint8_t>>& blobs) {
    return blob::build_superblob_impl(blobs);
}

std::vector<uint8_t> BlobBuilder::build_code_directory(const std::vector<uint8_t>& code, const std::string& identifier, const std::string& team_id, HashType hash_type, uint32_t flags) {
    return blob::build_code_directory_impl(code, identifier, team_id, hash_type, flags);
}

std::vector<uint8_t> BlobBuilder::build_cd_versioned(const std::vector<uint8_t>& code, const std::string& identifier, const std::string& team_id, HashType hash_type, uint32_t flags, uint32_t version) {
    return blob::build_cd_versioned_impl(code, identifier, team_id, hash_type, flags, version);
}

std::vector<uint8_t> BlobBuilder::build_entitlements_blob(const std::string& xml) {
    return blob::build_entitlements_blob_impl(xml);
}

std::vector<uint8_t> BlobBuilder::build_der_entitlements_blob(const std::string& xml) {
    return blob::build_der_entitlements_blob_impl(xml);
}

std::vector<uint8_t> BlobBuilder::build_requirements_blob(const std::string& identifier, const std::string& team_id) {
    return blob::build_requirements_blob_impl(identifier, team_id);
}

std::vector<uint8_t> BlobBuilder::build_dr(const std::string& identifier, const std::string& team_id) {
    return blob::build_dr_impl(identifier, team_id);
}

std::vector<uint8_t> BlobBuilder::compile_requirements(const std::string& xml) {
    return blob::compile_requirements_impl(xml);
}

std::vector<uint8_t> BlobBuilder::der_encode_plist_xml(const std::string& xml) {
    std::vector<uint8_t> xml_bytes(xml.begin(), xml.end());
    plist_t root = plist_from_xml_bytes(xml_bytes);
    if (!root) return {};
    std::vector<uint8_t> der = der_encode_plist_node(root);
    plist_free(root);
    return der;
}

bool ArchiveEngine::is_archive(const std::filesystem::path& path) {
    return archive::is_archive_impl(path);
}

ArchiveFormat ArchiveEngine::detect_format(const std::filesystem::path& path) {
    return archive::detect_format_impl(path);
}

std::vector<ArchiveEntryInfo> ArchiveEngine::list_contents(const std::filesystem::path& path) {
    return archive::list_contents_impl(path);
}

std::vector<ArchiveEntryInfo> ArchiveEngine::scan_for_signables(const std::filesystem::path& dir) {
    return archive::scan_for_signables_impl(dir);
}

void ArchiveEngine::extract_archive(const std::filesystem::path& archive_path, const std::filesystem::path& out_dir) {
    archive::extract_archive_impl(archive_path, out_dir);
}

void ArchiveEngine::create_archive(const std::filesystem::path& dir, const std::filesystem::path& out, ArchiveFormat format) {
    archive::create_archive_impl(dir, out, format);
}

void ArchiveEngine::create_ipa(const std::filesystem::path& dir, const std::filesystem::path& out) {
    archive::create_ipa_impl(dir, out);
}

void ArchiveEngine::create_zip(const std::filesystem::path& dir, const std::filesystem::path& out) {
    archive::create_zip_impl(dir, out);
}

void ArchiveEngine::create_tar(const std::filesystem::path& dir, const std::filesystem::path& out) {
    archive::create_tar_impl(dir, out);
}

void ArchiveEngine::extract_ipa(const std::filesystem::path& ipa, const std::filesystem::path& dir) {
    archive::extract_ipa_impl(ipa, dir);
}

void ArchiveEngine::repack_ipa(const std::filesystem::path& dir, const std::filesystem::path& out) {
    archive::repack_ipa_impl(dir, out);
}

std::filesystem::path ArchiveEngine::find_app_bundle(const std::filesystem::path& dir) {
    return archive::find_app_bundle_impl(dir);
}

std::filesystem::path ArchiveEngine::find_executable_in_bundle(const std::filesystem::path& bundle) {
    return archive::find_executable_in_bundle_impl(bundle);
}

void ArchiveEngine::stream_sign(const std::filesystem::path& in, const std::filesystem::path& out, const SignOptions& options) {
    archive::stream_sign_impl(in, out, options);
}

void Signer::sign(const std::filesystem::path& path, const SignOptions& options) {
    signer::sign_impl(path, options);
}

std::vector<uint8_t> Signer::sign_memory(const std::vector<uint8_t>& data, const SignOptions& options) {
    return signer::sign_macho_memory_impl(data, options, {}, {});
}

void Signer::unsign(const std::filesystem::path& path) {
    signer::unsign_impl(path);
}

void Signer::reset_cryptid(const std::filesystem::path& path) {
    signer::reset_cryptid_impl(path);
}

std::vector<uint8_t> Signer::unsign_memory(const std::vector<uint8_t>& data) {
    return signer::unsign_memory_impl(data);
}

void Signer::deep_sign(const std::filesystem::path& path, const SignOptions& options) {
    signer::deep_sign_impl(path, options);
}

void Signer::super_deep_sign(const std::filesystem::path& path, const SignOptions& options) {
    signer::super_deep_sign_impl(path, options);
}

void Signer::merge_entitlements(const std::filesystem::path& path, const SignOptions& options) {
    signer::merge_entitlements_impl(path, options);
}

void Signer::sign_ipa(const std::filesystem::path& ipa, const std::filesystem::path& out, const SignOptions& options) {
    signer::sign_ipa_impl(ipa, out, options);
}

void Signer::sign_archive(const std::filesystem::path& archive, const std::filesystem::path& out, const SignOptions& options) {
    signer::sign_archive_impl(archive, out, options);
}

void Signer::sign_bundle(const std::filesystem::path& bundle, const SignOptions& options) {
    signer::sign_bundle_impl(bundle, options);
}

void Signer::sign_plan(const ArchiveSignPlan& plan, const SignOptions& options) {
    signer::sign_plan_impl(plan, options);
}

VerificationResult Verifier::verify(const std::filesystem::path& path) {
    return verifier::verify_path_impl(path);
}

VerificationResult Verifier::verify_memory(const std::vector<uint8_t>& data) {
    return verifier::verify_memory_impl(data);
}

VerificationResult Verifier::verify_with_system(const std::filesystem::path& path) {
    return verifier::verify_with_system_impl(path);
}

VerificationResult Verifier::verify_bundle(const std::filesystem::path& bundle) {
    return verifier::verify_bundle_impl(bundle);
}

VerificationResult Verifier::verify_archive(const std::filesystem::path& archive) {
    return verifier::verify_archive_impl(archive);
}

void Display::display_info(const std::filesystem::path& path) {
    if (!std::filesystem::exists(path)) {
        std::cout << path.generic_string() << ": missing" << std::endl;
        return;
    }
    if (std::filesystem::is_directory(path)) {
        std::cout << path.generic_string() << ": directory" << std::endl;
        auto entries = ArchiveEngine::scan_for_signables(path);
        std::cout << "signables: " << entries.size() << std::endl;
        return;
    }
    if (ArchiveEngine::is_archive(path)) {
        std::cout << path.generic_string() << ": archive" << std::endl;
        auto entries = ArchiveEngine::list_contents(path);
        std::cout << "entries: " << entries.size() << std::endl;
        return;
    }
    auto data = read_file(path);
    std::cout << path.generic_string() << ": file" << std::endl;
    std::cout << "size: " << data.size() << std::endl;
    if (MachOParser::is_macho(data)) {
        auto slices = MachOParser::parse_slices(data);
        std::cout << "macho: true" << std::endl;
        std::cout << "slices: " << slices.size() << std::endl;
        auto info = MachOParser::get_signature_info(data);
        if (!info.identifier.empty()) std::cout << "identifier: " << info.identifier << std::endl;
        if (!info.team_id.empty()) std::cout << "team: " << info.team_id << std::endl;
        if (!info.cd_hash.empty()) std::cout << "cdhash: " << to_hex(info.cd_hash) << std::endl;
    } else {
        std::cout << "macho: false" << std::endl;
    }
}

void Display::display_signature(const std::filesystem::path& path) {
    auto data = read_file(path);
    if (!MachOParser::is_macho(data)) {
        std::cout << path.generic_string() << ": not a Mach-O" << std::endl;
        return;
    }
    auto info = MachOParser::get_signature_info(data);
    std::cout << "path: " << path.generic_string() << std::endl;
    std::cout << "identifier: " << info.identifier << std::endl;
    std::cout << "team: " << info.team_id << std::endl;
    const char* hash_name = info.hash_type == HashType::SHA1 ? "sha1" : (info.hash_type == HashType::SHA256 ? "sha256" : (info.hash_type == HashType::SHA256_TRUNCATED ? "sha256-truncated" : "sha384"));
    std::cout << "hash: " << hash_name << std::endl;
    std::cout << "cdhash: " << to_hex(info.cd_hash) << std::endl;
    std::cout << "flags: 0x" << std::hex << info.flags << std::dec << std::endl;
    std::cout << "version: 0x" << std::hex << info.version << std::dec << std::endl;
    std::cout << "adhoc: " << (info.adhoc ? "true" : "false") << std::endl;
    std::cout << "cms: " << (info.cms_signature.empty() ? "false" : "true") << std::endl;
    std::cout << "entitlements: " << (info.entitlements_xml.empty() ? "false" : "true") << std::endl;
    std::cout << "der-entitlements: " << (info.entitlements_der.empty() ? "false" : "true") << std::endl;
    std::cout << "requirements: " << (info.requirements_blob.empty() ? "false" : "true") << std::endl;
}

void Display::display_entitlements(const std::filesystem::path& path) {
    auto data = read_file(path);
    if (!MachOParser::is_macho(data)) return;
    auto info = MachOParser::get_signature_info(data);
    if (!info.entitlements_xml.empty()) {
        std::cout << info.entitlements_xml;
    }
}

std::string decode_requirement_expression(const std::vector<uint8_t>& data, size_t& pos) {
    auto read_string = [&](std::string& out) -> bool {
        if (pos + 4 > data.size()) return false;
        uint32_t length = load_be32(data.data() + pos); pos += 4;
        if (length > data.size() - pos) return false;
        out.assign(reinterpret_cast<const char*>(data.data() + pos), length);
        pos += length;
        while ((pos & 3U) != 0) { if (pos >= data.size()) return false; ++pos; }
        return true;
    };
    if (pos + 4 > data.size()) return {};
    uint32_t op = load_be32(data.data() + pos); pos += 4;
    if (op == 0) return "false";
    if (op == 1) return "true";
    if (op == 2) { std::string value; if (!read_string(value)) return {}; return "identifier \"" + value + "\""; }
    if (op == 3) return "anchor apple";
    if (op == 4 || op == 8) {
        if (pos + 20 > data.size()) return {};
        std::vector<uint8_t> hash(data.begin() + static_cast<std::ptrdiff_t>(pos), data.begin() + static_cast<std::ptrdiff_t>(pos + 20)); pos += 20;
        return "cdhash " + hex_encode(hash);
    }
    if (op == 6 || op == 7) {
        auto lhs = decode_requirement_expression(data, pos); auto rhs = decode_requirement_expression(data, pos);
        if (lhs.empty() || rhs.empty()) return {};
        return "(" + lhs + ") " + (op == 6 ? "and" : "or") + " (" + rhs + ")";
    }
    if (op == 9) { auto child = decode_requirement_expression(data, pos); return child.empty() ? std::string() : "not (" + child + ")"; }
    if (op == 10 || op == 16) {
        std::string field; if (!read_string(field) || pos + 4 > data.size()) return {};
        uint32_t match = load_be32(data.data() + pos); pos += 4; std::string value;
        if (match != 0 && match != 14 && !read_string(value)) return {};
        const char* prefix = op == 10 ? "info" : "entitlement";
        if (match == 0) return std::string(prefix) + "[\"" + field + "\"] exists";
        if (match == 14) return std::string(prefix) + "[\"" + field + "\"] absent";
        const char* op_text = "=";
        switch (match) { case 2: op_text = "*="; break; case 3: op_text = "^="; break; case 4: op_text = "$="; break; case 5: op_text = "<"; break; case 6: op_text = "<="; break; case 7: op_text = ">"; break; case 8: op_text = ">="; break; default: break; }
        return std::string(prefix) + "[\"" + field + "\"] " + op_text + " \"" + value + "\"";
    }
    if (op == 11) {
        if (pos + 4 > data.size()) return {}; uint32_t cert = load_be32(data.data() + pos); pos += 4;
        std::string field; if (!read_string(field) || pos + 4 > data.size()) return {};
        uint32_t match = load_be32(data.data() + pos); pos += 4; std::string value;
        if (match != 0 && match != 14 && !read_string(value)) return {};
        std::string index = cert == 0 ? "leaf" : (cert == 0xFFFFFFFFU ? "root" : std::to_string(cert));
        if (match == 0) return "certificate " + index + "[" + field + "] exists";
        if (match == 14) return "certificate " + index + "[" + field + "] absent";
        return "certificate " + index + "[" + field + "] = \"" + value + "\"";
    }
    if (op == 14) {
        if (pos + 4 > data.size()) return {}; uint32_t cert = load_be32(data.data() + pos); pos += 4;
        std::string oid_bytes; if (!read_string(oid_bytes) || pos + 4 > data.size()) return {};
        uint32_t match = load_be32(data.data() + pos); pos += 4; std::string value;
        if (match != 0 && match != 14 && !read_string(value)) return {};
        std::string index = cert == 0 ? "leaf" : (cert == 0xFFFFFFFFU ? "root" : std::to_string(cert));
        std::vector<uint8_t> bytes(oid_bytes.begin(), oid_bytes.end());
        if (match == 0) return "certificate " + index + "[field." + hex_encode(bytes) + "] exists";
        if (match == 14) return "certificate " + index + "[field." + hex_encode(bytes) + "] absent";
        return "certificate " + index + "[field." + hex_encode(bytes) + "] = \"" + value + "\"";
    }
    if (op == 15) return "anchor apple generic";
    if (op == 20) { if (pos + 4 > data.size()) return {}; uint32_t platform = load_be32(data.data() + pos); pos += 4; return "platform = " + std::to_string(platform); }
    return "<unsupported opcode " + std::to_string(op) + ">";
}

std::string format_requirements_blob(const std::vector<uint8_t>& blob) {
    if (blob.size() < 20 || load_be32(blob.data()) != 0xfade0c01U) return {};
    uint32_t count = load_be32(blob.data() + 8);
    if (count == 0 || blob.size() < 20) return {};
    uint32_t type = load_be32(blob.data() + 12);
    uint32_t offset = load_be32(blob.data() + 16);
    if (type != 3 || offset + 8 > blob.size()) return {};
    uint32_t length = load_be32(blob.data() + offset + 4);
    if (offset + length > blob.size() || length < 12 || load_be32(blob.data() + offset) != 0xfade0c00U) return {};
    uint32_t kind = load_be32(blob.data() + offset + 8);
    if (kind != 1) return {};
    size_t pos = offset + 12;
    return decode_requirement_expression(blob, pos);
}

void Display::display_requirements(const std::filesystem::path& path) {
    auto data = read_file(path);
    if (!MachOParser::is_macho(data)) return;
    auto info = MachOParser::get_signature_info(data);
    if (!info.requirements_blob.empty()) {
        auto readable = format_requirements_blob(info.requirements_blob);
        if (!readable.empty()) std::cout << readable << std::endl;
        else std::cout << to_hex(info.requirements_blob) << std::endl;
    }
}

void Display::display_cdhash(const std::filesystem::path& path) {
    auto data = read_file(path);
    if (!MachOParser::is_macho(data)) return;
    auto info = MachOParser::get_signature_info(data);
    if (!info.cd_hash.empty()) {
        std::cout << to_hex(info.cd_hash) << std::endl;
    }
}

void Display::display_archive_contents(const std::filesystem::path& path) {
    auto entries = ArchiveEngine::list_contents(path);
    for (auto& entry : entries) {
        std::cout << entry.path;
        if (entry.is_directory) std::cout << "/";
        std::cout << " " << entry.size << std::endl;
    }
}

std::string x509_name_string(X509_NAME* name) {
    if (!name) return {};
    BIO* bio = BIO_new(BIO_s_mem());
    if (!bio) return {};
    if (X509_NAME_print_ex(bio, name, 0, XN_FLAG_RFC2253) < 0) { BIO_free(bio); return {}; }
    char* buffer = nullptr; long length = BIO_get_mem_data(bio, &buffer);
    std::string result = (buffer && length > 0) ? std::string(buffer, static_cast<size_t>(length)) : std::string();
    BIO_free(bio);
    return result;
}

void Display::display_certificates(const std::filesystem::path& path) {
    auto certs = CryptoEngine::extract_certs_raw(path.string());
    std::cout << "certificates: " << certs.size() << std::endl;
    size_t index = 0;
    for (auto& cert : certs) {
        const unsigned char* cursor = cert.data();
        X509Ptr certificate(d2i_X509(nullptr, &cursor, static_cast<long>(cert.size())));
        if (!certificate.get()) {
            std::cout << "certificate " << index << ": invalid" << std::endl;
        } else {
            std::cout << "certificate " << index << std::endl;
            std::cout << "  subject: " << x509_name_string(X509_get_subject_name(certificate.get())) << std::endl;
            std::cout << "  issuer: " << x509_name_string(X509_get_issuer_name(certificate.get())) << std::endl;
            std::cout << "  size: " << cert.size() << std::endl;
        }
        ++index;
    }
}

std::vector<uint8_t> read_file(const std::filesystem::path& path) {
    std::ifstream input(path, std::ios::binary);
    return std::vector<uint8_t>((std::istreambuf_iterator<char>(input)), std::istreambuf_iterator<char>());
}

bool write_file(const std::filesystem::path& path, const std::vector<uint8_t>& data) {
    if (path.has_parent_path()) {
        std::error_code ec;
        std::filesystem::create_directories(path.parent_path(), ec);
    }
    std::ofstream output(path, std::ios::binary | std::ios::trunc);
    if (!output) return false;
    output.write(reinterpret_cast<const char*>(data.data()), static_cast<std::streamsize>(data.size()));
    return static_cast<bool>(output);
}

std::string read_text(const std::filesystem::path& path) {
    auto bytes = read_file(path);
    return std::string(bytes.begin(), bytes.end());
}

bool write_text(const std::filesystem::path& path, const std::string& text) {
    std::vector<uint8_t> bytes(text.begin(), text.end());
    return write_file(path, bytes);
}

std::string to_hex(const std::vector<uint8_t>& data) {
    return hex_encode(data);
}

std::vector<uint8_t> from_hex(const std::string& hex) {
    return hex_decode(hex);
}

std::string default_identifier_from_path(const std::filesystem::path& path) {
    auto stem = path.stem().string();
    if (stem.empty()) return "ldid-binary";
    return stem;
}

}

namespace {

std::string required_option_value(const std::string& arg, const std::string& prefix, int argc, char** argv, int& index) {
    if (arg.size() > prefix.size()) return arg.substr(prefix.size());
    if (index + 1 < argc) {
        ++index;
        return argv[index];
    }
    return {};
}

std::string optional_option_value(const std::string& arg, const std::string& prefix, int argc, char** argv, int& index) {
    if (arg.size() > prefix.size()) return arg.substr(prefix.size());
    if (index + 1 < argc && argv[index + 1][0] != '-') {
        ++index;
        return argv[index];
    }
    return {};
}

std::pair<uint32_t, bool> cd_flag_from_name(const std::string& raw_name) {
    std::string name = raw_name;
    std::transform(name.begin(), name.end(), name.begin(), [](unsigned char c) {
        return static_cast<char>(std::tolower(c));
    });
    bool clear = false;
    if (name.rfind("no-", 0) == 0) {
        clear = true;
        name = name.substr(3);
    }
    uint32_t bit = 0;
    if (name == "host") bit = static_cast<uint32_t>(ldid::CodeDirectoryFlag::VALID);
    else if (name == "adhoc") bit = static_cast<uint32_t>(ldid::CodeDirectoryFlag::ADHOC);
    else if (name == "hard") bit = static_cast<uint32_t>(ldid::CodeDirectoryFlag::HARD);
    else if (name == "kill") bit = static_cast<uint32_t>(ldid::CodeDirectoryFlag::KILL);
    else if (name == "expires" || name == "check-expiration") bit = static_cast<uint32_t>(ldid::CodeDirectoryFlag::CHECK_EXPIRATION);
    else if (name == "restrict") bit = static_cast<uint32_t>(ldid::CodeDirectoryFlag::RESTRICT);
    else if (name == "enforcement") bit = static_cast<uint32_t>(ldid::CodeDirectoryFlag::ENFORCEMENT);
    else if (name == "library-validation") bit = static_cast<uint32_t>(ldid::CodeDirectoryFlag::LIBRARY_VALIDATION);
    else if (name == "runtime") bit = static_cast<uint32_t>(ldid::CodeDirectoryFlag::RUNTIME);
    else if (name == "linker-signed") bit = static_cast<uint32_t>(ldid::CodeDirectoryFlag::LINKER_SIGNED);
    return {bit, clear};
}

void apply_cd_flags(const std::string& text, uint32_t& flags) {
    size_t start = 0;
    while (start < text.size()) {
        size_t end = text.find_first_of(", ", start);
        if (end == std::string::npos) end = text.size();
        std::string token = text.substr(start, end - start);
        if (!token.empty()) {
            auto parsed = cd_flag_from_name(token);
            uint32_t bit = parsed.first;
            if (bit != 0) {
                if (parsed.second) flags &= ~bit;
                else flags |= bit;
            }
        }
        start = end + 1;
    }
}

uint32_t parse_version_value(const std::string& value) {
    if (value.empty()) throw std::invalid_argument("invalid version");
    std::stringstream stream(value);
    std::string part;
    uint32_t components[3] = {0, 0, 0};
    size_t count = 0;
    while (std::getline(stream, part, '.')) {
        if (part.empty() || count >= 3) throw std::invalid_argument("invalid version");
        try {
            size_t parsed = 0;
            unsigned long component = std::stoul(part, &parsed, 10);
            if (parsed != part.size() || component > 0xFFUL) throw std::invalid_argument("invalid version: " + value);
            components[count++] = static_cast<uint32_t>(component);
        } catch (const std::exception&) {
            throw std::invalid_argument("invalid version: " + value);
        }
    }
    return (components[0] << 16) | (components[1] << 8) | components[2];
}

ldid::HashType parse_hash_type(const std::string& value) {
    std::string lowered = value;
    std::transform(lowered.begin(), lowered.end(), lowered.begin(), [](unsigned char c) {
        return static_cast<char>(std::tolower(c));
    });
    if (lowered == "sha1" || lowered == "1") return ldid::HashType::SHA1;
    if (lowered == "sha256" || lowered == "2") return ldid::HashType::SHA256;
    if (lowered == "sha256-truncated" || lowered == "sha256_160" || lowered == "3") return ldid::HashType::SHA256_TRUNCATED;
    if (lowered == "sha384" || lowered == "4") return ldid::HashType::SHA384;
    return ldid::HashType::ANY;
}

ldid::Platform parse_platform(const std::string& value) {
    std::string v = value;
    std::transform(v.begin(), v.end(), v.begin(), [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
    if (v == "macos" || v == "macosx") return ldid::Platform::MACOS;
    if (v == "ios") return ldid::Platform::IOS;
    if (v == "tvos") return ldid::Platform::TVOS;
    if (v == "watchos") return ldid::Platform::WATCHOS;
    if (v == "bridgeos") return ldid::Platform::BRIDGEOS;
    if (v == "maccatalyst") return ldid::Platform::MACCATALYST;
    if (v == "iossimulator") return ldid::Platform::IOSSIMULATOR;
    if (v == "tvossimulator") return ldid::Platform::TVOSSIMULATOR;
    if (v == "watchossimulator") return ldid::Platform::WATCHOSSIMULATOR;
    if (v == "driverkit") return ldid::Platform::DRIVERKIT;
    try {
        size_t parsed = 0;
        unsigned long numeric = std::stoul(v, &parsed, 10);
        if (parsed != v.size()) throw std::invalid_argument("invalid platform");
        return static_cast<ldid::Platform>(numeric);
    } catch (...) {
        std::cerr << "ldid: unknown platform: " << value << std::endl;
        return ldid::Platform::UNKNOWN;
    }
}

void print_usage() {
    std::cout << "usage: ldid [-S[file.xml]] [-s] [-r] [-e] [-q] [-d] [-h] [-M] [-Kkey.p12] [-Upassword] [-Iname] [-tTeamID] [-Qreq.xml] [-Cflags] [-H[hash]] [-Aarch] [-Pplatform] [--timestamp] [--timestamp-url=url] [--timestamp-required] [--timestamp-policy=oid] [--no-timestamp] [--min-os=version] [-Nreq.xml] [-D] [--reset-cryptid] [-a] [-w] [-O] [-n] [-arch arch] [--true-sign] [--deep] [--super-deep] [--verify] file..." << std::endl;
}

}

int main(int argc, char** argv) {
    if (argc < 2) {
        print_usage();
        return 1;
    }
    ldid::SignOptions options;
    bool do_sign = false;
    bool do_unsign = false;
    bool do_verify = false;
    bool show_entitlements = false;
    bool show_requirements = false;
    bool show_info = false;
    bool show_cdhash = false;
    bool show_version = false;
    bool reset_cryptid = false;
    std::vector<std::string> inputs;
    try {
    for (int i = 1; i < argc; ++i) {
        std::string arg = argv[i];
        if (arg == "-v" || arg == "--version") {
            show_version = true;
        } else if (arg == "--true-sign") {
            options.true_sign = true;
        } else if (arg == "--deep") {
            options.deep = true;
            do_sign = true;
        } else if (arg == "--super-deep") {
            options.super_deep = true;
            do_sign = true;
        } else if (arg == "--verify") {
            do_verify = true;
        } else if (arg == "-arch") {
            if (i + 1 < argc) {
                options.arch = argv[++i];
            }
        } else if (arg.rfind("--arch=", 0) == 0) {
            options.arch = arg.substr(7);
        } else if (arg.rfind("-S", 0) == 0) {
            do_sign = true;
            auto value = optional_option_value(arg, "-S", argc, argv, i);
            if (!value.empty()) options.entitlements_path = value;
            else options.preserve_entitlements = true;
        } else if (arg == "-s") {
            do_sign = true;
            options.preserve_entitlements = true;
        } else if (arg == "-r") {
            do_unsign = true;
        } else if (arg == "-e") {
            show_entitlements = true;
        } else if (arg == "-q") {
            show_requirements = true;
        } else if (arg == "-D") {
            show_requirements = true;
        } else if (arg == "--reset-cryptid") {
            reset_cryptid = true;
        } else if (arg == "-d") {
            show_info = true;
        } else if (arg == "-h") {
            show_cdhash = true;
        } else if (arg == "-M") {
            do_sign = true;
            options.merge_only = true;
            options.preserve_entitlements = true;
        } else if (arg.rfind("-K", 0) == 0) {
            options.p12_path = required_option_value(arg, "-K", argc, argv, i);
            do_sign = true;
        } else if (arg.rfind("-U", 0) == 0) {
            options.key_password = required_option_value(arg, "-U", argc, argv, i);
        } else if (arg.rfind("-I", 0) == 0) {
            options.identifier = required_option_value(arg, "-I", argc, argv, i);
        } else if (arg.rfind("-t", 0) == 0) {
            options.team_id = required_option_value(arg, "-t", argc, argv, i);
        } else if (arg.rfind("-Q", 0) == 0) {
            options.requirements_path = required_option_value(arg, "-Q", argc, argv, i);
        } else if (arg.rfind("-N", 0) == 0) {
            options.requirements_path = required_option_value(arg, "-N", argc, argv, i);
        } else if (arg.rfind("-C", 0) == 0) {
            std::string value;
            if (arg.size() > 2) {
                value = arg.substr(2);
            } else if (i + 1 < argc) {
                std::string candidate = argv[i + 1];
                std::string lowered = candidate;
                std::transform(lowered.begin(), lowered.end(), lowered.begin(), [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
                bool recognized = false;
                for (const auto& token : {std::string("host"), std::string("adhoc"), std::string("hard"), std::string("kill"), std::string("expires"), std::string("check-expiration"), std::string("restrict"), std::string("enforcement"), std::string("library-validation"), std::string("runtime"), std::string("linker-signed"), std::string("no-host"), std::string("no-adhoc"), std::string("no-hard"), std::string("no-kill"), std::string("no-expires"), std::string("no-check-expiration"), std::string("no-restrict"), std::string("no-enforcement"), std::string("no-library-validation"), std::string("no-runtime"), std::string("no-linker-signed")}) {
                    if (lowered == token) { recognized = true; break; }
                }
                if (recognized) { value = candidate; ++i; }
            }
            if (value.empty()) { print_usage(); return 1; }
            apply_cd_flags(value, options.cd_flags);
        } else if (arg.rfind("-H", 0) == 0) {
            auto value = optional_option_value(arg, "-H", argc, argv, i);
            options.hash_type = parse_hash_type(value);
        } else if (arg.rfind("-A", 0) == 0) {
            options.arch = required_option_value(arg, "-A", argc, argv, i);
        } else if (arg.rfind("-P", 0) == 0) {
            auto value = optional_option_value(arg, "-P", argc, argv, i);
            options.platform = parse_platform(value);

        } else if (arg == "-a") {
            do_sign = true;
            options.adhoc = true;
        } else if (arg == "--force") {
            options.force = true;
        } else if (arg == "--min-os") {
            options.min_os_version = parse_version_value(required_option_value(arg, "--min-os", argc, argv, i));
        } else if (arg.rfind("--min-os=", 0) == 0) {
            options.min_os_version = parse_version_value(arg.substr(9));
        } else if (arg == "--timestamp") {
            options.timestamp_enabled = true;
        } else if (arg == "--timestamp-required") {
            options.timestamp_enabled = true;
            options.timestamp_required = true;
        } else if (arg == "--timestamp-policy") {
            options.timestamp_policy = required_option_value(arg, "--timestamp-policy", argc, argv, i);
        } else if (arg.rfind("--timestamp-policy=", 0) == 0) {
            options.timestamp_policy = arg.substr(19);
        } else if (arg == "--no-timestamp") {
            options.timestamp_enabled = false;
            options.emit_signing_time = false;
        } else if (arg.rfind("--timestamp-url=", 0) == 0) {
            options.timestamp_url = arg.substr(15);
            options.timestamp_enabled = true;
        } else if (arg == "--timestamp-url") {
            options.timestamp_url = required_option_value(arg, "--timestamp-url", argc, argv, i);
            options.timestamp_enabled = true;
        } else if (arg.rfind("-T", 0) == 0) {
            std::string value;
            if (arg.size() > 2) {
                value = arg.substr(2);
            } else if (i + 1 < argc) {
                std::string candidate = argv[i + 1];
                if (candidate.find("://") != std::string::npos) {
                    value = candidate;
                    ++i;
                }
            }
            if (!value.empty() && value.find("://") != std::string::npos) options.timestamp_url = value;
            options.timestamp_enabled = true;
        } else if (arg == "-w") {
            options.write_copy = true;
        } else if (arg == "-O") {
            options.output_stdout = true;
        } else if (arg == "-n") {
            options.no_overwrite = true;
        } else if (!arg.empty() && arg[0] == '-') {
            print_usage();
            return 1;
        } else {
            inputs.push_back(arg);
        }
    }
    if (show_version) {
        std::cout << "ldid enhanced two-file edition" << std::endl;
        return 0;
    }
    if (inputs.empty()) {
        print_usage();
        return 1;
    }
    if ((options.cd_flags & static_cast<uint32_t>(ldid::CodeDirectoryFlag::ADHOC)) != 0) {
        options.adhoc = true;
    }
    int exit_code = 0;
    for (auto& input : inputs) {
        if (reset_cryptid) {
            ldid::Signer::reset_cryptid(input);
            continue;
        }
        if (do_unsign) {
            ldid::Signer::unsign(input);
            continue;
        }
        if (do_verify) {
            auto result = ldid::Verifier::verify(input);
            if (result.ok) {
                std::cout << input << ": valid" << std::endl;
            } else {
                std::cout << input << ": invalid" << std::endl;
                for (auto& error : result.errors) {
                    std::cout << error << std::endl;
                }
                exit_code = 1;
            }
            continue;
        }
        if (do_sign) {
            ldid::Signer::sign(input, options);
            continue;
        }
        if (show_entitlements) {
            ldid::Display::display_entitlements(input);
        }
        if (show_requirements) {
            ldid::Display::display_requirements(input);
        }
        if (show_cdhash) {
            ldid::Display::display_cdhash(input);
        }
        if (show_info) {
            ldid::Display::display_info(input);
        }
        if (!show_entitlements && !show_requirements && !show_cdhash && !show_info) {
            ldid::Display::display_info(input);
        }
    }
    return exit_code;
    } catch (const std::exception& error) {
        std::cerr << "ldid: " << error.what() << std::endl;
        return 1;
    } catch (...) {
        std::cerr << "ldid: unknown error" << std::endl;
        return 1;
    }
}
