#ifndef LDIDBRIDGE_H
#define LDIDBRIDGE_H
#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <openssl/opensslv.h>
#include <openssl/asn1.h>
#include <openssl/asn1t.h>
#include <openssl/bio.h>
#include <openssl/err.h>
#include <openssl/evp.h>
#include <openssl/pem.h>
#include <openssl/pkcs7.h>
#include <openssl/pkcs12.h>
#include <openssl/ui.h>
#include <openssl/x509.h>
#include <openssl/provider.h>
#include <openssl/objects.h>
#include <openssl/stack.h>
#include <plist/plist.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <fcntl.h>
#include <unistd.h>
#include <dirent.h>
#include <errno.h>
#include <regex.h>

#ifndef OPENSSL_STACK
typedef struct stack_st OPENSSL_STACK;
#endif

static inline int ldid_OPENSSL_sk_num(void *stack) {
    return OPENSSL_sk_num((const OPENSSL_STACK *)stack);
}

static inline void *ldid_OPENSSL_sk_value(void *stack, int i) {
    return (void *)OPENSSL_sk_value((const OPENSSL_STACK *)stack, i);
}

static inline void *ldid_OPENSSL_sk_new_null(void) {
    return (void *)OPENSSL_sk_new_null();
}

static inline int ldid_OPENSSL_sk_push(void *stack, void *data) {
    return OPENSSL_sk_push((OPENSSL_STACK *)stack, data);
}

static inline void ldid_OPENSSL_sk_pop_free_X509(void *stack) {
    OPENSSL_sk_pop_free((OPENSSL_STACK *)stack, (void (*)(void *))X509_free);
}

#define LDID_CPU_TYPE_ANY           ((uint32_t) -1)
#define LDID_CPU_TYPE_VAX           ((uint32_t) 1)
#define LDID_CPU_TYPE_ROMP          ((uint32_t) 2)
#define LDID_CPU_TYPE_NS32032       ((uint32_t) 4)
#define LDID_CPU_TYPE_NS32332       ((uint32_t) 5)
#define LDID_CPU_TYPE_MC680x0       ((uint32_t) 6)
#define LDID_CPU_TYPE_I386          ((uint32_t) 7)
#define LDID_CPU_TYPE_X86           ((uint32_t) 7)
#define LDID_CPU_ARCH_ABI64         ((uint32_t) 0x1000000)
#define LDID_CPU_ARCH_ABI64_32      ((uint32_t) 0x2000000)
#define LDID_CPU_ARCH_MASK          ((uint32_t) 0xff000000)
#define LDID_CPU_TYPE_X86_64        ((uint32_t) (LDID_CPU_TYPE_I386 | LDID_CPU_ARCH_ABI64))
#define LDID_CPU_TYPE_MIPS          ((uint32_t) 8)
#define LDID_CPU_TYPE_NS32532       ((uint32_t) 9)
#define LDID_CPU_TYPE_HPPA          ((uint32_t) 11)
#define LDID_CPU_TYPE_ARM           ((uint32_t) 12)
#define LDID_CPU_TYPE_MC88000       ((uint32_t) 13)
#define LDID_CPU_TYPE_SPARC         ((uint32_t) 14)
#define LDID_CPU_TYPE_I860          ((uint32_t) 15)
#define LDID_CPU_TYPE_I860_LITTLE   ((uint32_t) 16)
#define LDID_CPU_TYPE_RS6000        ((uint32_t) 17)
#define LDID_CPU_TYPE_MC98000       ((uint32_t) 18)
#define LDID_CPU_TYPE_POWERPC       ((uint32_t) 18)
#define LDID_CPU_TYPE_POWERPC64     ((uint32_t) (LDID_CPU_TYPE_POWERPC | LDID_CPU_ARCH_ABI64))
#define LDID_CPU_TYPE_VEO           ((uint32_t) 255)
#define LDID_CPU_TYPE_ARM64         ((uint32_t) (LDID_CPU_TYPE_ARM | LDID_CPU_ARCH_ABI64))
#define LDID_CPU_TYPE_ARM64_32      ((uint32_t) (LDID_CPU_TYPE_ARM | LDID_CPU_ARCH_ABI64_32))
#define LDID_CPU_SUBTYPE_MASK       ((uint32_t) 0xff000000)
#define LDID_CPU_SUBTYPE_LIB64      ((uint32_t) 0x80000000)
#define LDID_CPU_SUBTYPE_MULTIPLE   ((uint32_t) -1)
#define LDID_CPU_SUBTYPE_VAX_ALL        ((uint32_t) 0)
#define LDID_CPU_SUBTYPE_VAX780         ((uint32_t) 1)
#define LDID_CPU_SUBTYPE_VAX785         ((uint32_t) 2)
#define LDID_CPU_SUBTYPE_VAX750         ((uint32_t) 3)
#define LDID_CPU_SUBTYPE_VAX730         ((uint32_t) 4)
#define LDID_CPU_SUBTYPE_UVAXI          ((uint32_t) 5)
#define LDID_CPU_SUBTYPE_UVAXII         ((uint32_t) 6)
#define LDID_CPU_SUBTYPE_VAX8200        ((uint32_t) 7)
#define LDID_CPU_SUBTYPE_VAX8500        ((uint32_t) 8)
#define LDID_CPU_SUBTYPE_VAX8600        ((uint32_t) 9)
#define LDID_CPU_SUBTYPE_VAX8650        ((uint32_t) 10)
#define LDID_CPU_SUBTYPE_VAX8800        ((uint32_t) 11)
#define LDID_CPU_SUBTYPE_UVAXIII        ((uint32_t) 12)
#define LDID_CPU_SUBTYPE_RT_ALL     ((uint32_t) 0)
#define LDID_CPU_SUBTYPE_RT_PC      ((uint32_t) 1)
#define LDID_CPU_SUBTYPE_RT_APC     ((uint32_t) 2)
#define LDID_CPU_SUBTYPE_RT_135     ((uint32_t) 3)
#define LDID_CPU_SUBTYPE_MMAX_ALL       ((uint32_t) 0)
#define LDID_CPU_SUBTYPE_MMAX_DPC       ((uint32_t) 1)
#define LDID_CPU_SUBTYPE_SQT            ((uint32_t) 2)
#define LDID_CPU_SUBTYPE_MMAX_APC_FPU   ((uint32_t) 3)
#define LDID_CPU_SUBTYPE_MMAX_APC_FPA   ((uint32_t) 4)
#define LDID_CPU_SUBTYPE_MMAX_XPC       ((uint32_t) 5)
#define LDID_CPU_SUBTYPE_I386_ALL   ((uint32_t) 3)
#define LDID_CPU_SUBTYPE_X86_64_ALL ((uint32_t) 3)
#define LDID_CPU_SUBTYPE_386        ((uint32_t) 3)
#define LDID_CPU_SUBTYPE_486        ((uint32_t) 4)
#define LDID_CPU_SUBTYPE_486SX      ((uint32_t) (4 + 128))
#define LDID_CPU_SUBTYPE_586        ((uint32_t) 5)
#define LDID_CPU_SUBTYPE_PENT       ((uint32_t) 5)
#define LDID_CPU_SUBTYPE_PENTPRO    ((uint32_t) (6 + (1 << 4)))
#define LDID_CPU_SUBTYPE_PENTII_M3  ((uint32_t) (6 + (3 << 4)))
#define LDID_CPU_SUBTYPE_PENTII_M5  ((uint32_t) (6 + (5 << 4)))
#define LDID_CPU_SUBTYPE_PENTIUM_4  ((uint32_t) (10 + (0 << 4)))
#define LDID_CPU_SUBTYPE_X86_64_H   ((uint32_t) 8)
#define LDID_CPU_SUBTYPE_MIPS_ALL   ((uint32_t) 0)
#define LDID_CPU_SUBTYPE_MIPS_R2300 ((uint32_t) 1)
#define LDID_CPU_SUBTYPE_MIPS_R2600 ((uint32_t) 2)
#define LDID_CPU_SUBTYPE_MIPS_R2800 ((uint32_t) 3)
#define LDID_CPU_SUBTYPE_MIPS_R2000a ((uint32_t) 4)
#define LDID_CPU_SUBTYPE_MC680x0_ALL    ((uint32_t) 1)
#define LDID_CPU_SUBTYPE_MC68030        ((uint32_t) 1)
#define LDID_CPU_SUBTYPE_MC68040        ((uint32_t) 2)
#define LDID_CPU_SUBTYPE_MC68030_ONLY   ((uint32_t) 3)
#define LDID_CPU_SUBTYPE_HPPA_ALL       ((uint32_t) 0)
#define LDID_CPU_SUBTYPE_HPPA_7100      ((uint32_t) 0)
#define LDID_CPU_SUBTYPE_HPPA_7100LC    ((uint32_t) 1)
#define LDID_CPU_SUBTYPE_ARM_ALL        ((uint32_t) 0)
#define LDID_CPU_SUBTYPE_ARM_A500_ARCH  ((uint32_t) 1)
#define LDID_CPU_SUBTYPE_ARM_A500       ((uint32_t) 2)
#define LDID_CPU_SUBTYPE_ARM_A440       ((uint32_t) 3)
#define LDID_CPU_SUBTYPE_ARM_M4         ((uint32_t) 4)
#define LDID_CPU_SUBTYPE_ARM_V4T        ((uint32_t) 5)
#define LDID_CPU_SUBTYPE_ARM_V6         ((uint32_t) 6)
#define LDID_CPU_SUBTYPE_ARM_V5TEJ      ((uint32_t) 7)
#define LDID_CPU_SUBTYPE_ARM_XSCALE     ((uint32_t) 8)
#define LDID_CPU_SUBTYPE_ARM_V7         ((uint32_t) 9)
#define LDID_CPU_SUBTYPE_ARM_V7F        ((uint32_t) 10)
#define LDID_CPU_SUBTYPE_ARM_V7S        ((uint32_t) 11)
#define LDID_CPU_SUBTYPE_ARM_V7K        ((uint32_t) 12)
#define LDID_CPU_SUBTYPE_ARM_V6M        ((uint32_t) 14)
#define LDID_CPU_SUBTYPE_ARM_V7M        ((uint32_t) 15)
#define LDID_CPU_SUBTYPE_ARM_V7EM       ((uint32_t) 16)
#define LDID_CPU_SUBTYPE_ARM_V8         ((uint32_t) 13)
#define LDID_CPU_SUBTYPE_ARM64_ALL      ((uint32_t) 0)
#define LDID_CPU_SUBTYPE_ARM64_V8       ((uint32_t) 1)
#define LDID_CPU_SUBTYPE_ARM64E         ((uint32_t) 2)
#define LDID_CPU_SUBTYPE_ARM64_32_V8    ((uint32_t) 1)
#define LDID_CPU_SUBTYPE_MC88000_ALL    ((uint32_t) 0)
#define LDID_CPU_SUBTYPE_MMAX_JPC       ((uint32_t) 1)
#define LDID_CPU_SUBTYPE_MC88100        ((uint32_t) 1)
#define LDID_CPU_SUBTYPE_MC88110        ((uint32_t) 2)
#define LDID_CPU_SUBTYPE_MC98000_ALL    ((uint32_t) 0)
#define LDID_CPU_SUBTYPE_MC98601        ((uint32_t) 1)
#define LDID_CPU_SUBTYPE_I860_ALL   ((uint32_t) 0)
#define LDID_CPU_SUBTYPE_I860_860   ((uint32_t) 1)
#define LDID_CPU_SUBTYPE_LITTLE_ENDIAN  ((uint32_t) 0)
#define LDID_CPU_SUBTYPE_BIG_ENDIAN     ((uint32_t) 1)
#define LDID_CPU_SUBTYPE_I860_LITTLE_ALL    ((uint32_t) 0)
#define LDID_CPU_SUBTYPE_I860_LITTLE        ((uint32_t) 1)
#define LDID_CPU_SUBTYPE_RS6000_ALL ((uint32_t) 0)
#define LDID_CPU_SUBTYPE_RS6000     ((uint32_t) 1)
#define LDID_CPU_SUBTYPE_SUN4_ALL   ((uint32_t) 0)
#define LDID_CPU_SUBTYPE_SUN4_260   ((uint32_t) 1)
#define LDID_CPU_SUBTYPE_SUN4_110   ((uint32_t) 2)
#define LDID_CPU_SUBTYPE_SPARC_ALL  ((uint32_t) 0)
#define LDID_CPU_SUBTYPE_POWERPC_ALL    ((uint32_t) 0)
#define LDID_CPU_SUBTYPE_POWERPC_601    ((uint32_t) 1)
#define LDID_CPU_SUBTYPE_POWERPC_602    ((uint32_t) 2)
#define LDID_CPU_SUBTYPE_POWERPC_603    ((uint32_t) 3)
#define LDID_CPU_SUBTYPE_POWERPC_603e   ((uint32_t) 4)
#define LDID_CPU_SUBTYPE_POWERPC_603ev  ((uint32_t) 5)
#define LDID_CPU_SUBTYPE_POWERPC_604    ((uint32_t) 6)
#define LDID_CPU_SUBTYPE_POWERPC_604e   ((uint32_t) 7)
#define LDID_CPU_SUBTYPE_POWERPC_620    ((uint32_t) 8)
#define LDID_CPU_SUBTYPE_POWERPC_750    ((uint32_t) 9)
#define LDID_CPU_SUBTYPE_POWERPC_7400   ((uint32_t) 10)
#define LDID_CPU_SUBTYPE_POWERPC_7450   ((uint32_t) 11)
#define LDID_CPU_SUBTYPE_POWERPC_970    ((uint32_t) 100)
#define LDID_CPU_SUBTYPE_VEO_1      ((uint32_t) 1)
#define LDID_CPU_SUBTYPE_VEO_2      ((uint32_t) 2)
#define LDID_CPU_SUBTYPE_VEO_3      ((uint32_t) 3)
#define LDID_CPU_SUBTYPE_VEO_4      ((uint32_t) 4)
#define LDID_CPU_SUBTYPE_VEO_ALL    ((uint32_t) 2)
#define LDID_MH_MAGIC       0xfeedface
#define LDID_MH_CIGAM       0xcefaedfe
#define LDID_MH_MAGIC_64    0xfeedfacf
#define LDID_MH_CIGAM_64    0xcffaedfe
#define LDID_FAT_MAGIC      0xcafebabe
#define LDID_FAT_CIGAM      0xbebafeca
#define LDID_MH_OBJECT      0x1
#define LDID_MH_EXECUTE     0x2
#define LDID_MH_DYLIB       0x6
#define LDID_MH_DYLINKER    0x7
#define LDID_MH_BUNDLE      0x8
#define LDID_MH_DYLIB_STUB  0x9
#define LDID_MH_DSYM        0xa
#define LDID_LC_REQ_DYLD            0x80000000
#define LDID_LC_SEGMENT             0x01
#define LDID_LC_SYMTAB              0x02
#define LDID_LC_DYSYMTAB            0x0b
#define LDID_LC_LOAD_DYLIB          0x0c
#define LDID_LC_ID_DYLIB            0x0d
#define LDID_LC_SEGMENT_64          0x19
#define LDID_LC_UUID                0x1b
#define LDID_LC_CODE_SIGNATURE      0x1d
#define LDID_LC_SEGMENT_SPLIT_INFO  0x1e
#define LDID_LC_REEXPORT_DYLIB      0x1f
#define LDID_LC_ENCRYPTION_INFO     0x21
#define LDID_LC_DYLD_INFO           0x22
#define LDID_LC_DYLD_INFO_ONLY      0x22
#define LDID_LC_ENCRYPTION_INFO_64  0x2c
#define LDID_LC_BUILD_VERSION       0x32
#define LDID_LC_VERSION_MIN_MACOSX  0x24
#define LDID_LC_VERSION_MIN_IPHONEOS 0x25
#define LDID_LC_VERSION_MIN_TVOS    0x2F
#define LDID_PLATFORM_MACOS 1
#define LDID_PLATFORM_IOS   2
#define LDID_PLATFORM_TVOS  3
#define LDID_CSMAGIC_REQUIREMENT            0xfade0c00
#define LDID_CSMAGIC_REQUIREMENTS           0xfade0c01
#define LDID_CSMAGIC_CODEDIRECTORY          0xfade0c02
#define LDID_CSMAGIC_EMBEDDED_SIGNATURE     0xfade0cc0
#define LDID_CSMAGIC_EMBEDDED_SIGNATURE_OLD 0xfade0b02
#define LDID_CSMAGIC_EMBEDDED_ENTITLEMENTS  0xfade7171
#define LDID_CSMAGIC_EMBEDDED_DERFORMAT     0xfade7172
#define LDID_CSMAGIC_DETACHED_SIGNATURE     0xfade0cc1
#define LDID_CSMAGIC_BLOBWRAPPER            0xfade0b01
#define LDID_CSSLOT_CODEDIRECTORY   0x00000
#define LDID_CSSLOT_INFOSLOT        0x00001
#define LDID_CSSLOT_REQUIREMENTS    0x00002
#define LDID_CSSLOT_RESOURCEDIR     0x00003
#define LDID_CSSLOT_APPLICATION     0x00004
#define LDID_CSSLOT_ENTITLEMENTS    0x00005
#define LDID_CSSLOT_REPSPECIFIC     0x00006
#define LDID_CSSLOT_DERFORMAT       0x00007
#define LDID_CSSLOT_ALTERNATE       0x01000
#define LDID_CSSLOT_SIGNATURESLOT   0x10000
#define LDID_CS_HASHTYPE_SHA160_160 1
#define LDID_CS_HASHTYPE_SHA256_256 2
#define LDID_CS_HASHTYPE_SHA256_160 3
#define LDID_CS_HASHTYPE_SHA386_386 4
#define LDID_CS_EXECSEG_MAIN_BINARY         0x001
#define LDID_CS_EXECSEG_ALLOW_UNSIGNED      0x010
#define LDID_CS_EXECSEG_DEBUGGER            0x020
#define LDID_CS_EXECSEG_JIT                 0x040
#define LDID_CS_EXECSEG_SKIP_LV             0x080
#define LDID_CS_EXECSEG_CAN_LOAD_CDHASH     0x100
#define LDID_CS_EXECSEG_CAN_EXEC_CDHASH     0x100
#define LDID_K_SEC_CODESIGNATURE_HOST                0x0001
#define LDID_K_SEC_CODESIGNATURE_ADHOC               0x0002
#define LDID_K_SEC_CODESIGNATURE_FORCEHARD           0x0100
#define LDID_K_SEC_CODESIGNATURE_FORCEKILL           0x0200
#define LDID_K_SEC_CODESIGNATURE_FORCEEXPIRATION     0x0400
#define LDID_K_SEC_CODESIGNATURE_RESTRICT            0x0800
#define LDID_K_SEC_CODESIGNATURE_ENFORCEMENT         0x1000
#define LDID_K_SEC_CODESIGNATURE_LIBRARYVALIDATION   0x2000
#define LDID_K_SEC_CODESIGNATURE_RUNTIME             0x10000
#define LDID_K_SEC_CODESIGNATURE_LINKERSIGNED        0x20000
#define LDID_PAGE_SHIFT 0x0c
#define LDID_PAGE_SIZE  (1 << LDID_PAGE_SHIFT)
#define LDID_MAXSEGALIGN   15
#define LDID_MINSEGALIGN32 2
#define LDID_MINSEGALIGN64 3
struct ldid_fat_header {
uint32_t magic;
uint32_t nfat_arch;
} __attribute__((packed));
struct ldid_fat_arch {
uint32_t cputype;
uint32_t cpusubtype;
uint32_t offset;
uint32_t size;
uint32_t align;
} __attribute__((packed));
struct ldid_mach_header {
uint32_t magic;
uint32_t cputype;
uint32_t cpusubtype;
uint32_t filetype;
uint32_t ncmds;
uint32_t sizeofcmds;
uint32_t flags;
} __attribute__((packed));
struct ldid_load_command {
uint32_t cmd;
uint32_t cmdsize;
} __attribute__((packed));
struct ldid_segment_command {
uint32_t cmd;
uint32_t cmdsize;
char segname[16];
uint32_t vmaddr;
uint32_t vmsize;
uint32_t fileoff;
uint32_t filesize;
uint32_t maxprot;
uint32_t initprot;
uint32_t nsects;
uint32_t flags;
} __attribute__((packed));
struct ldid_segment_command_64 {
uint32_t cmd;
uint32_t cmdsize;
char segname[16];
uint64_t vmaddr;
uint64_t vmsize;
uint64_t fileoff;
uint64_t filesize;
uint32_t maxprot;
uint32_t initprot;
uint32_t nsects;
uint32_t flags;
} __attribute__((packed));
struct ldid_section {
char sectname[16];
char segname[16];
uint32_t addr;
uint32_t size;
uint32_t offset;
uint32_t align;
uint32_t reloff;
uint32_t nreloc;
uint32_t flags;
uint32_t reserved1;
uint32_t reserved2;
} __attribute__((packed));
struct ldid_section_64 {
char sectname[16];
char segname[16];
uint64_t addr;
uint64_t size;
uint32_t offset;
uint32_t align;
uint32_t reloff;
uint32_t nreloc;
uint32_t flags;
uint32_t reserved1;
uint32_t reserved2;
uint32_t reserved3;
} __attribute__((packed));
struct ldid_symtab_command {
uint32_t cmd;
uint32_t cmdsize;
uint32_t symoff;
uint32_t nsyms;
uint32_t stroff;
uint32_t strsize;
} __attribute__((packed));
struct ldid_linkedit_data_command {
uint32_t cmd;
uint32_t cmdsize;
uint32_t dataoff;
uint32_t datasize;
} __attribute__((packed));
struct ldid_encryption_info_command {
uint32_t cmd;
uint32_t cmdsize;
uint32_t cryptoff;
uint32_t cryptsize;
uint32_t cryptid;
} __attribute__((packed));
struct ldid_dylib {
uint32_t name;
uint32_t timestamp;
uint32_t current_version;
uint32_t compatibility_version;
} __attribute__((packed));
struct ldid_dylib_command {
uint32_t cmd;
uint32_t cmdsize;
struct ldid_dylib dylib;
} __attribute__((packed));
struct ldid_build_version_command {
uint32_t cmd;
uint32_t cmdsize;
uint32_t platform;
uint32_t minos;
uint32_t sdk;
uint32_t ntools;
} __attribute__((packed));
struct ldid_version_min_command {
uint32_t cmd;
uint32_t cmdsize;
uint32_t version;
uint32_t sdk;
} __attribute__((packed));
struct ldid_blob {
uint32_t magic;
uint32_t length;
} __attribute__((packed));
struct ldid_blob_index {
uint32_t type;
uint32_t offset;
} __attribute__((packed));
struct ldid_superblob {
struct ldid_blob blob;
uint32_t count;
struct ldid_blob_index index[];
} __attribute__((packed));
struct ldid_code_directory {
uint32_t version;
uint32_t flags;
uint32_t hashOffset;
uint32_t identOffset;
uint32_t nSpecialSlots;
uint32_t nCodeSlots;
uint32_t codeLimit;
uint8_t hashSize;
uint8_t hashType;
uint8_t platform;
uint8_t pageSize;
uint32_t spare2;
uint32_t scatterOffset;
uint32_t teamIDOffset;
uint32_t spare3;
uint64_t codeLimit64;
uint64_t execSegBase;
uint64_t execSegLimit;
uint64_t execSegFlags;
} __attribute__((packed));
typedef struct {
uint8_t sha1[0x14];
uint8_t sha256[0x20];
} ldid_hash;
typedef struct {
ASN1_OBJECT *algorithm;
ASN1_OCTET_STRING *value;
} LDID_APPLE_CDHASH;
typedef struct {
ASN1_OBJECT *object;
STACK_OF(LDID_APPLE_CDHASH) *cdhashes;
} LDID_APPLE_CDATTR;
DECLARE_ASN1_FUNCTIONS(LDID_APPLE_CDHASH)
DECLARE_ASN1_FUNCTIONS(LDID_APPLE_CDATTR)
static inline uint16_t ldid_swap16(uint16_t value) {
return (uint16_t) ((value >> 8) | (value << 8));
}
static inline uint32_t ldid_swap32(uint32_t value) {
value = ((value >> 8) & 0x00ff00ff) | ((value << 8) & 0xff00ff00);
value = ((value >> 16) & 0x0000ffff) | ((value << 16) & 0xffff0000);
return value;
}
static inline uint64_t ldid_swap64(uint64_t value) {
value = (value & 0x00000000ffffffffULL) << 32 | (value & 0xffffffff00000000ULL) >> 32;
value = (value & 0x0000ffff0000ffffULL) << 16 | (value & 0xffff0000ffff0000ULL) >> 16;
value = (value & 0x00ff00ff00ff00ffULL) << 8  | (value & 0xff00ff00ff00ff00ULL) >> 8;
return value;
}
static inline int ldid_is_little_endian(void) {
const uint16_t value = 1;
return ((const uint8_t *) &value)[0] == 1;
}
static inline uint32_t ldid_swap32_host(uint32_t value) {
return ldid_is_little_endian() ? ldid_swap32(value) : value;
}
static inline uint64_t ldid_swap64_host(uint64_t value) {
return ldid_is_little_endian() ? ldid_swap64(value) : value;
}
static inline uint32_t ldid_sha1(const void *data, size_t size, uint8_t out[0x14]) {
unsigned int length = 0;
EVP_MD_CTX *ctx = EVP_MD_CTX_new();
if (ctx == NULL) return 0;
if (EVP_DigestInit_ex(ctx, EVP_sha1(), NULL) != 1) { EVP_MD_CTX_free(ctx); return 0; }
if (EVP_DigestUpdate(ctx, data, size) != 1) { EVP_MD_CTX_free(ctx); return 0; }
if (EVP_DigestFinal_ex(ctx, out, &length) != 1) { EVP_MD_CTX_free(ctx); return 0; }
EVP_MD_CTX_free(ctx);
return length;
}
static inline uint32_t ldid_sha256(const void *data, size_t size, uint8_t out[0x20]) {
unsigned int length = 0;
EVP_MD_CTX *ctx = EVP_MD_CTX_new();
if (ctx == NULL) return 0;
if (EVP_DigestInit_ex(ctx, EVP_sha256(), NULL) != 1) { EVP_MD_CTX_free(ctx); return 0; }
if (EVP_DigestUpdate(ctx, data, size) != 1) { EVP_MD_CTX_free(ctx); return 0; }
if (EVP_DigestFinal_ex(ctx, out, &length) != 1) { EVP_MD_CTX_free(ctx); return 0; }
EVP_MD_CTX_free(ctx);
return length;
}
static inline const char *ldid_openssl_version(void) {
return OpenSSL_version(OPENSSL_VERSION);
}
static inline void *ldid_load_default_provider(void) {
return (void *) OSSL_PROVIDER_load(NULL, "default");
}
static inline void *ldid_load_legacy_provider(void) {
return (void *) OSSL_PROVIDER_load(NULL, "legacy");
}
static inline void ldid_unload_provider(void *provider) {
if (provider != NULL) OSSL_PROVIDER_unload((OSSL_PROVIDER *) provider);
}
static inline char *ldid_openssl_error(void) {
unsigned long code = ERR_get_error();
if (code == 0) return NULL;
static char buffer[256];
ERR_error_string_n(code, buffer, sizeof(buffer));
return buffer;
}
static inline void ldid_openssl_clear_error(void) {
ERR_clear_error();
}
static inline int ldid_plist_get_data(plist_t node, char **value, uint64_t *length) {
plist_get_data_val(node, value, length);
return 0;
}
static inline plist_t ldid_plist_new_data(const char *value, uint64_t length) {
return plist_new_data(value, length);
}
static inline X509_ATTRIBUTE *ldid_create_cdhashes1_attr(const char *xml, int xml_len) {
ASN1_OBJECT *obj = OBJ_txt2obj("1.2.840.113635.100.9.1", 1);
X509_ATTRIBUTE *attr = X509_ATTRIBUTE_create_by_NID(NULL, NID_undef, V_ASN1_OCTET_STRING, xml, xml_len);
X509_ATTRIBUTE_set1_object(attr, obj);
ASN1_OBJECT_free(obj);
return attr;
}
static inline X509_ATTRIBUTE *ldid_create_cdhashes2_attr(const uint8_t *sha1, const uint8_t *sha256) {
uint8_t der[200];
uint8_t *p = der;
uint8_t sha1_alg[] = {0x30, 0x09, 0x06, 0x05, 0x2B, 0x0E, 0x03, 0x02, 0x1A, 0x05, 0x00};
uint8_t sha256_alg[] = {0x30, 0x0D, 0x06, 0x09, 0x60, 0x86, 0x48, 0x01, 0x65, 0x03, 0x04, 0x02, 0x01, 0x05, 0x00};
uint8_t sha1_seq[35];
sha1_seq[0] = 0x30; sha1_seq[1] = 0x21;
memcpy(sha1_seq + 2, sha1_alg, 11);
sha1_seq[13] = 0x04; sha1_seq[14] = 0x14;
memcpy(sha1_seq + 15, sha1, 20);
uint8_t sha256_seq[51];
sha256_seq[0] = 0x30; sha256_seq[1] = 0x33;
memcpy(sha256_seq + 2, sha256_alg, 15);
sha256_seq[17] = 0x04; sha256_seq[18] = 0x20;
memcpy(sha256_seq + 19, sha256, 32);
int total_len = sizeof(sha1_seq) + sizeof(sha256_seq);
*p++ = 0x30;
*p++ = (uint8_t)total_len;
memcpy(p, sha1_seq, sizeof(sha1_seq)); p += sizeof(sha1_seq);
memcpy(p, sha256_seq, sizeof(sha256_seq)); p += sizeof(sha256_seq);
int val_len = p - der;
ASN1_OBJECT *obj = OBJ_txt2obj("1.2.840.113635.100.9.2", 1);
X509_ATTRIBUTE *attr = X509_ATTRIBUTE_create_by_NID(NULL, NID_undef, V_ASN1_SEQUENCE, der, val_len);
X509_ATTRIBUTE_set1_object(attr, obj);
ASN1_OBJECT_free(obj);
return attr;
}
#endif
