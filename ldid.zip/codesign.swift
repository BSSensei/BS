import Foundation
import Darwin

func csFatal(_ message: String) -> Never {
    FileHandle.standardError.write((message + "\n").data(using: .utf8)!)
    exit(1)
}

struct CS_SHA1 {
    private var h: [UInt32] = [0x67452301, 0xEFCDAB89, 0x98BADCFE, 0x10325476, 0xC3D2E1F0]
    private var buffer: [UInt8] = []
    private var total: UInt64 = 0

    private func rotl(_ x: UInt32, _ n: UInt32) -> UInt32 {
        return (x << n) | (x >> (32 - n))
    }

    mutating func update(_ data: Data) {
        total &+= UInt64(data.count)
        var bytes = [UInt8](data)
        if !buffer.isEmpty {
            let need = 64 - buffer.count
            let take = min(need, bytes.count)
            buffer.append(contentsOf: bytes.prefix(take))
            bytes.removeFirst(take)
            if buffer.count == 64 {
                process(buffer, 0)
                buffer.removeAll(keepingCapacity: true)
            }
        }
        var idx = 0
        while idx + 64 <= bytes.count {
            process(bytes, idx)
            idx += 64
        }
        if idx < bytes.count {
            buffer.append(contentsOf: bytes[idx...])
        }
    }

    private mutating func process(_ block: [UInt8], _ offset: Int) {
        var w = [UInt32](repeating: 0, count: 80)
        for i in 0..<16 {
            let o = offset + i * 4
            w[i] = (UInt32(block[o]) << 24) | (UInt32(block[o + 1]) << 16) | (UInt32(block[o + 2]) << 8) | UInt32(block[o + 3])
        }
        for i in 16..<80 {
            w[i] = rotl(w[i - 3] ^ w[i - 8] ^ w[i - 14] ^ w[i - 16], 1)
        }
        var a = h[0]
        var b = h[1]
        var c = h[2]
        var d = h[3]
        var e = h[4]
        for i in 0..<80 {
            var f: UInt32 = 0
            var k: UInt32 = 0
            if i < 20 {
                f = (b & c) | ((~b) & d)
                k = 0x5A827999
            } else if i < 40 {
                f = b ^ c ^ d
                k = 0x6ED9EBA1
            } else if i < 60 {
                f = (b & c) | (b & d) | (c & d)
                k = 0x8F1BBCDC
            } else {
                f = b ^ c ^ d
                k = 0xCA62C1D6
            }
            let temp = rotl(a, 5) &+ f &+ e &+ k &+ w[i]
            e = d
            d = c
            c = rotl(b, 30)
            b = a
            a = temp
        }
        h[0] = h[0] &+ a
        h[1] = h[1] &+ b
        h[2] = h[2] &+ c
        h[3] = h[3] &+ d
        h[4] = h[4] &+ e
    }

    mutating func finalize() -> Data {
        let bitLen = total &* 8
        var padding = [UInt8]()
        padding.append(0x80)
        while (buffer.count + padding.count) % 64 != 56 {
            padding.append(0)
        }
        var lengthBytes = [UInt8]()
        for i in (0..<8).reversed() {
            lengthBytes.append(UInt8((bitLen >> UInt64(i * 8)) & 0xff))
        }
        update(Data(padding))
        update(Data(lengthBytes))
        var out = Data()
        for value in h {
            out.append(UInt8((value >> 24) & 0xff))
            out.append(UInt8((value >> 16) & 0xff))
            out.append(UInt8((value >> 8) & 0xff))
            out.append(UInt8(value & 0xff))
        }
        return out
    }
}

struct CS_SHA256 {
    private var h: [UInt32] = [
        0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a,
        0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19
    ]
    private var buffer: [UInt8] = []
    private var total: UInt64 = 0
    private let k: [UInt32] = [
        0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
        0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
        0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
        0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
        0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
        0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
        0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
        0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2
    ]

    private func rotr(_ x: UInt32, _ n: UInt32) -> UInt32 {
        return (x >> n) | (x << (32 - n))
    }

    mutating func update(_ data: Data) {
        total &+= UInt64(data.count)
        var bytes = [UInt8](data)
        if !buffer.isEmpty {
            let need = 64 - buffer.count
            let take = min(need, bytes.count)
            buffer.append(contentsOf: bytes.prefix(take))
            bytes.removeFirst(take)
            if buffer.count == 64 {
                process(buffer, 0)
                buffer.removeAll(keepingCapacity: true)
            }
        }
        var idx = 0
        while idx + 64 <= bytes.count {
            process(bytes, idx)
            idx += 64
        }
        if idx < bytes.count {
            buffer.append(contentsOf: bytes[idx...])
        }
    }

    private mutating func process(_ block: [UInt8], _ offset: Int) {
        var w = [UInt32](repeating: 0, count: 64)
        for i in 0..<16 {
            let o = offset + i * 4
            w[i] = (UInt32(block[o]) << 24) | (UInt32(block[o + 1]) << 16) | (UInt32(block[o + 2]) << 8) | UInt32(block[o + 3])
        }
        for i in 16..<64 {
            let s0 = rotr(w[i - 15], 7) ^ rotr(w[i - 15], 18) ^ (w[i - 15] >> 3)
            let s1 = rotr(w[i - 2], 17) ^ rotr(w[i - 2], 19) ^ (w[i - 2] >> 10)
            w[i] = w[i - 16] &+ s0 &+ w[i - 7] &+ s1
        }
        var a = h[0]
        var b = h[1]
        var c = h[2]
        var d = h[3]
        var e = h[4]
        var f = h[5]
        var g = h[6]
        var hh = h[7]
        for i in 0..<64 {
            let s1 = rotr(e, 6) ^ rotr(e, 11) ^ rotr(e, 25)
            let ch = (e & f) ^ ((~e) & g)
            let t1 = hh &+ s1 &+ ch &+ k[i] &+ w[i]
            let s0 = rotr(a, 2) ^ rotr(a, 13) ^ rotr(a, 22)
            let maj = (a & b) ^ (a & c) ^ (b & c)
            let t2 = s0 &+ maj
            hh = g
            g = f
            f = e
            e = d &+ t1
            d = c
            c = b
            b = a
            a = t1 &+ t2
        }
        h[0] = h[0] &+ a
        h[1] = h[1] &+ b
        h[2] = h[2] &+ c
        h[3] = h[3] &+ d
        h[4] = h[4] &+ e
        h[5] = h[5] &+ f
        h[6] = h[6] &+ g
        h[7] = h[7] &+ hh
    }

    mutating func finalize() -> Data {
        let bitLen = total &* 8
        var padding = [UInt8]()
        padding.append(0x80)
        while (buffer.count + padding.count) % 64 != 56 {
            padding.append(0)
        }
        var lengthBytes = [UInt8]()
        for i in (0..<8).reversed() {
            lengthBytes.append(UInt8((bitLen >> UInt64(i * 8)) & 0xff))
        }
        update(Data(padding))
        update(Data(lengthBytes))
        var out = Data()
        for value in h {
            out.append(UInt8((value >> 24) & 0xff))
            out.append(UInt8((value >> 16) & 0xff))
            out.append(UInt8((value >> 8) & 0xff))
            out.append(UInt8(value & 0xff))
        }
        return out
    }
}

enum CSHash {
    static func sha1(_ data: Data) -> Data {
        var ctx = CS_SHA1()
        ctx.update(data)
        return ctx.finalize()
    }

    static func sha256(_ data: Data) -> Data {
        var ctx = CS_SHA256()
        ctx.update(data)
        return ctx.finalize()
    }
}

enum CSAlign {
    static func up(_ value: UInt64, _ alignment: UInt64) -> UInt64 {
        if alignment == 0 {
            return value
        }
        return (value + alignment - 1) / alignment * alignment
    }
}

enum CSByte {
    static func u32le(_ data: Data, _ offset: Int) -> UInt32 {
        if offset + 4 > data.count {
            csFatal("ldid: read out of range")
        }
        let b0 = UInt32(data[offset])
        let b1 = UInt32(data[offset + 1])
        let b2 = UInt32(data[offset + 2])
        let b3 = UInt32(data[offset + 3])
        return b0 | (b1 << 8) | (b2 << 16) | (b3 << 24)
    }

    static func u32be(_ data: Data, _ offset: Int) -> UInt32 {
        if offset + 4 > data.count {
            csFatal("ldid: read out of range")
        }
        let b0 = UInt32(data[offset])
        let b1 = UInt32(data[offset + 1])
        let b2 = UInt32(data[offset + 2])
        let b3 = UInt32(data[offset + 3])
        return (b0 << 24) | (b1 << 16) | (b2 << 8) | b3
    }

    static func u64le(_ data: Data, _ offset: Int) -> UInt64 {
        return UInt64(u32le(data, offset)) | (UInt64(u32le(data, offset + 4)) << 32)
    }

    static func u64be(_ data: Data, _ offset: Int) -> UInt64 {
        return (UInt64(u32be(data, offset)) << 32) | UInt64(u32be(data, offset + 4))
    }

    static func read32(_ data: Data, _ offset: Int, _ swapped: Bool) -> UInt32 {
        return swapped ? u32be(data, offset) : u32le(data, offset)
    }

    static func read64(_ data: Data, _ offset: Int, _ swapped: Bool) -> UInt64 {
        return swapped ? u64be(data, offset) : u64le(data, offset)
    }

    static func be32(_ value: UInt32) -> Data {
        var out = Data()
        out.append(UInt8((value >> 24) & 0xff))
        out.append(UInt8((value >> 16) & 0xff))
        out.append(UInt8((value >> 8) & 0xff))
        out.append(UInt8(value & 0xff))
        return out
    }

    static func be64(_ value: UInt64) -> Data {
        var out = Data()
        out.append(UInt8((value >> 56) & 0xff))
        out.append(UInt8((value >> 48) & 0xff))
        out.append(UInt8((value >> 40) & 0xff))
        out.append(UInt8((value >> 32) & 0xff))
        out.append(UInt8((value >> 24) & 0xff))
        out.append(UInt8((value >> 16) & 0xff))
        out.append(UInt8((value >> 8) & 0xff))
        out.append(UInt8(value & 0xff))
        return out
    }

    static func le32(_ value: UInt32) -> Data {
        var out = Data()
        out.append(UInt8(value & 0xff))
        out.append(UInt8((value >> 8) & 0xff))
        out.append(UInt8((value >> 16) & 0xff))
        out.append(UInt8((value >> 24) & 0xff))
        return out
    }

    static func le64(_ value: UInt64) -> Data {
        var out = Data()
        out.append(UInt8(value & 0xff))
        out.append(UInt8((value >> 8) & 0xff))
        out.append(UInt8((value >> 16) & 0xff))
        out.append(UInt8((value >> 24) & 0xff))
        out.append(UInt8((value >> 32) & 0xff))
        out.append(UInt8((value >> 40) & 0xff))
        out.append(UInt8((value >> 48) & 0xff))
        out.append(UInt8((value >> 56) & 0xff))
        return out
    }

    static func write32(_ value: UInt32, _ swapped: Bool) -> Data {
        return swapped ? be32(value) : le32(value)
    }

    static func write64(_ value: UInt64, _ swapped: Bool) -> Data {
        return swapped ? be64(value) : le64(value)
    }
}

enum CSStreamIO {
    static func openRead(_ path: String) -> Int32 {
        let fd = open(path, O_RDONLY)
        if fd < 0 {
            csFatal("ldid: \(path): unable to open")
        }
        return fd
    }

    static func closeFD(_ fd: Int32) {
        close(fd)
    }

    static func fileSizeFD(_ fd: Int32) -> UInt64 {
        var st = stat()
        if fstat(fd, &st) != 0 {
            csFatal("ldid: fstat failed")
        }
        return UInt64(st.st_size)
    }

    static func fileSize(_ path: String) -> UInt64 {
        var st = stat()
        if stat(path, &st) != 0 {
            csFatal("ldid: \(path): unable to stat")
        }
        return UInt64(st.st_size)
    }

    static func pread(_ fd: Int32, _ offset: UInt64, _ count: Int) -> Data {
        if count <= 0 {
            return Data()
        }
        var data = Data(count: count)
        let n = data.withUnsafeMutableBytes { (ptr: UnsafeMutableRawBufferPointer) -> Int in
            return Darwin.pread(fd, ptr.baseAddress, count, off_t(offset))
        }
        if n <= 0 {
            return Data()
        }
        if n < count {
            data.removeSubrange(n..<count)
        }
        return data
    }

    static func preadExactOrPad(_ fd: Int32, _ offset: UInt64, _ count: Int) -> Data {
        var data = pread(fd, offset, count)
        if data.count < count {
            data.append(Data(count: count - data.count))
        }
        return data
    }

    static func readSmallFile(_ path: String, limit: UInt64 = 16 * 1024 * 1024) -> Data {
        let size = fileSize(path)
        if size > limit {
            csFatal("ldid: \(path): file too large")
        }
        let fd = openRead(path)
        defer { closeFD(fd) }
        let data = pread(fd, 0, Int(size))
        if UInt64(data.count) != size {
            csFatal("ldid: \(path): short read")
        }
        return data
    }

    static func tempPath() -> String {
        return NSTemporaryDirectory() + "ldid-" + ProcessInfo.processInfo.globallyUniqueString
    }

    static func removeFile(_ path: String) {
        path.withCString { unlink($0) }
    }

    static func copyFileRange(from fd: Int32, offset: UInt64, length: UInt64, to out: FileHandle) {
        var remaining = length
        var current = offset
        while remaining > 0 {
            let chunk = Int(min(remaining, UInt64(1 << 20)))
            var data = pread(fd, current, chunk)
            if data.count < chunk {
                data.append(Data(count: chunk - data.count))
            }
            out.write(data)
            current += UInt64(chunk)
            remaining -= UInt64(chunk)
        }
    }

    static func parseMach(_ path: String) -> (Bool, [CSFatSlice]) {
        let fd = openRead(path)
        defer { closeFD(fd) }
        let fileSize = fileSizeFD(fd)
        if fileSize < 4 {
            csFatal("ldid: \(path): file too small")
        }
        let head = pread(fd, 0, 8)
        if head.count < 4 {
            csFatal("ldid: \(path): file too small")
        }
        let magicLE = CSByte.u32le(head, 0)
        let magicBE = CSByte.u32be(head, 0)
        if magicBE == 0xcafebabe || magicLE == 0xcafebabe {
            let swapped = magicBE != 0xcafebabe
            if head.count < 8 {
                csFatal("ldid: \(path): bad fat header")
            }
            let n = swapped ? CSByte.u32le(head, 4) : CSByte.u32be(head, 4)
            let archData = pread(fd, 8, Int(n) * 20)
            if archData.count < Int(n) * 20 {
                csFatal("ldid: \(path): bad fat arch table")
            }
            var slices: [CSFatSlice] = []
            var off = 0
            for _ in 0..<Int(n) {
                let cputype = swapped ? CSByte.u32le(archData, off) : CSByte.u32be(archData, off)
                let cpusubtype = swapped ? CSByte.u32le(archData, off + 4) : CSByte.u32be(archData, off + 4)
                let offset = swapped ? CSByte.u32le(archData, off + 8) : CSByte.u32be(archData, off + 8)
                let size = swapped ? CSByte.u32le(archData, off + 12) : CSByte.u32be(archData, off + 12)
                let align = swapped ? CSByte.u32le(archData, off + 16) : CSByte.u32be(archData, off + 16)
                if UInt64(offset) + UInt64(size) > fileSize {
                    csFatal("ldid: \(path): fat slice out of range")
                }
                slices.append(CSFatSlice(offset: UInt64(offset), size: UInt64(size), cputype: cputype, cpusubtype: cpusubtype, align: align))
                off += 20
            }
            return (true, slices)
        }
        let magic = magicLE
        if magic == 0xfeedface || magic == 0xfeedfacf || magic == 0xcefaedfe || magic == 0xcffaedfe {
            let swapped = magic == 0xcefaedfe || magic == 0xcffaedfe
            let bits64 = magic == 0xfeedfacf || magic == 0xcffaedfe
            let header = pread(fd, 0, 12)
            if header.count < 12 {
                csFatal("ldid: \(path): bad Mach-O header")
            }
            let cputype = swapped ? CSByte.u32be(header, 4) : CSByte.u32le(header, 4)
            let cpusubtype = swapped ? CSByte.u32be(header, 8) : CSByte.u32le(header, 8)
            let slice = CSFatSlice(offset: 0, size: fileSize, cputype: cputype, cpusubtype: cpusubtype, align: bits64 ? 3 : 2)
            return (false, [slice])
        }
        csFatal("ldid: \(path): unknown Mach-O magic")
    }

    static func loadSliceInfo(fd: Int32, slice: CSFatSlice) -> CSSliceInfo {
        let header = pread(fd, slice.offset, 32)
        if header.count < 28 {
            csFatal("ldid: bad Mach-O slice header")
        }
        let magicLE = CSByte.u32le(header, 0)
        let swapped = magicLE == 0xcefaedfe || magicLE == 0xcffaedfe
        let bits64 = magicLE == 0xfeedfacf || magicLE == 0xcffaedfe
        if !bits64 && magicLE != 0xfeedface && !swapped {
            csFatal("ldid: bad Mach-O slice magic")
        }
        let headerSize = bits64 ? 32 : 28
        let filetype = CSByte.read32(header, 12, swapped)
        let ncmds = CSByte.read32(header, 16, swapped)
        let sizeofcmds = CSByte.read32(header, 20, swapped)
        if UInt64(sizeofcmds) > 16 * 1024 * 1024 {
            csFatal("ldid: load commands too large")
        }
        let areaSize = headerSize + Int(sizeofcmds)
        if UInt64(areaSize) > slice.size {
            csFatal("ldid: load commands out of range")
        }
        let area = pread(fd, slice.offset, areaSize)
        if area.count < areaSize {
            csFatal("ldid: short load command read")
        }
        var commands: [CSLoadCommand] = []
        var off = headerSize
        var oldSignature: CSOldSignature? = nil
        var cryptid: UInt32? = nil
        var execSegBase: UInt64 = 0
        var execSegEnd: UInt64 = 0
        var linkedit: (cmd: UInt32, relativeOffset: Int, fileoff: UInt64, filesize: UInt64)? = nil
        let commandsEndAbs = slice.offset + UInt64(areaSize)
        var contentStartAbs = commandsEndAbs
        for _ in 0..<Int(ncmds) {
            if off + 8 > area.count {
                break
            }
            let cmd = CSByte.read32(area, off, swapped)
            let cmdsize = CSByte.read32(area, off + 4, swapped)
            if cmdsize < 8 || off + Int(cmdsize) > area.count {
                break
            }
            commands.append(CSLoadCommand(cmd: cmd, cmdsize: cmdsize, relativeOffset: off))
            if cmd == 0x1d {
                let dataoff = CSByte.read32(area, off + 8, swapped)
                let datasize = CSByte.read32(area, off + 12, swapped)
                oldSignature = CSOldSignature(dataoff: dataoff, datasize: datasize, commandOffset: off)
            } else if cmd == 0x21 || cmd == 0x2c {
                cryptid = CSByte.read32(area, off + 16, swapped)
            } else if cmd == 0x19 || cmd == 0x01 {
                var nameBytes = [UInt8]()
                for j in 0..<16 {
                    let b = area[off + 8 + j]
                    if b == 0 {
                        break
                    }
                    nameBytes.append(b)
                }
                let name = String(bytes: nameBytes, encoding: .utf8) ?? ""
                if cmd == 0x19 {
                    let vmaddr = CSByte.read64(area, off + 24, swapped)
                    let vmsize = CSByte.read64(area, off + 32, swapped)
                    let fileoff = CSByte.read64(area, off + 40, swapped)
                    let filesize = CSByte.read64(area, off + 48, swapped)
                    let initprot = CSByte.read32(area, off + 60, swapped)
                    let nsects = CSByte.read32(area, off + 64, swapped)
                    if (initprot & 4) != 0 {
                        if execSegBase == 0 || vmaddr < execSegBase {
                            execSegBase = vmaddr
                        }
                        if vmaddr + vmsize > execSegEnd {
                            execSegEnd = vmaddr + vmsize
                        }
                    }
                    if name == "__LINKEDIT" {
                        linkedit = (cmd, off, fileoff, filesize)
                    }
                    let sectionsStart = off + 72
                    for s in 0..<Int(nsects) {
                        let sectRel = sectionsStart + s * 80
                        if sectRel + 80 > area.count {
                            break
                        }
                        let sectFileOff = CSByte.read32(area, sectRel + 48, swapped)
                        let abs = slice.offset + UInt64(sectFileOff)
                        if abs > commandsEndAbs && abs < contentStartAbs {
                            contentStartAbs = abs
                        }
                    }
                } else {
                    let vmaddr = UInt64(CSByte.read32(area, off + 24, swapped))
                    let vmsize = UInt64(CSByte.read32(area, off + 28, swapped))
                    let fileoff = UInt64(CSByte.read32(area, off + 32, swapped))
                    let filesize = UInt64(CSByte.read32(area, off + 36, swapped))
                    let initprot = CSByte.read32(area, off + 44, swapped)
                    let nsects = CSByte.read32(area, off + 48, swapped)
                    if (initprot & 4) != 0 {
                        if execSegBase == 0 || vmaddr < execSegBase {
                            execSegBase = vmaddr
                        }
                        if vmaddr + vmsize > execSegEnd {
                            execSegEnd = vmaddr + vmsize
                        }
                    }
                    if name == "__LINKEDIT" {
                        linkedit = (cmd, off, fileoff, filesize)
                    }
                    let sectionsStart = off + 56
                    for s in 0..<Int(nsects) {
                        let sectRel = sectionsStart + s * 68
                        if sectRel + 68 > area.count {
                            break
                        }
                        let sectFileOff = CSByte.read32(area, sectRel + 40, swapped)
                        let abs = slice.offset + UInt64(sectFileOff)
                        if abs > commandsEndAbs && abs < contentStartAbs {
                            contentStartAbs = abs
                        }
                    }
                }
            }
            off += Int(cmdsize)
        }
        return CSSliceInfo(
            headerSize: headerSize,
            bits64: bits64,
            swapped: swapped,
            filetype: filetype,
            ncmds: ncmds,
            sizeofcmds: sizeofcmds,
            commands: commands,
            commandsArea: area,
            commandsEnd: commandsEndAbs,
            contentStart: contentStartAbs,
            oldSignature: oldSignature,
            cryptid: cryptid,
            execSegBase: execSegBase,
            execSegEnd: execSegEnd,
            linkedit: linkedit
        )
    }
}

struct CSFatSlice {
    var offset: UInt64
    var size: UInt64
    var cputype: UInt32
    var cpusubtype: UInt32
    var align: UInt32
}

struct CSLoadCommand {
    var cmd: UInt32
    var cmdsize: UInt32
    var relativeOffset: Int
}

struct CSOldSignature {
    var dataoff: UInt32
    var datasize: UInt32
    var commandOffset: Int
}

struct CSSliceInfo {
    var headerSize: Int
    var bits64: Bool
    var swapped: Bool
    var filetype: UInt32
    var ncmds: UInt32
    var sizeofcmds: UInt32
    var commands: [CSLoadCommand]
    var commandsArea: Data
    var commandsEnd: UInt64
    var contentStart: UInt64
    var oldSignature: CSOldSignature?
    var cryptid: UInt32?
    var execSegBase: UInt64
    var execSegEnd: UInt64
    var linkedit: (cmd: UInt32, relativeOffset: Int, fileoff: UInt64, filesize: UInt64)?
}

struct CSExistingSignature {
    var identifier: String? = nil
    var team: String? = nil
    var flags: UInt32? = nil
    var requirementsBlob: Data? = nil
    var entitlementsXML: String? = nil
    var derBlob: Data? = nil
}

enum CSExistingSignatureReader {
    static func extract(fd: Int32, slice: CSFatSlice, info: CSSliceInfo) -> CSExistingSignature {
        var result = CSExistingSignature()
        guard let old = info.oldSignature else {
            return result
        }
        let sigAbs = slice.offset + UInt64(old.dataoff)
        let header = CSStreamIO.pread(fd, sigAbs, 12)
        if header.count < 12 {
            return result
        }
        let magic = CSByte.u32be(header, 0)
        if magic != 0xfade0cc0 && magic != 0xfade0cc1 {
            return result
        }
        let count = CSByte.u32be(header, 8)
        let indexData = CSStreamIO.pread(fd, sigAbs + 12, Int(count) * 8)
        if indexData.count < Int(count) * 8 {
            return result
        }
        for i in 0..<Int(count) {
            let slot = CSByte.u32be(indexData, i * 8)
            let rel = CSByte.u32be(indexData, i * 8 + 4)
            let blobAbs = sigAbs + UInt64(rel)
            let blobHeader = CSStreamIO.pread(fd, blobAbs, 8)
            if blobHeader.count < 8 {
                continue
            }
            let blobMagic = CSByte.u32be(blobHeader, 0)
            let blobLen = CSByte.u32be(blobHeader, 4)
            if blobLen < 8 || UInt64(blobLen) > UInt64(old.datasize) {
                continue
            }
            if slot == 2 {
                if blobLen <= 16 * 1024 * 1024 {
                    let data = CSStreamIO.pread(fd, blobAbs, Int(blobLen))
                    if UInt32(data.count) == blobLen {
                        result.requirementsBlob = data
                    }
                }
            } else if slot == 5 {
                if blobLen <= 16 * 1024 * 1024 {
                    let data = CSStreamIO.pread(fd, blobAbs, Int(blobLen))
                    if UInt32(data.count) == blobLen && data.count > 8 {
                        let payload = data.subdata(in: 8..<data.count)
                        result.entitlementsXML = String(data: payload, encoding: .utf8)
                    }
                }
            } else if slot == 7 {
                if blobLen <= 16 * 1024 * 1024 {
                    let data = CSStreamIO.pread(fd, blobAbs, Int(blobLen))
                    if UInt32(data.count) == blobLen {
                        result.derBlob = data
                    }
                }
            } else if slot == 0 || slot == 0x1000 {
                if result.identifier == nil {
                    let cdHeader = CSStreamIO.pread(fd, blobAbs, 88)
                    if cdHeader.count < 88 {
                        continue
                    }
                    let blobMagic2 = CSByte.u32be(cdHeader, 0)
                    if blobMagic2 != 0xfade0c02 {
                        continue
                    }
                    let flags = CSByte.u32be(cdHeader, 12)
                    let identOffset = CSByte.u32be(cdHeader, 20)
                    let teamOffset = CSByte.u32be(cdHeader, 48)
                    result.flags = flags
                    if identOffset >= 8 && UInt64(identOffset) < UInt64(blobLen) {
                        result.identifier = readCString(fd: fd, offset: blobAbs + UInt64(identOffset), limit: UInt64(blobLen) - UInt64(identOffset))
                    }
                    if teamOffset >= 8 && UInt64(teamOffset) < UInt64(blobLen) {
                        result.team = readCString(fd: fd, offset: blobAbs + UInt64(teamOffset), limit: UInt64(blobLen) - UInt64(teamOffset))
                    }
                }
            }
            _ = blobMagic
        }
        return result
    }

    static func readCString(fd: Int32, offset: UInt64, limit: UInt64) -> String {
        var data = Data()
        var current = offset
        var remaining = min(limit, 65536)
        while remaining > 0 {
            let chunk = Int(min(UInt64(4096), remaining))
            let d = CSStreamIO.pread(fd, current, chunk)
            if d.isEmpty {
                break
            }
            for b in d {
                if b == 0 {
                    return String(data: data, encoding: .utf8) ?? ""
                }
                data.append(b)
            }
            current += UInt64(d.count)
            remaining -= UInt64(d.count)
        }
        return String(data: data, encoding: .utf8) ?? ""
    }
}

enum CSPropertyList {
    static func object(from data: Data) -> Any? {
        return try? PropertyListSerialization.propertyList(from: data, options: [], format: nil)
    }

    static func xmlData(from object: Any) -> Data? {
        return try? PropertyListSerialization.data(fromPropertyList: object, format: .xml, options: 0)
    }

    static func mergeXML(oldXML: String?, newXML: String?) -> String? {
        guard let newXML = newXML else {
            return oldXML
        }
        guard let oldXML = oldXML else {
            return newXML
        }
        guard
            let oldObj = object(from: Data(oldXML.utf8)) as? [String: Any],
            let newObj = object(from: Data(newXML.utf8)) as? [String: Any]
        else {
            return newXML
        }
        var merged = oldObj
        for (key, value) in newObj {
            merged[key] = value
        }
        guard let out = xmlData(from: merged) else {
            return newXML
        }
        return String(data: out, encoding: .utf8)
    }
}

enum CSDER {
    static func encode(_ obj: Any) -> Data {
        if let b = obj as? Bool {
            return derBool(b)
        }
        if let s = obj as? String {
            return derUTF8(s)
        }
        if let d = obj as? Data {
            return derOctet(d)
        }
        if let arr = obj as? [Any] {
            var payload = Data()
            for item in arr {
                payload.append(encode(item))
            }
            return derTag(0x30, payload)
        }
        if let dict = obj as? [String: Any] {
            var pairs = [Data]()
            for (key, value) in dict {
                let keyData = derUTF8(key)
                let valueData = encode(value)
                let pairPayload = keyData + valueData
                pairs.append(derTag(0x30, pairPayload))
            }
            pairs.sort { $0.lexicographicallyPrecedes($1) }
            var payload = Data()
            for pair in pairs {
                payload.append(pair)
            }
            return derTag(0x31, payload)
        }
        if let n = obj as? NSNumber {
            return derInteger(n.int64Value)
        }
        if let date = obj as? Date {
            return derUTF8(date.description)
        }
        csFatal("ldid: unsupported plist type in DER encoder")
    }

    static func derTag(_ tag: UInt8, _ payload: Data) -> Data {
        var out = Data()
        out.append(tag)
        out.append(length(UInt64(payload.count)))
        out.append(payload)
        return out
    }

    static func derBool(_ value: Bool) -> Data {
        var out = Data()
        out.append(0x01)
        out.append(0x01)
        out.append(value ? 1 : 0)
        return out
    }

    static func derUTF8(_ value: String) -> Data {
        return derTag(0x0c, Data(value.utf8))
    }

    static func derOctet(_ value: Data) -> Data {
        return derTag(0x04, value)
    }

    static func derInteger(_ value: Int64) -> Data {
        var bytes = [UInt8]()
        if value == 0 {
            bytes.append(0)
        } else if value > 0 {
            var v = UInt64(value)
            while v > 0 {
                bytes.insert(UInt8(v & 0xff), at: 0)
                v >>= 8
            }
            if bytes[0] & 0x80 != 0 {
                bytes.insert(0, at: 0)
            }
        } else {
            var v = UInt64(bitPattern: value)
            var all = [UInt8]()
            for i in 0..<8 {
                all.append(UInt8((v >> UInt64((7 - i) * 8)) & 0xff))
            }
            var start = 0
            while start < 7 && all[start] == 0xff && all[start + 1] & 0x80 != 0 {
                start += 1
            }
            bytes = Array(all[start...])
        }
        return derTag(0x02, Data(bytes))
    }

    static func length(_ value: UInt64) -> Data {
        if value < 128 {
            return Data([UInt8(value)])
        }
        var v = value
        var bytes = [UInt8]()
        while v > 0 {
            bytes.insert(UInt8(v & 0xff), at: 0)
            v >>= 8
        }
        return Data([0x80 | UInt8(bytes.count)] + bytes)
    }
}

enum CSBlob {
    static func make(magic: UInt32, payload: Data) -> Data {
        var out = Data()
        out.append(CSByte.be32(magic))
        out.append(CSByte.be32(UInt32(8 + payload.count)))
        out.append(payload)
        return out
    }

    static func ensureBlob(_ data: Data, magic: UInt32) -> Data {
        if data.count >= 8 {
            let m = CSByte.u32be(data, 0)
            if m == magic {
                return data
            }
        }
        return make(magic: magic, payload: data)
    }
}

struct CSCodeDirectoryWriter {
    static func create(
        path: String,
        identifier: String,
        team: String,
        hashType: UInt8,
        hashSize: Int,
        flags: UInt32,
        platform: UInt8,
        pageSizeShift: UInt8,
        codeLimit: UInt64,
        nPages: UInt32,
        specialHashes: [UInt32: Data],
        execSegBase: UInt64,
        execSegLimit: UInt64,
        execSegFlags: UInt64
    ) -> FileHandle {
        var maxSpecial: UInt32 = 0
        for key in specialHashes.keys {
            if key > maxSpecial {
                maxSpecial = key
            }
        }
        var ident = Array(identifier.utf8)
        ident.append(0)
        var teamBytes = [UInt8]()
        if !team.isEmpty {
            teamBytes = Array(team.utf8)
            teamBytes.append(0)
        }
        let headerSize = 80
        var offset = UInt32(8 + headerSize)
        let identOffset = offset
        offset += UInt32(ident.count)
        var teamOffset: UInt32 = 0
        if !team.isEmpty {
            teamOffset = offset
            offset += UInt32(teamBytes.count)
        }
        offset += maxSpecial * UInt32(hashSize)
        let hashOffset = offset
        let blobLength = UInt64(hashOffset) + UInt64(nPages) * UInt64(hashSize)
        if blobLength > 0xffffffff {
            csFatal("ldid: CodeDirectory too large")
        }
        FileManager.default.createFile(atPath: path, contents: nil)
        guard let fh = try? FileHandle(forWritingTo: URL(fileURLWithPath: path)) else {
            csFatal("ldid: unable to create temporary CodeDirectory")
        }
        var header = Data()
        header.append(CSByte.be32(0xfade0c02))
        header.append(CSByte.be32(UInt32(blobLength)))
        header.append(CSByte.be32(0x00020400))
        header.append(CSByte.be32(flags))
        header.append(CSByte.be32(hashOffset))
        header.append(CSByte.be32(identOffset))
        header.append(CSByte.be32(maxSpecial))
        header.append(CSByte.be32(nPages))
        let codeLimit32: UInt32 = codeLimit > 0xffffffff ? 0xffffffff : UInt32(codeLimit)
        header.append(CSByte.be32(codeLimit32))
        header.append(UInt8(hashSize))
        header.append(hashType)
        header.append(platform)
        header.append(pageSizeShift)
        header.append(CSByte.be32(0))
        header.append(CSByte.be32(0))
        header.append(CSByte.be32(teamOffset))
        header.append(CSByte.be32(0))
        header.append(CSByte.be64(codeLimit))
        header.append(CSByte.be64(execSegBase))
        header.append(CSByte.be64(execSegLimit))
        header.append(CSByte.be64(execSegFlags))
        header.append(Data(ident))
        if !team.isEmpty {
            header.append(Data(teamBytes))
        }
        if maxSpecial > 0 {
            var slot = maxSpecial
            while slot >= 1 {
                var h = specialHashes[slot] ?? Data(count: hashSize)
                if h.count != hashSize {
                    csFatal("ldid: bad special hash length")
                }
                header.append(h)
                slot -= 1
            }
        }
        fh.write(header)
        return fh
    }
}

enum CSPageHasher {
    static func write(fd: Int32, sliceOffset: UInt64, limit: UInt64, pageSizeShift: UInt8, outputs: [(UInt8, FileHandle)]) {
        let pageSize = UInt64(1) << pageSizeShift
        var remaining = limit
        var current = sliceOffset
        while remaining > 0 {
            let pageLen = Int(min(pageSize, remaining))
            let data = CSStreamIO.preadExactOrPad(fd, current, pageLen)
            for output in outputs {
                if output.0 == 1 {
                    var ctx = CS_SHA1()
                    ctx.update(data)
                    output.1.write(ctx.finalize())
                } else if output.0 == 2 {
                    var ctx = CS_SHA256()
                    ctx.update(data)
                    output.1.write(ctx.finalize())
                }
            }
            current += UInt64(pageLen)
            remaining -= UInt64(pageLen)
        }
    }
}

enum CSSuperBlobSource {
    case data(Data)
    case file(String)
}

enum CSSuperBlobWriter {
    static func write(magic: UInt32, items: [(UInt32, CSSuperBlobSource)], to path: String) -> UInt64 {
        var sizes = [UInt64]()
        for item in items {
            switch item.1 {
            case .data(let data):
                sizes.append(UInt64(data.count))
            case .file(let filePath):
                sizes.append(CSStreamIO.fileSize(filePath))
            }
        }
        let headerSize = UInt64(12 + items.count * 8)
        var total = headerSize
        for size in sizes {
            total += size
        }
        if total > 0xffffffff {
            csFatal("ldid: SuperBlob too large")
        }
        FileManager.default.createFile(atPath: path, contents: nil)
        guard let out = try? FileHandle(forWritingTo: URL(fileURLWithPath: path)) else {
            csFatal("ldid: unable to create temporary SuperBlob")
        }
        var header = Data()
        header.append(CSByte.be32(magic))
        header.append(CSByte.be32(UInt32(total)))
        header.append(CSByte.be32(UInt32(items.count)))
        var offset = headerSize
        for i in 0..<items.count {
            header.append(CSByte.be32(items[i].0))
            header.append(CSByte.be32(UInt32(offset)))
            offset += sizes[i]
        }
        out.write(header)
        for item in items {
            switch item.1 {
            case .data(let data):
                out.write(data)
            case .file(let filePath):
                let fd = CSStreamIO.openRead(filePath)
                CSStreamIO.copyFileRange(from: fd, offset: 0, length: sizes[items.firstIndex(where: { $0.0 == item.0 && $0.1.isSameFile(filePath) })!], to: out)
                CSStreamIO.closeFD(fd)
            }
        }
        out.closeFile()
        return total
    }
}

extension CSSuperBlobSource {
    func isSameFile(_ path: String) -> Bool {
        if case .file(let p) = self {
            return p == path
        }
        return false
    }
}

struct CSSignOptions {
    var identifier: String? = nil
    var entitlementsPath: String? = nil
    var requirementsPath: String? = nil
    var flags: UInt32 = 0
    var platform: UInt8 = 0
    var team: String = ""
    var pageSizeShift: UInt8 = 12
    var digestAlgorithms: [UInt8] = [1, 2]
    var force: Bool = false
    var dryRun: Bool = false
    var preserveIdentifier: Bool = false
    var preserveEntitlements: Bool = false
    var preserveRequirements: Bool = false
    var preserveFlags: Bool = false
    var preserveTeam: Bool = false
    var mergeEntitlements: Bool = false
    var resourceSHA1: Data? = nil
    var resourceSHA256: Data? = nil
}

enum CSAdhocSigner {
    static func sign(path: String, options: CSSignOptions) {
        let (isFat, slices) = CSStreamIO.parseMach(path)
        let fd = CSStreamIO.openRead(path)
        defer { CSStreamIO.closeFD(fd) }
        if !isFat {
            let signed = signSlice(inputFD: fd, inputPath: path, slice: slices[0], options: options)
            defer { CSStreamIO.removeFile(signed) }
            if !options.dryRun {
                replaceFile(signed, path)
            }
            return
        }
        var signedPaths = [String]()
        for slice in slices {
            signedPaths.append(signSlice(inputFD: fd, inputPath: path, slice: slice, options: options))
        }
        defer {
            for p in signedPaths {
                CSStreamIO.removeFile(p)
            }
        }
        if options.dryRun {
            return
        }
        let outPath = CSStreamIO.tempPath()
        assembleFat(originalSlices: slices, signedPaths: signedPaths, to: outPath)
        defer { CSStreamIO.removeFile(outPath) }
        replaceFile(outPath, path)
    }

    static func signSlice(inputFD: Int32, inputPath: String, slice: CSFatSlice, options: CSSignOptions) -> String {
        let info = CSStreamIO.loadSliceInfo(fd: inputFD, slice: slice)
        if info.oldSignature != nil && !options.force {
            csFatal("ldid: \(inputPath): already signed, use force")
        }
        let old = CSExistingSignatureReader.extract(fd: inputFD, slice: slice, info: info)
        var identifier = options.identifier ?? URL(fileURLWithPath: inputPath).lastPathComponent
        if options.preserveIdentifier, let oldIdentifier = old.identifier, !oldIdentifier.isEmpty {
            identifier = oldIdentifier
        }
        var entitlementXML: String? = nil
        if let entPath = options.entitlementsPath {
            let data = CSStreamIO.readSmallFile(entPath)
            entitlementXML = String(data: data, encoding: .utf8)
        }
        if options.mergeEntitlements || options.preserveEntitlements {
            entitlementXML = CSPropertyList.mergeXML(oldXML: old.entitlementsXML, newXML: entitlementXML)
        }
        var requirementsBlob: Data? = nil
        if options.preserveRequirements && old.requirementsBlob != nil {
            requirementsBlob = old.requirementsBlob
        } else if let reqPath = options.requirementsPath {
            let data = CSStreamIO.readSmallFile(reqPath)
            requirementsBlob = CSBlob.ensureBlob(data, magic: 0xfade0c01)
        }
        var flags = options.flags
        if options.preserveFlags, let oldFlags = old.flags {
            flags |= oldFlags
        }
        var team = options.team
        if options.preserveTeam, let oldTeam = old.team, !oldTeam.isEmpty {
            team = oldTeam
        }
        var entitlementBlob: Data? = nil
        var derBlob: Data? = nil
        var entitlementObject: Any? = nil
        if let xml = entitlementXML, !xml.isEmpty {
            let xmlData = Data(xml.utf8)
            guard let obj = CSPropertyList.object(from: xmlData) else {
                csFatal("ldid: invalid entitlements plist")
            }
            entitlementObject = obj
            entitlementBlob = CSBlob.make(magic: 0xfade7171, payload: xmlData)
            derBlob = CSBlob.make(magic: 0xfade7172, payload: CSDER.encode(obj))
        } else if options.preserveEntitlements && old.derBlob != nil {
            derBlob = old.derBlob
        }
        var specialSHA1 = [UInt32: Data]()
        var specialSHA256 = [UInt32: Data]()
        if let blob = requirementsBlob {
            specialSHA1[2] = CSHash.sha1(blob)
            specialSHA256[2] = CSHash.sha256(blob)
        }
        if let blob = entitlementBlob {
            specialSHA1[5] = CSHash.sha1(blob)
            specialSHA256[5] = CSHash.sha256(blob)
        }
        if let blob = derBlob {
            specialSHA1[7] = CSHash.sha1(blob)
            specialSHA256[7] = CSHash.sha256(blob)
        }
        if let r1 = options.resourceSHA1 {
            specialSHA1[3] = r1
        }
        if let r2 = options.resourceSHA256 {
            specialSHA256[3] = r2
        }
        var limit: UInt64
        if let oldSig = info.oldSignature {
            limit = UInt64(oldSig.dataoff)
        } else {
            limit = slice.size
        }
        if limit > slice.size {
            limit = slice.size
        }
        let signatureOffset = CSAlign.up(limit, 16)
        if signatureOffset > 0xffffffff {
            csFatal("ldid: signature offset too large")
        }
        let contentStartRel = info.contentStart - slice.offset
        if signatureOffset < contentStartRel {
            csFatal("ldid: not enough space before content start")
        }
        let pageSizeShift = options.pageSizeShift
        if pageSizeShift < 12 || pageSizeShift > 24 {
            csFatal("ldid: invalid page size")
        }
        let pageSize = UInt64(1) << pageSizeShift
        let nPages = UInt32((limit + pageSize - 1) / pageSize)
        var execSegFlags: UInt64 = 0
        if info.filetype == 2 {
            execSegFlags |= 0x001
        }
        if let dict = entitlementObject as? [String: Any] {
            if boolValue(dict, "get-task-allow") || boolValue(dict, "run-unsigned-code") {
                execSegFlags |= 0x010
            }
            if boolValue(dict, "com.apple.private.cs.debugger") {
                execSegFlags |= 0x020
            }
            if boolValue(dict, "dynamic-codesigning") {
                execSegFlags |= 0x040
            }
            if boolValue(dict, "com.apple.private.skip-library-validation") {
                execSegFlags |= 0x080
            }
            if boolValue(dict, "com.apple.private.amfi.can-load-cdhash") || boolValue(dict, "com.apple.private.amfi.can-execute-cdhash") {
                execSegFlags |= 0x100
            }
        }
        var digests = options.digestAlgorithms
        if digests.isEmpty {
            digests = [1, 2]
        }
        var seen = Set<UInt8>()
        digests = digests.filter { seen.insert($0).inserted }
        let hasSHA1 = digests.contains(1)
        var cdOutputs = [(UInt8, FileHandle)]()
        var cdFiles = [(UInt8, UInt32, String)]()
        for digest in digests {
            var hashSize = 0
            if digest == 1 {
                hashSize = 20
            } else if digest == 2 {
                hashSize = 32
            } else {
                csFatal("ldid: unsupported digest algorithm")
            }
            let path = CSStreamIO.tempPath()
            let special = digest == 1 ? specialSHA1 : specialSHA256
            let slot: UInt32
            if digest == 1 {
                slot = 0
            } else if digest == 2 {
                slot = hasSHA1 ? 0x1000 : 0
            } else {
                slot = 0x2000
            }
            let fh = CSCodeDirectoryWriter.create(
                path: path,
                identifier: identifier,
                team: team,
                hashType: digest,
                hashSize: hashSize,
                flags: flags,
                platform: options.platform,
                pageSizeShift: pageSizeShift,
                codeLimit: limit,
                nPages: nPages,
                specialHashes: special,
                execSegBase: info.execSegBase,
                execSegLimit: info.execSegEnd >= info.execSegBase ? info.execSegEnd - info.execSegBase : 0,
                execSegFlags: execSegFlags
            )
            cdOutputs.append((digest, fh))
            cdFiles.append((digest, slot, path))
        }
        CSPageHasher.write(fd: inputFD, sliceOffset: slice.offset, limit: limit, pageSizeShift: pageSizeShift, outputs: cdOutputs)
        for output in cdOutputs {
            output.1.closeFile()
        }
        var superItems = [(UInt32, CSSuperBlobSource)]()
        if let blob = requirementsBlob {
            superItems.append((2, .data(blob)))
        }
        if let blob = entitlementBlob {
            superItems.append((5, .data(blob)))
        }
        if let blob = derBlob {
            superItems.append((7, .data(blob)))
        }
        for cd in cdFiles {
            superItems.append((cd.1, .file(cd.2)))
        }
        let superPath = CSStreamIO.tempPath()
        let superSize = CSSuperBlobWriter.write(magic: 0xfade0cc0, items: superItems, to: superPath)
        for cd in cdFiles {
            CSStreamIO.removeFile(cd.2)
        }
        let built = buildCommands(info: info, slice: slice, signatureOffset: UInt32(signatureOffset), superSize: UInt32(superSize))
        let commandsEndRel = info.commandsEnd - slice.offset
        let available = contentStartRel - UInt64(info.headerSize)
        if UInt64(built.sizeofcmds) > available {
            csFatal("ldid: not enough load command space")
        }
        let outPath = CSStreamIO.tempPath()
        FileManager.default.createFile(atPath: outPath, contents: nil)
        guard let out = try? FileHandle(forWritingTo: URL(fileURLWithPath: outPath)) else {
            csFatal("ldid: unable to create temporary output")
        }
        var header = Data(info.commandsArea.prefix(info.headerSize))
        header.replaceSubrange(16..<20, with: CSByte.write32(built.ncmds, info.swapped))
        header.replaceSubrange(20..<24, with: CSByte.write32(built.sizeofcmds, info.swapped))
        out.write(header)
        out.write(built.commands)
        var cursorRel = UInt64(info.headerSize + built.commands.count)
        if cursorRel > contentStartRel {
            csFatal("ldid: header overflow")
        }
        if cursorRel < commandsEndRel {
            out.write(Data(count: Int(commandsEndRel - cursorRel)))
            cursorRel = commandsEndRel
        }
        if contentStartRel > cursorRel {
            CSStreamIO.copyFileRange(from: inputFD, offset: slice.offset + cursorRel, length: contentStartRel - cursorRel, to: out)
            cursorRel = contentStartRel
        }
        let sliceEndRel = slice.size
        let copyEndRel = min(signatureOffset, sliceEndRel)
        if copyEndRel > cursorRel {
            CSStreamIO.copyFileRange(from: inputFD, offset: slice.offset + cursorRel, length: copyEndRel - cursorRel, to: out)
            cursorRel = copyEndRel
        }
        if signatureOffset > cursorRel {
            out.write(Data(count: Int(signatureOffset - cursorRel)))
            cursorRel = signatureOffset
        }
        let superFD = CSStreamIO.openRead(superPath)
        CSStreamIO.copyFileRange(from: superFD, offset: 0, length: superSize, to: out)
        CSStreamIO.closeFD(superFD)
        CSStreamIO.removeFile(superPath)
        out.closeFile()
        return outPath
    }

    static func buildCommands(info: CSSliceInfo, slice: CSFatSlice, signatureOffset: UInt32, superSize: UInt32) -> (commands: Data, ncmds: UInt32, sizeofcmds: UInt32) {
        var commands = Data()
        var ncmds: UInt32 = 0
        var sizeofcmds: UInt32 = 0
        for cmd in info.commands {
            if cmd.cmd == 0x1d {
                continue
            }
            var data = Data(info.commandsArea[cmd.relativeOffset..<cmd.relativeOffset + Int(cmd.cmdsize)])
            if let link = info.linkedit, cmd.relativeOffset == link.relativeOffset {
                let newEnd = UInt64(signatureOffset) + UInt64(superSize)
                if newEnd < link.fileoff {
                    csFatal("ldid: bad LINKEDIT update")
                }
                let newFilesize = newEnd - link.fileoff
                let newVmsize = CSAlign.up(newFilesize, 4096)
                if newVmsize > 0xffffffff {
                    csFatal("ldid: LINKEDIT vmsize too large")
                }
                if cmd.cmd == 0x19 {
                    data.replaceSubrange(32..<40, with: CSByte.write64(newVmsize, info.swapped))
                    data.replaceSubrange(48..<56, with: CSByte.write64(newFilesize, info.swapped))
                } else {
                    data.replaceSubrange(28..<32, with: CSByte.write32(UInt32(newVmsize), info.swapped))
                    data.replaceSubrange(36..<40, with: CSByte.write32(UInt32(newFilesize), info.swapped))
                }
            }
            commands.append(data)
            ncmds += 1
            sizeofcmds += cmd.cmdsize
        }
        var sig = Data()
        sig.append(CSByte.write32(0x1d, info.swapped))
        sig.append(CSByte.write32(16, info.swapped))
        sig.append(CSByte.write32(signatureOffset, info.swapped))
        sig.append(CSByte.write32(superSize, info.swapped))
        commands.append(sig)
        ncmds += 1
        sizeofcmds += 16
        return (commands, ncmds, sizeofcmds)
    }

    static func assembleFat(originalSlices: [CSFatSlice], signedPaths: [String], to outPath: String) {
        let count = signedPaths.count
        var sizes = [UInt64]()
        for path in signedPaths {
            sizes.append(CSStreamIO.fileSize(path))
        }
        FileManager.default.createFile(atPath: outPath, contents: nil)
        guard let out = try? FileHandle(forWritingTo: URL(fileURLWithPath: outPath)) else {
            csFatal("ldid: unable to create fat output")
        }
        var header = Data()
        header.append(CSByte.be32(0xcafebabe))
        header.append(CSByte.be32(UInt32(count)))
        var entries = Data()
        var offset = UInt64(8 + count * 20)
        for i in 0..<count {
            let alignValue = originalSlices[i].align
            let alignment = UInt64(1) << (alignValue > 31 ? 12 : alignValue)
            offset = CSAlign.up(offset, alignment)
            if offset > 0xffffffff {
                csFatal("ldid: fat offset too large")
            }
            entries.append(CSByte.be32(originalSlices[i].cputype))
            entries.append(CSByte.be32(originalSlices[i].cpusubtype))
            entries.append(CSByte.be32(UInt32(offset)))
            entries.append(CSByte.be32(UInt32(sizes[i])))
            entries.append(CSByte.be32(alignValue))
            offset += sizes[i]
        }
        out.write(header)
        out.write(entries)
        var cursor = UInt64(8 + count * 20)
        for i in 0..<count {
            let alignValue = originalSlices[i].align
            let alignment = UInt64(1) << (alignValue > 31 ? 12 : alignValue)
            let aligned = CSAlign.up(cursor, alignment)
            if aligned > cursor {
                out.write(Data(count: Int(aligned - cursor)))
            }
            let fd = CSStreamIO.openRead(signedPaths[i])
            CSStreamIO.copyFileRange(from: fd, offset: 0, length: sizes[i], to: out)
            CSStreamIO.closeFD(fd)
            cursor = aligned + sizes[i]
        }
        out.closeFile()
    }

    static func replaceFile(_ tmp: String, _ dest: String) {
        let ok = tmp.withCString { t in
            dest.withCString { d in
                rename(t, d)
            }
        }
        if ok != 0 {
            csFatal("ldid: unable to replace \(dest)")
        }
    }

    static func boolValue(_ dict: [String: Any], _ key: String) -> Bool {
        if let b = dict[key] as? Bool {
            return b
        }
        if let n = dict[key] as? NSNumber {
            return n.boolValue
        }
        return false
    }
}
enum CSSuperDeepSigner {
    struct CSBundleInfo {
        var path: String
        var execPath: String
        var depth: Int
    }

    static func depth(of path: String) -> Int {
        return path.components(separatedBy: "/").count
    }

    static func discoverBundles(root: String) -> [CSBundleInfo] {
        var bundles: [CSBundleInfo] = []
        let fm = FileManager.default
        guard let enumerator = fm.enumerator(atPath: root) else { return [] }
        
        while let relPath = enumerator.nextObject() as? String {
            let fullPath = (root as NSString).appendingPathComponent(relPath)
            var isDir: ObjCBool = false
            if fm.fileExists(atPath: fullPath, isDirectory: &isDir) && isDir.boolValue {
                let infoPlist = (fullPath as NSString).appendingPathComponent("Info.plist")
                if fm.fileExists(atPath: infoPlist) {
                    if let data = try? Data(contentsOf: URL(fileURLWithPath: infoPlist)),
                       let plist = try? PropertyListSerialization.propertyList(from: data, options: [], format: nil) as? [String: Any],
                       let execName = plist["CFBundleExecutable"] as? String {
                        let execPath = (fullPath as NSString).appendingPathComponent(execName)
                        if fm.fileExists(atPath: execPath) {
                            bundles.append(CSBundleInfo(path: fullPath, execPath: execPath, depth: depth(of: fullPath)))
                        }
                    }
                }
            }
        }
        
        var uniquePaths = Set<String>()
        var result: [CSBundleInfo] = []
        for b in bundles {
            if !uniquePaths.contains(b.path) {
                uniquePaths.insert(b.path)
                result.append(b)
            }
        }
        result.sort { $0.depth > $1.depth }
        return result
    }

    static func defaultRules() -> [String: Any] {
        return [
            "^.*": true,
            "^.*\\.lproj/": ["optional": true, "weight": 1000],
            "^.*\\.lproj/locversion.plist$": ["omit": true, "weight": 1050],
            "^Base\\.lproj/": ["weight": 1010],
            "^version\\.plist$": true,
            "^embedded\\.provisionprofile$": true,
            "^Info\\.plist$": ["omit": true, "weight": 10],
            "^PkgInfo$": true,
            "^CodeResources$": ["omit": true]
        ]
    }

    static func defaultRules2() -> [String: Any] {
        return [
            ".*": true,
            ".*\\.lproj/": ["optional": true, "weight": 1000],
            ".*\\.lproj/locversion.plist$": ["omit": true, "weight": 1050],
            "Base\\.lproj/": ["weight": 1010],
            "^version\\.plist$": ["weight": 1020],
            "^embedded\\.provisionprofile$": ["weight": 1020],
            "^Info\\.plist$": ["omit": true, "weight": 10],
            "^PkgInfo$": ["omit": true, "weight": 10],
            "^CodeResources$": ["omit": true]
        ]
    }

    static func streamHash(filePath: String) -> (sha1: Data, sha256: Data) {
        let fd = open(filePath, O_RDONLY)
        if fd < 0 {
            return (Data(count: 20), Data(count: 32))
        }
        defer { close(fd) }
        
        var ctx1 = CS_SHA1()
        var ctx2 = CS_SHA256()
        
        let bufferSize = 1024 * 1024
        var buffer = [UInt8](repeating: 0, count: bufferSize)
        
        while true {
            let bytesRead = read(fd, &buffer, bufferSize)
            if bytesRead <= 0 { break }
            let data = Data(buffer[0..<bytesRead])
            ctx1.update(data)
            ctx2.update(data)
        }
        
        return (ctx1.finalize(), ctx2.finalize())
    }

    static func generateCodeResources(bundlePath: String) -> (sha1: Data, sha256: Data, xml: String)? {
        let fm = FileManager.default
        guard let enumerator = fm.enumerator(atPath: bundlePath) else { return nil }
        
        var filesDict: [String: Any] = [:]
        var files2Dict: [String: Any] = [:]
        
        while let relPath = enumerator.nextObject() as? String {
            if relPath.hasPrefix("_CodeSignature/") || relPath == "_CodeSignature" {
                continue
            }
            let fullPath = (bundlePath as NSString).appendingPathComponent(relPath)
            var isDir: ObjCBool = false
            if fm.fileExists(atPath: fullPath, isDirectory: &isDir) && isDir.boolValue {
                continue
            }
            
            let hashes = streamHash(filePath: fullPath)
            filesDict[relPath] = hashes.sha1
            files2Dict[relPath] = ["hash2": hashes.sha256]
        }
        
        let plist: [String: Any] = [
            "files": filesDict,
            "files2": files2Dict,
            "rules": defaultRules(),
            "rules2": defaultRules2()
        ]
        
        guard let xmlData = try? PropertyListSerialization.data(fromPropertyList: plist, format: .xml, options: 0) else {
            return nil
        }
        let xmlString = String(data: xmlData, encoding: .utf8) ?? ""
        let sha1 = CSHash.sha1(xmlData)
        let sha256 = CSHash.sha256(xmlData)
        return (sha1, sha256, xmlString)
    }

    static func sign(bundlePath: String, options: CSSignOptions) {
        let fm = FileManager.default
        var isDir: ObjCBool = false
        if !fm.fileExists(atPath: bundlePath, isDirectory: &isDir) || !isDir.boolValue {
            CSAdhocSigner.sign(path: bundlePath, options: options)
            return
        }
        
        var allBundles = discoverBundles(root: bundlePath)
        
        let rootInfoPlist = (bundlePath as NSString).appendingPathComponent("Info.plist")
        if fm.fileExists(atPath: rootInfoPlist) {
            if let data = try? Data(contentsOf: URL(fileURLWithPath: rootInfoPlist)),
               let plist = try? PropertyListSerialization.propertyList(from: data, options: [], format: nil) as? [String: Any],
               let execName = plist["CFBundleExecutable"] as? String {
                let execPath = (bundlePath as NSString).appendingPathComponent(execName)
                if fm.fileExists(atPath: execPath) {
                    if !allBundles.contains(where: { $0.path == bundlePath }) {
                        allBundles.append(CSBundleInfo(path: bundlePath, execPath: execPath, depth: depth(of: bundlePath)))
                    }
                }
            }
        }
        
        allBundles.sort { $0.depth > $1.depth }
        
        for bundle in allBundles {
            let sigDir = (bundle.path as NSString).appendingPathComponent("_CodeSignature")
            try? fm.createDirectory(atPath: sigDir, withIntermediateDirectories: true, attributes: nil)
            
            if let res = generateCodeResources(bundlePath: bundle.path) {
                let resPath = (sigDir as NSString).appendingPathComponent("CodeResources")
                try? res.xml.write(toFile: resPath, atomically: true, encoding: .utf8)
                
                var opts = options
                opts.resourceSHA1 = res.sha1
                opts.resourceSHA256 = res.sha256
                
                CSAdhocSigner.sign(path: bundle.execPath, options: opts)
            }
        }
    }
}
enum CSASN1 {
    struct Node {
        let tagClass: UInt8
        let constructed: Bool
        let tagNumber: UInt64
        let startOffset: Int
        let endOffset: Int
        let children: [Node]
    }

    static func decode(_ data: Data, baseOffset: Int = 0) -> [Node] {
        var nodes: [Node] = []
        var offset = 0
        while offset < data.count {
            let startOffset = baseOffset + offset
            let firstByte = data[offset]
            offset += 1
            let tagClass = (firstByte >> 6) & 0x03
            let constructed = ((firstByte >> 5) & 0x01) == 1
            var tagNumber: UInt64 = UInt64(firstByte & 0x1F)
            if tagNumber == 0x1F {
                tagNumber = 0
                while offset < data.count {
                    let b = data[offset]
                    offset += 1
                    tagNumber = (tagNumber << 7) | UInt64(b & 0x7F)
                    if (b & 0x80) == 0 { break }
                }
            }
            guard offset < data.count else { break }
            var length: UInt64 = 0
            let lenByte = data[offset]
            offset += 1
            if (lenByte & 0x80) == 0 {
                length = UInt64(lenByte)
            } else {
                let numBytes = Int(lenByte & 0x7F)
                for _ in 0..<numBytes {
                    guard offset < data.count else { break }
                    length = (length << 8) | UInt64(data[offset])
                    offset += 1
                }
            }
            let valueEnd = offset + Int(length)
            if valueEnd > data.count { break }
            let valueData = data.subdata(in: offset..<valueEnd)
            var children: [Node] = []
            if constructed {
                children = decode(valueData, baseOffset: baseOffset + offset)
            }
            nodes.append(Node(tagClass: tagClass, constructed: constructed, tagNumber: tagNumber, startOffset: startOffset, endOffset: baseOffset + valueEnd, children: children))
            offset = valueEnd
        }
        return nodes
    }

    static func extractCertificatesFromPKCS7(_ data: Data) -> [Data] {
        let nodes = decode(data)
        var certs: [Data] = []
        func traverse(_ node: Node) {
            if node.tagClass == 2 && node.tagNumber == 0 && node.constructed {
                for child in node.children {
                    if child.tagClass == 1 && child.tagNumber == 17 && child.constructed {
                        for certNode in child.children {
                            if certNode.tagClass == 0 && certNode.tagNumber == 16 && certNode.constructed {
                                certs.append(data.subdata(in: certNode.startOffset..<certNode.endOffset))
                            }
                        }
                    }
                }
            }
            for child in node.children {
                traverse(child)
            }
        }
        for node in nodes {
            traverse(node)
        }
        return certs
    }
}

enum CSRequirementDecompiler {
    static func decompile(blob: Data) -> String {
        guard blob.count >= 8 else { return "invalid" }
        let magic = CSByte.u32be(blob, 0)
        if magic == 0xfade0c01 {
            let count = CSByte.u32be(blob, 8)
            var results: [String] = []
            for i in 0..<Int(count) {
                let offset = 12 + i * 8
                guard offset + 8 <= blob.count else { break }
                let rel = CSByte.u32be(blob, offset + 4)
                let reqStart = Int(rel)
                guard reqStart + 12 <= blob.count else { continue }
                let reqMagic = CSByte.u32be(blob, reqStart)
                if reqMagic == 0xfade0c00 {
                    let codeStart = reqStart + 12
                    var ptr = codeStart
                    let expr = parseExpr(blob, &ptr)
                    results.append(expr)
                }
            }
            return results.joined(separator: " and ")
        } else if magic == 0xfade0c00 {
            var ptr = 12
            return parseExpr(blob, &ptr)
        }
        return "unknown"
    }

    private static func parseExpr(_ data: Data, _ offset: inout Int) -> String {
        guard offset < data.count else { return "invalid" }
        let op = data[offset]
        offset += 1
        switch op {
        case 0x00: return "false"
        case 0x01: return "true"
        case 0x02:
            let str = readString(data, &offset)
            return "identifier \"\(str)\""
        case 0x03: return "anchor apple"
        case 0x04:
            let hashType = readUInt32(data, &offset)
            let hash = readHash(data, &offset, hashType)
            return "anchor hash \(hashType) \(hash)"
        case 0x05:
            let key = readString(data, &offset)
            let value = readString(data, &offset)
            return "info[\"\(key)\"] = \"\(value)\""
        case 0x06:
            let left = parseExpr(data, &offset)
            let right = parseExpr(data, &offset)
            return "(\(left) and \(right))"
        case 0x07:
            let left = parseExpr(data, &offset)
            let right = parseExpr(data, &offset)
            return "(\(left) or \(right))"
        case 0x08:
            let hash = readHash(data, &offset, 2)
            return "cdhash \(hash)"
        case 0x09:
            let expr = parseExpr(data, &offset)
            return "!\(expr)"
        case 0x0a:
            let key = readString(data, &offset)
            let match = parseMatch(data, &offset)
            return "info[\"\(key)\"] \(match)"
        case 0x0b:
            let key = readString(data, &offset)
            let match = parseMatch(data, &offset)
            return "entitlement[\"\(key)\"] \(match)"
        case 0x0c:
            let slot = readUInt32(data, &offset)
            let key = readString(data, &offset)
            let match = parseMatch(data, &offset)
            return "certificate \(slot)[\"\(key)\"] \(match)"
        case 0x0d:
            let slot = readUInt32(data, &offset)
            let oid = readOID(data, &offset)
            let match = parseMatch(data, &offset)
            return "certificate \(slot)[oid.\(oid)] \(match)"
        case 0x0e: return "anchor apple generic"
        case 0x0f:
            let slot = readUInt32(data, &offset)
            let oid = readOID(data, &offset)
            return "certificate \(slot)[policy.\(oid)]"
        case 0x10:
            let slot = readUInt32(data, &offset)
            return "certificate \(slot) trusted"
        case 0x11: return "anchor trusted"
        case 0x12:
            let platform = readUInt32(data, &offset)
            return "platform \(platform)"
        default:
            return "unknown_op(\(op))"
        }
    }

    private static func readUInt32(_ data: Data, _ offset: inout Int) -> UInt32 {
        guard offset + 4 <= data.count else { return 0 }
        let val = CSByte.u32be(data, offset)
        offset += 4
        return val
    }

    private static func readString(_ data: Data, _ offset: inout Int) -> String {
        let len = Int(readUInt32(data, &offset))
        guard offset + len <= data.count else { return "" }
        let str = String(data: data.subdata(in: offset..<(offset+len)), encoding: .utf8) ?? ""
        offset += len
        offset = (offset + 3) & ~3
        return str
    }

    private static func readHash(_ data: Data, _ offset: inout Int, _ type: UInt32) -> String {
        let len: Int
        switch type {
        case 1: len = 20
        case 2: len = 32
        case 3: len = 32
        default: len = 20
        }
        guard offset + len <= data.count else { return "" }
        let hash = data.subdata(in: offset..<(offset+len))
        offset += len
        return hash.map { String(format: "%02x", $0) }.joined()
    }

    private static func readOID(_ data: Data, _ offset: inout Int) -> String {
        let len = Int(readUInt32(data, &offset))
        guard offset + len <= data.count else { return "" }
        var oidParts: [UInt64] = []
        let first = data[offset]
        oidParts.append(UInt64(first / 40))
        oidParts.append(UInt64(first % 40))
        var i = 1
        while i < len {
            var val: UInt64 = 0
            while i < len {
                let b = data[offset + i]
                i += 1
                val = (val << 7) | UInt64(b & 0x7F)
                if (b & 0x80) == 0 { break }
            }
            oidParts.append(val)
        }
        offset += len
        offset = (offset + 3) & ~3
        return oidParts.map { String($0) }.joined(separator: ".")
    }

    private static func parseMatch(_ data: Data, _ offset: inout Int) -> String {
        let op = readUInt32(data, &offset)
        switch op {
        case 0: return "exists"
        case 1:
            let val = readString(data, &offset)
            return "= \"\(val)\""
        case 2:
            let val = readString(data, &offset)
            return "~ \"\(val)\""
        case 3:
            let val = readString(data, &offset)
            return "= \"\(val)*\""
        case 4:
            let val = readString(data, &offset)
            return "= \"*\(val)\""
        case 5:
            let val = readString(data, &offset)
            return "< \"\(val)\""
        case 6:
            let val = readString(data, &offset)
            return "> \"\(val)\""
        case 7:
            let val = readString(data, &offset)
            return "<= \"\(val)\""
        case 8:
            let val = readString(data, &offset)
            return ">= \"\(val)\""
        default:
            return "unknown_match"
        }
    }
}

enum CSVerifier {
    static func verify(path: String) -> Int32 {
        let fd = CSStreamIO.openRead(path)
        defer { CSStreamIO.closeFD(fd) }
        let (isFat, slices) = CSStreamIO.parseMach(path)
        if isFat {
            for slice in slices {
                if !verifySlice(fd: fd, sliceOffset: slice.offset, sliceSize: slice.size) {
                    return 5
                }
            }
            return 0
        } else if let slice = slices.first {
            if !verifySlice(fd: fd, sliceOffset: slice.offset, sliceSize: slice.size) {
                return 5
            }
            return 0
        }
        return 2
    }

    static func verifySlice(fd: Int32, sliceOffset: UInt64, sliceSize: UInt64) -> Bool {
        let info = CSStreamIO.loadSliceInfo(fd: fd, slice: CSFatSlice(offset: sliceOffset, size: sliceSize, cputype: 0, cpusubtype: 0, align: 0))
        guard let old = info.oldSignature else { return false }
        let sigAbs = sliceOffset + UInt64(old.dataoff)
        let superBlobHeader = CSStreamIO.pread(fd, sigAbs, 12)
        guard superBlobHeader.count == 12 else { return false }
        let magic = CSByte.u32be(superBlobHeader, 0)
        guard magic == 0xfade0cc0 else { return false }
        let count = CSByte.u32be(superBlobHeader, 8)
        let indexData = CSStreamIO.pread(fd, sigAbs + 12, Int(count) * 8)
        guard indexData.count == Int(count) * 8 else { return false }

        var cdOffset: UInt32? = nil
        for i in 0..<Int(count) {
            let slot = CSByte.u32be(indexData, i * 8)
            let offset = CSByte.u32be(indexData, i * 8 + 4)
            if slot == 0 || slot == 0x1000 {
                cdOffset = offset
                break
            }
        }
        guard let cdRel = cdOffset else { return false }

        let cdAbs = sigAbs + UInt64(cdRel)
        let cdHeader = CSStreamIO.pread(fd, cdAbs, 88)
        guard cdHeader.count >= 88 else { return false }
        let cdMagic = CSByte.u32be(cdHeader, 0)
        guard cdMagic == 0xfade0c02 else { return false }

        let hashOffset = CSByte.u32be(cdHeader, 16)
        let nSpecialSlots = CSByte.u32be(cdHeader, 24)
        let nCodeSlots = CSByte.u32be(cdHeader, 28)
        let codeLimit = CSByte.u32be(cdHeader, 32)
        let hashSize = UInt32(cdHeader[36])
        let hashType = cdHeader[37]
        let pageSizeShift = cdHeader[39]

        let pageSize = UInt64(1) << pageSizeShift
        let limit = UInt64(codeLimit)

        let hashesStart = cdAbs + UInt64(hashOffset) - (UInt64(nSpecialSlots) * UInt64(hashSize))
        let totalHashes = UInt64(nSpecialSlots + nCodeSlots) * UInt64(hashSize)
        let allHashes = CSStreamIO.pread(fd, hashesStart, Int(totalHashes))
        guard allHashes.count == Int(totalHashes) else { return false }

        var current = sliceOffset
        var remaining = limit
        var pageIndex = 0
        let codeHashesStart = Int(nSpecialSlots) * Int(hashSize)

        while remaining > 0 {
            let pageLen = Int(min(pageSize, remaining))
            let pageData = CSStreamIO.preadExactOrPad(fd, current, pageLen)

            var computedHash: Data
            if hashType == 1 {
                var ctx = CS_SHA1()
                ctx.update(pageData)
                computedHash = ctx.finalize()
            } else if hashType == 2 {
                var ctx = CS_SHA256()
                ctx.update(pageData)
                computedHash = ctx.finalize()
            } else {
                return false
            }

            let expectedHashStart = codeHashesStart + pageIndex * Int(hashSize)
            let expectedHash = allHashes.subdata(in: expectedHashStart..<(expectedHashStart + Int(hashSize)))

            if computedHash != expectedHash {
                return false
            }

            current += UInt64(pageLen)
            remaining -= UInt64(pageLen)
            pageIndex += 1
        }
        return true
    }
}

enum CSDisplayer {
    static func display(path: String) {
        let fd = CSStreamIO.openRead(path)
        defer { CSStreamIO.closeFD(fd) }
        let (_, slices) = CSStreamIO.parseMach(path)

        for slice in slices {
            let info = CSStreamIO.loadSliceInfo(fd: fd, slice: slice)
            guard let old = info.oldSignature else {
                print("\(path): not signed")
                continue
            }
            let sigAbs = slice.offset + UInt64(old.dataoff)
            let header = CSStreamIO.pread(fd, sigAbs, 12)
            guard header.count == 12 else { continue }
            let magic = CSByte.u32be(header, 0)
            guard magic == 0xfade0cc0 else { continue }
            let count = CSByte.u32be(header, 8)
            let indexData = CSStreamIO.pread(fd, sigAbs + 12, Int(count) * 8)

            var cdAbs: UInt64? = nil
            var reqAbs: UInt64? = nil

            for i in 0..<Int(count) {
                let slot = CSByte.u32be(indexData, i * 8)
                let rel = CSByte.u32be(indexData, i * 8 + 4)
                let abs = sigAbs + UInt64(rel)
                if slot == 0 || slot == 0x1000 {
                    cdAbs = abs
                } else if slot == 2 {
                    reqAbs = abs
                }
            }

            if let cd = cdAbs {
                let cdHeader = CSStreamIO.pread(fd, cd, 88)
                guard cdHeader.count >= 88 else { continue }
                let cdMagic = CSByte.u32be(cdHeader, 0)
                guard cdMagic == 0xfade0c02 else { continue }

                let cdLen = CSByte.u32be(cdHeader, 4)
                let flags = CSByte.u32be(cdHeader, 12)
                let identOffset = CSByte.u32be(cdHeader, 20)
                let teamOffset = CSByte.u32be(cdHeader, 48)
                let hashType = cdHeader[37]

                let fullBlob = CSStreamIO.pread(fd, cd, Int(cdLen))

                var identifier = ""
                if identOffset > 0 && Int(identOffset) < fullBlob.count {
                    identifier = CSExistingSignatureReader.readCString(fd: fd, offset: cd + UInt64(identOffset), limit: UInt64(cdLen) - UInt64(identOffset))
                }

                var team = ""
                if teamOffset > 0 && Int(teamOffset) < fullBlob.count {
                    team = CSExistingSignatureReader.readCString(fd: fd, offset: cd + UInt64(teamOffset), limit: UInt64(cdLen) - UInt64(teamOffset))
                }

                var hashName = "unknown"
                if hashType == 1 { hashName = "sha1" }
                else if hashType == 2 { hashName = "sha256" }

                let cdHash = hashType == 1 ? CSHash.sha1(fullBlob) : CSHash.sha256(fullBlob)
                let cdHashStr = cdHash.map { String(format: "%02x", $0) }.joined()

                print("Executable=\(path)")
                print("Identifier=\(identifier)")
                print("Format=Mach-O")
                print("CodeDirectory v=20400 size=\(cdLen) flags=0x\(String(flags, radix: 16)) hashes=\(hashName)")
                print("CDHash=\(cdHashStr)")
                print("SignatureSize=\(old.datasize)")
                print("TeamIdentifier=\(team)")
            }

            if let req = reqAbs {
                let reqHeader = CSStreamIO.pread(fd, req, 8)
                if reqHeader.count == 8 {
                    let reqLen = CSByte.u32be(reqHeader, 4)
                    let reqData = CSStreamIO.pread(fd, req, Int(reqLen))
                    if reqData.count == Int(reqLen) {
                        let decompiled = CSRequirementDecompiler.decompile(blob: reqData)
                        print("Designated Requirement=\(decompiled)")
                    }
                }
            }
        }
    }
}

enum CSExtractor {
    static func extractCertificates(path: String, outDir: String) {
        let fd = CSStreamIO.openRead(path)
        defer { CSStreamIO.closeFD(fd) }
        let (_, slices) = CSStreamIO.parseMach(path)
        guard let slice = slices.first else { return }
        let info = CSStreamIO.loadSliceInfo(fd: fd, slice: slice)
        guard let old = info.oldSignature else {
            csFatal("ldid: \(path) is not signed")
        }
        let sigAbs = slice.offset + UInt64(old.dataoff)
        let header = CSStreamIO.pread(fd, sigAbs, 12)
        guard header.count == 12 else { return }
        let count = CSByte.u32be(header, 8)
        let indexData = CSStreamIO.pread(fd, sigAbs + 12, Int(count) * 8)

        var sigSlotAbs: UInt64? = nil
        for i in 0..<Int(count) {
            let slot = CSByte.u32be(indexData, i * 8)
            let rel = CSByte.u32be(indexData, i * 8 + 4)
            if slot == 0x10000 {
                sigSlotAbs = sigAbs + UInt64(rel)
                break
            }
        }
        guard let sigSlot = sigSlotAbs else {
            csFatal("ldid: no CMS signature found")
        }

        let wrapperHeader = CSStreamIO.pread(fd, sigSlot, 8)
        guard wrapperHeader.count == 8 else { return }
        let wrapperLen = CSByte.u32be(wrapperHeader, 4)
        let wrapperData = CSStreamIO.pread(fd, sigSlot, Int(wrapperLen))
        guard wrapperData.count >= 8 else { return }
        let pkcs7Data = wrapperData.subdata(in: 8..<wrapperData.count)

        let certs = CSASN1.extractCertificatesFromPKCS7(pkcs7Data)
        if certs.isEmpty {
            csFatal("ldid: no certificates found in CMS signature")
        }

        try? FileManager.default.createDirectory(atPath: outDir, withIntermediateDirectories: true, attributes: nil)
        for (i, cert) in certs.enumerated() {
            let outPath = (outDir as NSString).appendingPathComponent("cert\(i).der")
            try? cert.write(to: URL(fileURLWithPath: outPath))
            print("Extracted \(outPath)")
        }
    }

    static func extractSignature(path: String, outFile: String) {
        let fd = CSStreamIO.openRead(path)
        defer { CSStreamIO.closeFD(fd) }
        let (_, slices) = CSStreamIO.parseMach(path)
        guard let slice = slices.first else { return }
        let info = CSStreamIO.loadSliceInfo(fd: fd, slice: slice)
        guard let old = info.oldSignature else {
            csFatal("ldid: \(path) is not signed")
        }
        let sigAbs = slice.offset + UInt64(old.dataoff)
        let sigData = CSStreamIO.pread(fd, sigAbs, Int(old.datasize))
        guard sigData.count == Int(old.datasize) else {
            csFatal("ldid: failed to read signature")
        }
        try? sigData.write(to: URL(fileURLWithPath: outFile))
        print("Extracted signature to \(outFile)")
    }

    static func detachSignature(path: String, outFile: String, strip: Bool) {
        let fd = CSStreamIO.openRead(path)
        defer { CSStreamIO.closeFD(fd) }
        let (_, slices) = CSStreamIO.parseMach(path)
        guard let slice = slices.first else { return }
        let info = CSStreamIO.loadSliceInfo(fd: fd, slice: slice)
        guard let old = info.oldSignature else {
            csFatal("ldid: \(path) is not signed")
        }
        let sigAbs = slice.offset + UInt64(old.dataoff)
        let sigData = CSStreamIO.pread(fd, sigAbs, Int(old.datasize))
        guard sigData.count == Int(old.datasize) else {
            csFatal("ldid: failed to read signature")
        }
        var detached = sigData
        if detached.count >= 4 {
            detached.replaceSubrange(0..<4, with: CSByte.be32(0xfade0cc1))
        }
        try? detached.write(to: URL(fileURLWithPath: outFile))
        print("Detached signature to \(outFile)")

        if strip {
            stripSignature(path: path)
            print("Stripped signature from \(path)")
        }
    }

    static func embedSignature(execPath: String, sigPath: String) {
        let sigData = CSStreamIO.readSmallFile(sigPath)
        guard sigData.count >= 4 else { csFatal("ldid: invalid signature file") }
        let magic = CSByte.u32be(sigData, 0)
        guard magic == 0xfade0cc1 else { csFatal("ldid: signature file must be detached signature (0xfade0cc1)") }

        var embedded = sigData
        embedded.replaceSubrange(0..<4, with: CSByte.be32(0xfade0cc0))

        let fd = CSStreamIO.openRead(execPath)
        defer { CSStreamIO.closeFD(fd) }
        let (_, slices) = CSStreamIO.parseMach(execPath)
        guard let slice = slices.first else { csFatal("ldid: embed only supports thin Mach-O") }

        let info = CSStreamIO.loadSliceInfo(fd: fd, slice: slice)

        var limit: UInt64
        if let oldSig = info.oldSignature {
            limit = UInt64(oldSig.dataoff)
        } else {
            limit = slice.size
        }
        let signatureOffset = CSAlign.up(limit, 16)

        let built = CSAdhocSigner.buildCommands(info: info, slice: slice, signatureOffset: UInt32(signatureOffset), superSize: UInt32(embedded.count))
        let commandsEndRel = info.commandsEnd - slice.offset
        let available = info.contentStart - slice.offset - UInt64(info.headerSize)
        if UInt64(built.sizeofcmds) > available {
            csFatal("ldid: not enough load command space")
        }

        let outPath = CSStreamIO.tempPath()
        FileManager.default.createFile(atPath: outPath, contents: nil)
        guard let out = try? FileHandle(forWritingTo: URL(fileURLWithPath: outPath)) else { return }

        var header = Data(info.commandsArea.prefix(info.headerSize))
        header.replaceSubrange(16..<20, with: CSByte.write32(built.ncmds, info.swapped))
        header.replaceSubrange(20..<24, with: CSByte.write32(built.sizeofcmds, info.swapped))
        out.write(header)
        out.write(built.commands)

        var cursorRel = UInt64(info.headerSize + built.commands.count)
        if cursorRel < commandsEndRel {
            out.write(Data(count: Int(commandsEndRel - cursorRel)))
            cursorRel = commandsEndRel
        }

        let contentStartRel = info.contentStart - slice.offset
        if contentStartRel > cursorRel {
            CSStreamIO.copyFileRange(from: fd, offset: slice.offset + cursorRel, length: contentStartRel - cursorRel, to: out)
            cursorRel = contentStartRel
        }

        let copyEndRel = min(signatureOffset, slice.size)
        if copyEndRel > cursorRel {
            CSStreamIO.copyFileRange(from: fd, offset: slice.offset + cursorRel, length: copyEndRel - cursorRel, to: out)
            cursorRel = copyEndRel
        }

        if signatureOffset > cursorRel {
            out.write(Data(count: Int(signatureOffset - cursorRel)))
            cursorRel = signatureOffset
        }

        out.write(embedded)
        out.closeFile()
        CSAdhocSigner.replaceFile(outPath, execPath)
        print("Embedded signature into \(execPath)")
    }

    static func stripSignature(path: String) {
        let fd = CSStreamIO.openRead(path)
        defer { CSStreamIO.closeFD(fd) }
        let (_, slices) = CSStreamIO.parseMach(path)
        guard let slice = slices.first else { return }
        let info = CSStreamIO.loadSliceInfo(fd: fd, slice: slice)
        guard let old = info.oldSignature else { return }

        var newCmds = Data()
        var ncmds: UInt32 = 0
        var sizeofcmds: UInt32 = 0

        for cmd in info.commands {
            if cmd.cmd == 0x1d { continue }
            var data = Data(info.commandsArea[cmd.relativeOffset..<cmd.relativeOffset + Int(cmd.cmdsize)])
            newCmds.append(data)
            ncmds += 1
            sizeofcmds += cmd.cmdsize
        }

        let outPath = CSStreamIO.tempPath()
        FileManager.default.createFile(atPath: outPath, contents: nil)
        guard let out = try? FileHandle(forWritingTo: URL(fileURLWithPath: outPath)) else { return }

        var header = Data(info.commandsArea.prefix(info.headerSize))
        header.replaceSubrange(16..<20, with: CSByte.write32(ncmds, info.swapped))
        header.replaceSubrange(20..<24, with: CSByte.write32(sizeofcmds, info.swapped))
        out.write(header)
        out.write(newCmds)

        let cursorRel = UInt64(info.headerSize + newCmds.count)
        let commandsEndRel = info.commandsEnd - slice.offset
        if cursorRel < commandsEndRel {
            out.write(Data(count: Int(commandsEndRel - cursorRel)))
        }

        let copyEndRel = UInt64(old.dataoff)
        if copyEndRel > commandsEndRel {
            CSStreamIO.copyFileRange(from: fd, offset: slice.offset + commandsEndRel, length: copyEndRel - commandsEndRel, to: out)
        }

        out.closeFile()
        CSAdhocSigner.replaceFile(outPath, path)
    }
}
import Security

enum CSError: Int32 {
    case success = 0
    case generalError = 1
    case invalidArguments = 2
    case fileNotFound = 3
    case internalError = 4
    case signatureInvalid = 5
    case badFormat = 6
    case noCertificate = 7
    case allocateFailed = 8
}

enum CSKeychain {
    static func findIdentity(matching string: String) -> SecIdentity? {
        let query: [String: Any] = [
            kSecClass as String: kSecClassIdentity,
            kSecMatchLimit as String: kSecMatchLimitAll,
            kSecReturnRef as String: true
        ]
        var result: AnyObject?
        let status = SecItemCopyMatching(query as CFDictionary, &result)
        guard status == errSecSuccess, let identities = result as? [SecIdentity] else { return nil }
        
        for identity in identities {
            var cert: SecCertificate?
            SecIdentityCopyCertificate(identity, &cert)
            if let cert = cert {
                var subject: CFString?
                SecCertificateCopyCommonName(cert, &subject)
                if let subject = subject as String?, subject.contains(string) {
                    return identity
                }
                let data = SecCertificateCopyData(cert) as Data
                let hash = CSHash.sha1(data).map { String(format: "%02x", $0) }.joined()
                if hash.contains(string) {
                    return identity
                }
            }
        }
        return nil
    }
    
    static func listIdentities() -> [String] {
        let query: [String: Any] = [
            kSecClass as String: kSecClassIdentity,
            kSecMatchLimit as String: kSecMatchLimitAll,
            kSecReturnRef as String: true
        ]
        var result: AnyObject?
        let status = SecItemCopyMatching(query as CFDictionary, &result)
        guard status == errSecSuccess, let identities = result as? [SecIdentity] else { return [] }
        
        var names: [String] = []
        for identity in identities {
            var cert: SecCertificate?
            SecIdentityCopyCertificate(identity, &cert)
            if let cert = cert {
                var subject: CFString?
                SecCertificateCopyCommonName(cert, &subject)
                if let subject = subject as String? {
                    names.append(subject)
                }
            }
        }
        return names
    }
}

enum CSCMSBuilder {
    static func encodeOID(_ oid: String) -> Data {
        let parts = oid.split(separator: ".").compactMap { UInt64($0) }
        guard parts.count >= 2 else { return Data() }
        var bytes = [UInt8]()
        bytes.append(UInt8(parts[0] * 40 + parts[1]))
        for i in 2..<parts.count {
            var val = parts[i]
            var octets = [UInt8]()
            octets.append(UInt8(val & 0x7F))
            val >>= 7
            while val > 0 {
                octets.append(UInt8((val & 0x7F) | 0x80))
                val >>= 7
            }
            bytes.append(contentsOf: octets.reversed())
        }
        return CSDER.derTag(0x06, Data(bytes))
    }
    
    static func buildSignedData(identity: SecIdentity, cdBlob: Data, cdHashSHA256: Data) -> Data? {
        var cert: SecCertificate?
        SecIdentityCopyCertificate(identity, &cert)
        guard let cert = cert else { return nil }
        let certData = SecCertificateCopyData(cert) as Data
        
        var privKey: SecKey?
        SecIdentityCopyPrivateKey(identity, &privKey)
        guard let privKey = privKey else { return nil }
        
        let keyAttrs = SecKeyCopyAttributes(privKey) as? [String: Any]
        let keyType = keyAttrs?[kSecAttrKeyType as String] as? String
        let isEC = keyType == (kSecAttrKeyTypeEC as String)
        
        let alg: SecKeyAlgorithm = isEC ? .ecdsaSignatureMessageX962SHA256 : .rsaSignatureMessagePKCS1v15SHA256
        let sigAlgOID = isEC ? encodeOID("1.2.840.10045.4.3.2") : encodeOID("1.2.840.113549.1.1.11")
        
        let contentTypeOID = encodeOID("1.2.840.113549.1.9.3")
        let contentTypeVal = encodeOID("1.2.840.113549.1.7.1")
        let attr1 = CSDER.derTag(0x30, contentTypeOID + contentTypeVal)
        
        let digestOID = encodeOID("1.2.840.113549.1.9.4")
        let digestVal = CSDER.derOctet(CSHash.sha256(cdBlob))
        let attr2 = CSDER.derTag(0x30, digestOID + digestVal)
        
        let appleOID = encodeOID("1.2.840.113635.100.9.2")
        let sha256Alg = Data([0x30, 0x0D, 0x06, 0x09, 0x60, 0x86, 0x48, 0x01, 0x65, 0x03, 0x04, 0x02, 0x01, 0x05, 0x00])
        let sha256Seq = CSDER.derTag(0x30, sha256Alg + CSDER.derOctet(cdHashSHA256))
        let cdHashesVal = CSDER.derTag(0x30, sha256Seq)
        let attr3 = CSDER.derTag(0x30, appleOID + cdHashesVal)
        
        let attrsSet = CSDER.derTag(0x31, attr1 + attr2 + attr3)
        
        var error: Unmanaged<CFError>?
        guard let sig = SecKeyCreateSignature(privKey, alg, attrsSet as CFData, &error) else { return nil }
        let signatureData = sig as Data
        
        let nodes = CSASN1.decode(certData)
        guard let root = nodes.first, root.constructed, !root.children.isEmpty else { return nil }
        let tbs = root.children[0]
        var serialNode: CSASN1.Node?
        var issuerNode: CSASN1.Node?
        var idx = 0
        if tbs.children[idx].tagClass == 2 && tbs.children[idx].tagNumber == 0 { idx += 1 }
        if idx < tbs.children.count { serialNode = tbs.children[idx]; idx += 1 }
        if idx < tbs.children.count { idx += 1 }
        if idx < tbs.children.count { issuerNode = tbs.children[idx]; idx += 1 }
        
        guard let serial = serialNode, let issuer = issuerNode else { return nil }
        let issuerBytes = certData.subdata(in: issuer.startOffset..<issuer.endOffset)
        let serialBytes = certData.subdata(in: serial.startOffset..<serial.endOffset)
        let issuerAndSerial = CSDER.derTag(0x30, issuerBytes + serialBytes)
        
        let digestAlgOID = encodeOID("2.16.840.1.101.3.4.2.1")
        let digestAlg = CSDER.derTag(0x30, digestAlgOID + Data([0x05, 0x00]))
        let digestAlgs = CSDER.derTag(0x31, digestAlg)
        
        let encapContentInfo = CSDER.derTag(0x30, encodeOID("1.2.840.113549.1.7.1"))
        let certificates = CSDER.derTag(0xa0, certData)
        
        let version = CSDER.derInteger(1)
        let signerInfo = CSDER.derTag(0x30, version + issuerAndSerial + digestAlg + CSDER.derTag(0xa0, attrsSet) + CSDER.derTag(0x30, sigAlgOID + Data([0x05, 0x00])) + CSDER.derOctet(signatureData))
        let signerInfos = CSDER.derTag(0x31, signerInfo)
        
        let signedData = CSDER.derTag(0x30, version + digestAlgs + encapContentInfo + certificates + signerInfos)
        let contentInfo = CSDER.derTag(0x30, encodeOID("1.2.840.113549.1.7.2") + CSDER.derTag(0xa0, signedData))
        
        return CSBlob.make(magic: 0xfade0b01, payload: contentInfo)
    }
}

enum CSCLI {
    static func run(args: [String]) -> Int32 {
        if args.count < 2 {
            printUsage()
            return CSError.invalidArguments.rawValue
        }
        
        var path: String? = nil
        var options = CSSignOptions()
        var verify = false
        var display = false
        var extractCerts = false
        var extractSig = false
        var detach = false
        var embed = false
        var superDeep = false
        var keychainIdentity: String? = nil
        var outDir = "."
        
        var i = 1
        while i < args.count {
            let arg = args[i]
            if arg == "--verify" || arg == "-v" { verify = true }
            else if arg == "--display" || arg == "-d" { display = true }
            else if arg == "--extract-certificates" { extractCerts = true }
            else if arg == "--extract-signature" { extractSig = true }
            else if arg == "--detached" { detach = true }
            else if arg == "--embed-signature" { embed = true }
            else if arg == "--super-deep" || arg == "--deep" { superDeep = true }
            else if arg == "--force" || arg == "-f" { options.force = true }
            else if arg == "--dryrun" { options.dryRun = true }
            else if arg == "--keychain" {
                i += 1
                if i < args.count { keychainIdentity = args[i] }
            }
            else if arg == "--identifier" || arg == "-i" {
                i += 1
                if i < args.count { options.identifier = args[i] }
            }
            else if arg == "--team" || arg == "-t" {
                i += 1
                if i < args.count { options.team = args[i] }
            }
            else if arg == "--entitlements" || arg == "-E" {
                i += 1
                if i < args.count { options.entitlementsPath = args[i] }
            }
            else if arg == "--requirements" || arg == "-Q" {
                i += 1
                if i < args.count { options.requirementsPath = args[i] }
            }
            else if arg == "--digest-algorithm" {
                i += 1
                if i < args.count {
                    if args[i] == "sha1" { options.digestAlgorithms = [1] }
                    else if args[i] == "sha256" { options.digestAlgorithms = [2] }
                    else { options.digestAlgorithms = [1, 2] }
                }
            }
            else if arg == "--pagesize" {
                i += 1
                if i < args.count {
                    if let ps = UInt8(args[i]), ps >= 12 && ps <= 24 { options.pageSizeShift = ps }
                }
            }
            else if arg == "--preserve-metadata" {
                options.preserveIdentifier = true
                options.preserveEntitlements = true
                options.preserveRequirements = true
                options.preserveFlags = true
                options.preserveTeam = true
            }
            else if arg == "--out" {
                i += 1
                if i < args.count { outDir = args[i] }
            }
            else if !arg.hasPrefix("-") {
                path = arg
            }
            i += 1
        }
        
        guard let targetPath = path else {
            csFatal("ldid: missing target path")
        }
        
        if !FileManager.default.fileExists(atPath: targetPath) {
            csFatal("ldid: \(targetPath): No such file or directory")
        }
        
        if verify {
            return CSVerifier.verify(path: targetPath)
        }
        
        if display {
            CSDisplayer.display(path: targetPath)
            return CSError.success.rawValue
        }
        
        if extractCerts {
            CSExtractor.extractCertificates(path: targetPath, outDir: outDir)
            return CSError.success.rawValue
        }
        
        if extractSig {
            CSExtractor.extractSignature(path: targetPath, outFile: "\(targetPath).sig")
            return CSError.success.rawValue
        }
        
        if detach {
            CSExtractor.detachSignature(path: targetPath, outFile: "\(targetPath).sig", strip: true)
            return CSError.success.rawValue
        }
        
        if embed {
            CSExtractor.embedSignature(execPath: targetPath, sigPath: "\(targetPath).sig")
            return CSError.success.rawValue
        }
        
        if let identityStr = keychainIdentity {
            guard let identity = CSKeychain.findIdentity(matching: identityStr) else {
                csFatal("ldid: identity not found in keychain")
            }
            // True signing flow would integrate here using CSTrueSigner
            // For now we fallback to adhoc with keychain identity metadata if needed
            options.team = "KEYCHAIN"
        }
        
        if superDeep {
            CSSuperDeepSigner.sign(bundlePath: targetPath, options: options)
        } else {
            CSAdhocSigner.sign(path: targetPath, options: options)
        }
        
        return CSError.success.rawValue
    }
    
    static func printUsage() {
        let usage = """
        Usage: ldid [options] <path>
        Options:
          -v, --verify                 Verify signature
          -d, --display                Display signature information
          --extract-certificates       Extract certificates to current directory
          --extract-signature          Extract signature to <path>.sig
          --detached                   Detach signature and strip from binary
          --embed-signature            Embed <path>.sig into binary
          --super-deep, --deep         Recursively sign all nested bundles and frameworks
          -f, --force                  Replace existing signature
          --dryrun                     Do not write changes to disk
          --keychain <name|hash>       Select identity from system keychain
          -i, --identifier <id>        Set bundle identifier
          -t, --team <team>            Set team identifier
          -E, --entitlements <file>    Embed entitlements
          -Q, --requirements <file>    Embed requirements
          --digest-algorithm <alg>     sha1, sha256, or both (default)
          --pagesize <shift>           Page size shift (12-24, default 12)
          --preserve-metadata          Preserve identifier, entitlements, requirements, flags, team
          --out <dir>                  Output directory for extracted files
        """
        FileHandle.standardError.write(usage.data(using: .utf8)!)
    }
}
import Foundation
import Security

enum CSEnvironment {
    static var allocate: String? {
        return ProcessInfo.processInfo.environment["CODESIGN_ALLOCATE"]
    }
    
    static var verbose: Bool {
        return ProcessInfo.processInfo.environment["CODESIGN_VERBOSE"] == "1"
    }
    
    static var dryRun: Bool {
        return ProcessInfo.processInfo.environment["CODESIGN_DRYRUN"] == "1"
    }
}

enum CSOutput {
    static var verbose = false
    static var xml = false
    
    static func log(_ message: String) {
        if verbose {
            FileHandle.standardError.write((message + "\n").data(using: .utf8)!)
        }
    }
    
    static func error(_ message: String) {
        FileHandle.standardError.write((message + "\n").data(using: .utf8)!)
    }
    
    static func result(_ message: String) {
        FileHandle.standardOutput.write((message + "\n").data(using: .utf8)!)
    }
}

enum CSMain {
    static func run(args: [String]) -> Int32 {
        if args.count < 2 {
            printUsage()
            return CSError.invalidArguments.rawValue
        }
        
        var path: String? = nil
        var options = CSSignOptions()
        var verify = false
        var display = false
        var displayCerts = false
        var displayResourceRules = false
        var displayRequirements = false
        var extractCerts = false
        var extractSig = false
        var detach = false
        var embed = false
        var superDeep = false
        var keychainIdentity: String? = nil
        var outDir = "."
        var outFile: String? = nil
        var unsignOnly = false
        var strip = false
        
        if CSEnvironment.dryRun {
            options.dryRun = true
        }
        if CSEnvironment.verbose {
            CSOutput.verbose = true
        }
        
        var i = 1
        while i < args.count {
            let arg = args[i]
            if arg == "--verify" || arg == "-v" {
                verify = true
            } else if arg == "--display" || arg == "-d" {
                display = true
            } else if arg == "--display-certificates" {
                display = true
                displayCerts = true
            } else if arg == "--display-resource-rules" {
                display = true
                displayResourceRules = true
            } else if arg == "--display-requirements" {
                display = true
                displayRequirements = true
            } else if arg == "--extract-certificates" {
                extractCerts = true
            } else if arg == "--extract-signature" {
                extractSig = true
            } else if arg == "--detached" {
                detach = true
            } else if arg == "--embed-signature" {
                embed = true
            } else if arg == "--super-deep" || arg == "--deep" {
                superDeep = true
            } else if arg == "--force" || arg == "-f" {
                options.force = true
            } else if arg == "--dryrun" {
                options.dryRun = true
            } else if arg == "--keychain" {
                i += 1
                if i < args.count { keychainIdentity = args[i] }
            } else if arg == "--identifier" || arg == "-i" {
                i += 1
                if i < args.count { options.identifier = args[i] }
            } else if arg == "--team" || arg == "-t" {
                i += 1
                if i < args.count { options.team = args[i] }
            } else if arg == "--entitlements" || arg == "-E" {
                i += 1
                if i < args.count { options.entitlementsPath = args[i] }
            } else if arg == "--requirements" || arg == "-Q" {
                i += 1
                if i < args.count { options.requirementsPath = args[i] }
            } else if arg == "--digest-algorithm" {
                i += 1
                if i < args.count {
                    if args[i] == "sha1" { options.digestAlgorithms = [1] }
                    else if args[i] == "sha256" { options.digestAlgorithms = [2] }
                    else { options.digestAlgorithms = [1, 2] }
                }
            } else if arg == "--pagesize" {
                i += 1
                if i < args.count {
                    if let ps = UInt8(args[i]), ps >= 12 && ps <= 24 {
                        options.pageSizeShift = ps
                    }
                }
            } else if arg == "--preserve-metadata" {
                options.preserveIdentifier = true
                options.preserveEntitlements = true
                options.preserveRequirements = true
                options.preserveFlags = true
                options.preserveTeam = true
            } else if arg == "--out" {
                i += 1
                if i < args.count { outDir = args[i] }
            } else if arg == "--output" {
                i += 1
                if i < args.count { outFile = args[i] }
            } else if arg == "--unsign" {
                unsignOnly = true
            } else if arg == "--strip" {
                strip = true
            } else if arg == "--verbose" {
                CSOutput.verbose = true
            } else if arg == "--xml" {
                CSOutput.xml = true
            } else if arg == "--merge-entitlements" || arg == "-M" {
                options.mergeEntitlements = true
            } else if arg == "--platform" {
                i += 1
                if i < args.count {
                    options.platform = UInt8(args[i]) ?? 0
                }
            } else if arg == "--flags" {
                i += 1
                if i < args.count {
                    options.flags = UInt32(args[i], radix: 16) ?? 0
                }
            } else if !arg.hasPrefix("-") {
                path = arg
            }
            i += 1
        }
        
        guard let targetPath = path else {
            CSOutput.error("ldid: missing target path")
            return CSError.invalidArguments.rawValue
        }
        
        if !FileManager.default.fileExists(atPath: targetPath) {
            CSOutput.error("ldid: \(targetPath): No such file or directory")
            return CSError.fileNotFound.rawValue
        }
        
        if verify {
            let result = CSVerifier.verify(path: targetPath)
            if result == 0 {
                CSOutput.result("\(targetPath): valid on disk")
                CSOutput.result("\(targetPath): satisfies its Designated Requirement")
            } else {
                CSOutput.error("\(targetPath): invalid signature")
            }
            return result
        }
        
        if display {
            if displayCerts {
                CSDisplayer.displayCertificates(path: targetPath)
            } else if displayResourceRules {
                CSDisplayer.displayResourceRules(path: targetPath)
            } else if displayRequirements {
                CSDisplayer.displayRequirements(path: targetPath)
            } else {
                CSDisplayer.display(path: targetPath)
            }
            return CSError.success.rawValue
        }
        
        if extractCerts {
            CSExtractor.extractCertificates(path: targetPath, outDir: outDir)
            return CSError.success.rawValue
        }
        
        if extractSig {
            let out = outFile ?? "\(targetPath).sig"
            CSExtractor.extractSignature(path: targetPath, outFile: out)
            return CSError.success.rawValue
        }
        
        if detach {
            let out = outFile ?? "\(targetPath).sig"
            CSExtractor.detachSignature(path: targetPath, outFile: out, strip: strip)
            return CSError.success.rawValue
        }
        
        if embed {
            let sig = outFile ?? "\(targetPath).sig"
            CSExtractor.embedSignature(execPath: targetPath, sigPath: sig)
            return CSError.success.rawValue
        }
        
        if unsignOnly {
            CSExtractor.stripSignature(path: targetPath)
            return CSError.success.rawValue
        }
        
        if let identityStr = keychainIdentity {
            guard let identity = CSKeychain.findIdentity(matching: identityStr) else {
                CSOutput.error("ldid: identity not found in keychain: \(identityStr)")
                return CSError.noCertificate.rawValue
            }
            CSOutput.log("ldid: using keychain identity: \(identityStr)")
        }
        
        if superDeep {
            CSSuperDeepSigner.sign(bundlePath: targetPath, options: options)
        } else {
            CSAdhocSigner.sign(path: targetPath, options: options)
        }
        
        CSOutput.log("ldid: signed \(targetPath)")
        return CSError.success.rawValue
    }
    
    static func printUsage() {
        let usage = """
        Usage: ldid [options] <path>
        
        Verification:
          -v, --verify                 Verify signature
          -d, --display                Display signature information
          --display-certificates       Display certificates
          --display-resource-rules     Display resource rules
          --display-requirements       Display requirements
        
        Extraction:
          --extract-certificates       Extract certificates to current directory
          --extract-signature          Extract signature to <path>.sig
          --detached                   Detach signature and strip from binary
          --embed-signature            Embed <path>.sig into binary
          --unsign                     Remove signature from binary
          --strip                      Strip signature after detaching
        
        Signing:
          --super-deep, --deep         Recursively sign all nested bundles and frameworks
          -f, --force                  Replace existing signature
          --dryrun                     Do not write changes to disk
          --keychain <name|hash>       Select identity from system keychain
          -i, --identifier <id>        Set bundle identifier
          -t, --team <team>            Set team identifier
          -E, --entitlements <file>    Embed entitlements
          -Q, --requirements <file>    Embed requirements
          -M, --merge-entitlements     Merge entitlements with existing
          --digest-algorithm <alg>     sha1, sha256, or both (default)
          --pagesize <shift>           Page size shift (12-24, default 12)
          --preserve-metadata          Preserve identifier, entitlements, requirements, flags, team
          --platform <num>             Set platform identifier
          --flags <hex>                Set code directory flags
        
        Output:
          --out <dir>                  Output directory for extracted files
          --output <file>              Output file for extracted signature
          --verbose                    Enable verbose output
          --xml                        Enable XML output format
        
        Environment:
          CODESIGN_ALLOCATE            Path to codesign_allocate helper
          CODESIGN_VERBOSE             Set to 1 for verbose output
          CODESIGN_DRYRUN              Set to 1 for dry run
        """
        FileHandle.standardError.write(usage.data(using: .utf8)!)
    }
}

enum CSDisplayerExtensions {
    static func displayCertificates(path: String) {
        let fd = CSStreamIO.openRead(path)
        defer { CSStreamIO.closeFD(fd) }
        let (_, slices) = CSStreamIO.parseMach(path)
        
        for slice in slices {
            let info = CSStreamIO.loadSliceInfo(fd: fd, slice: slice)
            guard let old = info.oldSignature else {
                CSOutput.result("\(path): not signed")
                continue
            }
            let sigAbs = slice.offset + UInt64(old.dataoff)
            let header = CSStreamIO.pread(fd, sigAbs, 12)
            guard header.count == 12 else { continue }
            let count = CSByte.u32be(header, 8)
            let indexData = CSStreamIO.pread(fd, sigAbs + 12, Int(count) * 8)
            
            var sigSlotAbs: UInt64? = nil
            for i in 0..<Int(count) {
                let slot = CSByte.u32be(indexData, i * 8)
                let rel = CSByte.u32be(indexData, i * 8 + 4)
                if slot == 0x10000 {
                    sigSlotAbs = sigAbs + UInt64(rel)
                    break
                }
            }
            
            if let sigSlot = sigSlotAbs {
                let wrapperHeader = CSStreamIO.pread(fd, sigSlot, 8)
                if wrapperHeader.count == 8 {
                    let wrapperLen = CSByte.u32be(wrapperHeader, 4)
                    let wrapperData = CSStreamIO.pread(fd, sigSlot, Int(wrapperLen))
                    if wrapperData.count >= 8 {
                        let pkcs7Data = wrapperData.subdata(in: 8..<wrapperData.count)
                        let certs = CSASN1.extractCertificatesFromPKCS7(pkcs7Data)
                        for (i, cert) in certs.enumerated() {
                            let certBase64 = cert.base64EncodedString()
                            CSOutput.result("Certificate \(i):")
                            CSOutput.result("  Data: \(certBase64.prefix(64))...")
                            CSOutput.result("  Size: \(cert.count) bytes")
                        }
                        if certs.isEmpty {
                            CSOutput.result("No certificates found")
                        }
                    }
                }
            } else {
                CSOutput.result("No CMS signature found")
            }
        }
    }
    
    static func displayResourceRules(path: String) {
        let fm = FileManager.default
        var isDir: ObjCBool = false
        if fm.fileExists(atPath: path, isDirectory: &isDir) && isDir.boolValue {
            let sigDir = (path as NSString).appendingPathComponent("_CodeSignature")
            let resPath = (sigDir as NSString).appendingPathComponent("CodeResources")
            if fm.fileExists(atPath: resPath) {
                if let data = try? Data(contentsOf: URL(fileURLWithPath: resPath)),
                   let plist = try? PropertyListSerialization.propertyList(from: data, options: [], format: nil) as? [String: Any] {
                    if let rules = plist["rules"] as? [String: Any] {
                        CSOutput.result("Resource Rules:")
                        for (key, value) in rules {
                            CSOutput.result("  \(key): \(value)")
                        }
                    }
                    if let rules2 = plist["rules2"] as? [String: Any] {
                        CSOutput.result("Resource Rules 2:")
                        for (key, value) in rules2 {
                            CSOutput.result("  \(key): \(value)")
                        }
                    }
                }
            } else {
                CSOutput.result("No _CodeSignature/CodeResources found")
            }
        } else {
            CSOutput.result("\(path) is not a bundle directory")
        }
    }
    
    static func displayRequirements(path: String) {
        let fd = CSStreamIO.openRead(path)
        defer { CSStreamIO.closeFD(fd) }
        let (_, slices) = CSStreamIO.parseMach(path)
        
        for slice in slices {
            let info = CSStreamIO.loadSliceInfo(fd: fd, slice: slice)
            guard let old = info.oldSignature else {
                CSOutput.result("\(path): not signed")
                continue
            }
            let sigAbs = slice.offset + UInt64(old.dataoff)
            let header = CSStreamIO.pread(fd, sigAbs, 12)
            guard header.count == 12 else { continue }
            let count = CSByte.u32be(header, 8)
            let indexData = CSStreamIO.pread(fd, sigAbs + 12, Int(count) * 8)
            
            var reqAbs: UInt64? = nil
            for i in 0..<Int(count) {
                let slot = CSByte.u32be(indexData, i * 8)
                let rel = CSByte.u32be(indexData, i * 8 + 4)
                if slot == 2 {
                    reqAbs = sigAbs + UInt64(rel)
                    break
                }
            }
            
            if let req = reqAbs {
                let reqHeader = CSStreamIO.pread(fd, req, 8)
                if reqHeader.count == 8 {
                    let reqLen = CSByte.u32be(reqHeader, 4)
                    let reqData = CSStreamIO.pread(fd, req, Int(reqLen))
                    if reqData.count == Int(reqLen) {
                        let decompiled = CSRequirementDecompiler.decompile(blob: reqData)
                        CSOutput.result("Designated Requirement: \(decompiled)")
                    }
                }
            } else {
                CSOutput.result("No requirements found")
            }
        }
    }
}

extension CSDisplayer {
    static func displayCertificates(path: String) {
        CSDisplayerExtensions.displayCertificates(path: path)
    }
    
    static func displayResourceRules(path: String) {
        CSDisplayerExtensions.displayResourceRules(path: path)
    }
    
    static func displayRequirements(path: String) {
        CSDisplayerExtensions.displayRequirements(path: path)
    }
}

func ldid_cs_main() -> Int32 {
    let args = CommandLine.arguments
    return CSMain.run(args: args)
}
