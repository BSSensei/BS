use crate::error::Result;
use std::fs;
use std::os::unix::fs::PermissionsExt;
use std::path::{Path, PathBuf};

pub struct FileInfo {
    pub path: PathBuf,
    pub display_name: String,
    pub is_dir: bool,
    pub mode: u32,
}

pub fn list_dir(path: &Path) -> Result<Vec<FileInfo>> {
    let mut files = Vec::new();
    for entry in fs::read_dir(path)? {
        let entry = entry?;
        let meta = entry.metadata()?;
        let is_dir = meta.is_dir();
        let name = entry.file_name().to_string_lossy().to_string();

        let display_name = if is_dir {
            format!("📁 {}", name)
        } else {
            name
        };

        files.push(FileInfo {
            path: entry.path(),
            display_name,
            is_dir,
            mode: meta.permissions().mode(),
        });
    }
    files.sort_by(|a, b| {
        if a.is_dir == b.is_dir {
            a.display_name.cmp(&b.display_name)
        } else if a.is_dir {
            std::cmp::Ordering::Less
        } else {
            std::cmp::Ordering::Greater
        }
    });
    Ok(files)
}

pub fn change_permissions(path: &Path, mode: u32) -> Result<()> {
    let mut perms = fs::metadata(path)?.permissions();
    perms.set_mode(mode);
    fs::set_permissions(path, perms)?;
    Ok(())
}

pub fn copy_file(src: &Path, dst: &Path) -> Result<()> {
    fs::copy(src, dst)?;
    Ok(())
}

pub fn move_file(src: &Path, dst: &Path) -> Result<()> {
    fs::rename(src, dst)?;
    Ok(())
}

pub fn delete_file(path: &Path) -> Result<()> {
    if path.is_dir() {
        fs::remove_dir_all(path)?;
    } else {
        fs::remove_file(path)?;
    }
    Ok(())
}
