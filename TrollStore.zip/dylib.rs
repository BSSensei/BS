use crate::error::{AppError, Result};
use goblin::mach::Mach;
use std::fs;
use std::path::Path;

pub fn inject_dylib(app_binary: &Path, dylib_path: &str) -> Result<()> {
    let data = fs::read(app_binary)?;
    let mach = Mach::parse(&data).map_err(|_| AppError::MachOError)?;

    match mach {
        Mach::Binary(macho) => {
            if !macho.is_object_file() {
                return Err(AppError::MachOError);
            }
            let mut found = false;
            for cmd in macho.load_commands.iter() {
                if let goblin::mach::load_command::CommandVariant::LoadDylib(ld) = &cmd.command {
                    let name_offset = ld.dylib.name as usize;
                    let name = std::str::from_utf8(&data[name_offset..]).unwrap_or("");
                    if name.contains(dylib_path) {
                        found = true;
                        break;
                    }
                }
            }
            if !found {}
            Ok(())
        }
        Mach::Fat(_) => Err(AppError::MachOError),
    }
}

pub fn list_dylibs(app_binary: &Path) -> Result<Vec<String>> {
    let data = fs::read(app_binary)?;
    let mach = Mach::parse(&data).map_err(|_| AppError::MachOError)?;
    let mut libs = Vec::new();

    if let Mach::Binary(macho) = mach {
        for cmd in macho.load_commands.iter() {
            if let goblin::mach::load_command::CommandVariant::LoadDylib(ld) = &cmd.command {
                let name_offset = ld.dylib.name as usize;
                let name = std::str::from_utf8(&data[name_offset..])
                    .unwrap_or("")
                    .to_string();
                libs.push(name);
            }
        }
    }
    Ok(libs)
}

pub fn remove_dylib(_app_binary: &Path, _dylib_path: &str) -> Result<()> {
    Ok(())
}

pub fn set_load_mode(_app_binary: &Path, _weak: bool) -> Result<()> {
    Ok(())
}
