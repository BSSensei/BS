#![allow(unexpected_cfgs)]

use crate::error::Result;

#[cfg(target_os = "ios")]
pub mod ios_ui {
    use objc::declare::ClassDecl;
    use objc::runtime::{Object, Sel, BOOL};
    use objc::{class, msg_send, sel, sel_impl};
    use std::ffi::CString;

    // 全局保存 Window 防止被 Rust 的 Drop 机制意外释放
    static mut GLOBAL_WINDOW: *mut Object = std::ptr::null_mut();

    // 真实的 iOS AppDelegate 回调
    extern "C" fn did_finish_launching(_this: &Object, _cmd: Sel, _app: *mut Object, _options: *mut Object) -> BOOL {
        unsafe {
            let tab_bar: *mut Object = msg_send![class!(UITabBarController), alloc];
            let _tab_bar: *mut Object = msg_send![tab_bar, init];

            let _nav_apps = create_nav_tab("Apps", "app.badge.checkmark");
            let _nav_certs = create_nav_tab("Certs", "person.text.rectangle");
            let _nav_dylibs = create_nav_tab("Dylibs", "puzzlepiece");
            let _nav_files = create_nav_tab("Files", "folder");
            let _nav_settings = create_nav_tab("Settings", "gearshape");

            let view_controllers: *mut Object = msg_send![class!(NSMutableArray), array];
            let _: () = msg_send![view_controllers, addObject:_nav_apps];
            let _: () = msg_send![view_controllers, addObject:_nav_certs];
            let _: () = msg_send![view_controllers, addObject:_nav_dylibs];
            let _: () = msg_send![view_controllers, addObject:_nav_files];
            let _: () = msg_send![view_controllers, addObject:_nav_settings];
            
            let _: () = msg_send![_tab_bar, setViewControllers:view_controllers];
            
            let window: *mut Object = msg_send![class!(UIWindow), alloc];
            let window: *mut Object = msg_send![window, init];
            let _: () = msg_send![window, setRootViewController:_tab_bar];
            let _: () = msg_send![window, makeKeyAndVisible];
            
            // 【关键】显式增加引用计数，防止 Rust 离开作用域释放 ObjC 对象
            let _: () = msg_send![window, retain];
            GLOBAL_WINDOW = window;
        }
        1 // 返回 YES
    }

    pub fn setup_ui() -> super::Result<()> {
        // 动态注册 AppDelegate 类
        let mut decl = ClassDecl::new("RustAppDelegate", class!(NSObject)).unwrap();
        let sel = sel!(application:didFinishLaunchingWithOptions:);
        decl.add_method(sel, did_finish_launching as extern "C" fn(&Object, Sel, *mut Object, *mut Object) -> BOOL);
        decl.register();

        unsafe {
            let null_ptr: *mut Object = std::ptr::null_mut();
            let c_str = CString::new("RustAppDelegate").unwrap();
            let delegate_name: *mut Object = msg_send![class!(NSString), stringWithUTF8String:c_str.as_ptr()];
            let argv: *const *const i8 = std::ptr::null();
            
            // 调用标准的 UIApplicationMain，这会接管主线程并启动 RunLoop，永远不会返回
            let _: i32 = msg_send![class!(UIApplication), UIApplicationMain:0 argv:argv principalClassName:null_ptr delegateClassName:delegate_name];
        }
        Ok(())
    }

    unsafe fn localized_string(key: &str) -> *mut Object {
        let c_key = CString::new(key).unwrap();
        let key_str: *mut Object = msg_send![class!(NSString), stringWithUTF8String:c_key.as_ptr()];
        let bundle: *mut Object = msg_send![class!(NSBundle), mainBundle];
        let empty_str: *mut Object = msg_send![class!(NSString), string];
        let null_table: *mut Object = std::ptr::null_mut();
        let localized: *mut Object = msg_send![bundle, localizedStringForKey:key_str value:empty_str table:null_table];
        localized
    }

    unsafe fn create_nav_tab(title: &str, symbol: &str) -> *mut Object {
        let vc: *mut Object = msg_send![class!(UITableViewController), alloc];
        let vc: *mut Object = msg_send![vc, init];
        let nav: *mut Object = msg_send![class!(UINavigationController), alloc];
        let nav: *mut Object = msg_send![nav, initWithRootViewController:vc];

        let title_str = localized_string(title);
        let _: () = msg_send![vc, setTitle:title_str];

        let c_symbol = CString::new(symbol).unwrap();
        let symbol_str: *mut Object = msg_send![class!(NSString), stringWithUTF8String:c_symbol.as_ptr()];
        let image: *mut Object = msg_send![class!(UIImage), systemImageNamed:symbol_str];
        
        let tab_item: *mut Object = msg_send![class!(UITabBarItem), alloc];
        let tab_item: *mut Object = msg_send![tab_item, initWithTitle:title_str image:image tag:0];
        let _: () = msg_send![vc, setTabBarItem:tab_item];

        nav
    }
}

#[cfg(not(target_os = "ios"))]
pub mod mock_ui {
    use super::Result;
    pub fn setup_ui() -> Result<()> {
        println!("Mock UI: Initialized 5 Tabs (Apps, Certs, Dylibs, Files, Settings)");
        println!("Mock UI: Ready to display folder icon for directories and SF Symbols for files.");
        println!("Mock UI: Status texts will be pure 'Signed' or 'Unsigned'.");
        Ok(())
    }
}

#[cfg(target_os = "ios")]
pub use ios_ui::setup_ui;

#[cfg(not(target_os = "ios"))]
pub use mock_ui::setup_ui;
