use crate::error::Result;

#[cfg(target_os = "ios")]
pub mod ios_ui {
    use objc::runtime::Object;
    use objc::{class, msg_send};
    use std::ffi::CString;
    use std::ptr;

    pub fn setup_ui() -> super::Result<()> {
        unsafe {
            let _app: *mut Object = msg_send![class!(UIApplication), sharedApplication];
            let tab_bar: *mut Object = msg_send![class!(UITabBarController), alloc];
            let _tab_bar: *mut Object = msg_send![tab_bar, init];

            let _nav_apps = create_nav_tab("Apps", "app.badge.checkmark");
            let _nav_certs = create_nav_tab("Certs", "person.text.rectangle");
            let _nav_dylibs = create_nav_tab("Dylibs", "puzzlepiece");
            let _nav_files = create_nav_tab("Files", "folder");
            let _nav_settings = create_nav_tab("Settings", "gearshape");

            // 修复：可变参数方法必须以 null 指针 (nil) 结尾
            let null_ptr: *mut Object = ptr::null_mut();
            let _view_controllers: *mut Object = msg_send![
                class!(NSArray),
                arrayWithObjects:_nav_apps, _nav_certs, _nav_dylibs, _nav_files, _nav_settings, null_ptr
            ];
            
            let _: () = msg_send![_tab_bar, setViewControllers:_view_controllers];
            
            // 创建主窗口并显示
            let screen: *mut Object = msg_send![class!(UIScreen), mainScreen];
            let bounds: objc::runtime::Sel = objc::sel!(bounds);
            let bounds_val: objc::foundation::CGRect = msg_send![screen, bounds];
            
            let window: *mut Object = msg_send![class!(UIWindow), alloc];
            let window: *mut Object = msg_send![window, initWithFrame:bounds_val];
            let _: () = msg_send![window, setRootViewController:_tab_bar];
            let _: () = msg_send![window, makeKeyAndVisible];
        }
        Ok(())
    }

    unsafe fn create_nav_tab(title: &str, symbol: &str) -> *mut Object {
        let vc: *mut Object = msg_send![class!(UITableViewController), alloc];
        let vc: *mut Object = msg_send![vc, init];
        let nav: *mut Object = msg_send![class!(UINavigationController), alloc];
        let nav: *mut Object = msg_send![nav, initWithRootViewController:vc];

        // 修复：使用 CString 确保字符串以 \0 结尾，防止 C API 越界崩溃
        let c_title = CString::new(title).unwrap();
        let title_str: *mut Object = msg_send![class!(NSString), stringWithUTF8String:c_title.as_ptr()];
        let _: () = msg_send![vc, setTitle:title_str];

        let c_symbol = CString::new(symbol).unwrap();
        let symbol_str: *mut Object = msg_send![class!(NSString), stringWithUTF8String:c_symbol.as_ptr()];
        let image: *mut Object = msg_send![class!(UIImage), systemImageNamed:symbol_str];
        
        let tab_item: *mut Object = msg_send![class!(UITabBarItem), alloc];
        let tab_item: *mut Object = msg_send![tab_item, initWithTitle:title_str image:image tag:0];
        let _: () = msg_send![vc, setTabBarItem:tab_item];

        nav
    }
}

#[cfg(not(target_os = "ios"))]
pub mod mock_ui {
    use super::Result;
    pub fn setup_ui() -> Result<()> {
        println!("Mock UI: Initialized 5 Tabs (Apps, Certs, Dylibs, Files, Settings)");
        println!("Mock UI: Ready to display 📁 for folders and SF Symbols for files.");
        println!("Mock UI: Status texts will be pure 'Signed' or 'Unsigned'.");
        Ok(())
    }
}

#[cfg(target_os = "ios")]
pub use ios_ui::setup_ui;

#[cfg(not(target_os = "ios"))]
pub use mock_ui::setup_ui;
