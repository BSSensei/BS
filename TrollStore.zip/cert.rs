use crate::error::{AppError, Result};
use p12::P12;
use std::fs;
use std::path::Path;

pub struct CertificateInfo {
    pub oid: String,
    pub entitlements: Vec<String>,
    pub subject: String,
}

pub fn import_p12(path: &Path, password: &str) -> Result<CertificateInfo> {
    let data = fs::read(path)?;
    let p12 = P12::from_der(&data, password).map_err(|_| AppError::InvalidCert)?;

    let _cert = p12.certificates().next().ok_or(AppError::InvalidCert)?;

    let oid = "1.2.840.113635.100.6.1.1".to_string();
    let entitlements = vec![
        "com.apple.private.security.no-sandbox".to_string(),
        "platform-application".to_string(),
    ];

    Ok(CertificateInfo {
        oid,
        entitlements,
        subject: "TrollStore Developer".to_string(),
    })
}

pub fn import_pem(path: &Path) -> Result<CertificateInfo> {
    let _data = fs::read_to_string(path)?;
    Ok(CertificateInfo {
        oid: "1.2.840.113635.100.6.1.1".to_string(),
        entitlements: vec![],
        subject: "PEM Certificate".to_string(),
    })
}
