use thiserror::Error;

#[derive(Error, Debug)]
pub enum AppError {
    #[error("IO error: {0}")]
    Io(#[from] std::io::Error),
    #[error("Plist error: {0}")]
    Plist(#[from] plist::Error),
    #[error("Zip error: {0}")]
    Zip(#[from] zip::result::ZipError),
    #[error("Ldid execution failed")]
    LdidFailed,
    #[error("Helper execution failed")]
    HelperFailed,
    #[error("Invalid certificate")]
    InvalidCert,
    #[error("UI error: {0}")]
    Ui(String),
    #[error("Mach-O parse error")]
    MachOError,
}

pub type Result<T> = std::result::Result<T, AppError>;
