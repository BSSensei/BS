use crate::error::Result;
use plist::Value;
use std::path::Path;

pub fn load_plist(path: &Path) -> Result<Value> {
    let value = Value::from_file(path)?;
    Ok(value)
}

pub fn save_plist(path: &Path, value: &Value) -> Result<()> {
    value.to_file_xml(path)?;
    Ok(())
}

pub fn get_keys(value: &Value) -> Vec<String> {
    if let Some(dict) = value.as_dictionary() {
        dict.keys().cloned().collect()
    } else {
        vec![]
    }
}
