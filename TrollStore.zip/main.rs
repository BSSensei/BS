mod error;
mod core;
mod ui;

fn main() {
    if let Err(e) = ui::setup_ui() {
        eprintln!("Failed to initialize UI: {}", e);
    }
    
    #[cfg(not(target_os = "ios"))]
    {
        println!("=== Starting macOS Comprehensive Logic Tests ===");
        run_macos_tests();
        println!("=== All macOS Tests Completed Successfully ===");
    }
}

#[cfg(not(target_os = "ios"))]
fn run_macos_tests() {
    test_fs();
    test_plist();
    test_ipa_structure();
    test_dylib();
    test_cert();
}

#[cfg(not(target_os = "ios"))]
fn test_fs() {
    println!("[Test] File System Operations");
    use crate::core::fs;
    use std::fs;
    let dir = tempfile::tempdir().unwrap();
    let f1 = dir.path().join("test.txt");
    fs::write(&f1, "data").unwrap();
    let files = fs::list_dir(dir.path()).unwrap();
    assert_eq!(files.len(), 1);
    fs::change_permissions(&f1, 0o755).unwrap();
    fs::delete_file(&f1).unwrap();
    println!("  -> FS tests passed.");
}

#[cfg(not(target_os = "ios"))]
fn test_plist() {
    println!("[Test] Plist Parsing");
    use crate::core::plist;
    let dir = tempfile::tempdir().unwrap();
    let p = dir.path().join("test.plist");
    let mut dict = plist::Dictionary::new();
    dict.insert("Key1".to_string(), plist::Value::String("Val1".to_string()));
    let val = plist::Value::Dictionary(dict);
    plist::save_plist(&p, &val).unwrap();
    let loaded = plist::load_plist(&p).unwrap();
    let keys = plist::get_keys(&loaded);
    assert_eq!(keys, vec!["Key1"]);
    println!("  -> Plist tests passed.");
}

#[cfg(not(target_os = "ios"))]
fn test_ipa_structure() {
    println!("[Test] IPA Structure Extraction");
    use std::fs::File;
    use std::io::Write;
    use zip::ZipWriter;
    use zip::write::SimpleFileOptions;
    use zip::CompressionMethod;
    
    let dir = tempfile::tempdir().unwrap();
    let zip_path = dir.path().join("test.ipa");
    let file = File::create(&zip_path).unwrap();
    let mut zip = ZipWriter::new(file);
    let options = SimpleFileOptions::default().compression_method(CompressionMethod::Stored);
    
    zip.start_file("Payload/Test.app/Info.plist", options).unwrap();
    zip.write_all(b"<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<!DOCTYPE plist PUBLIC \"-//Apple//DTD PLIST 1.0//EN\" \"http://www.apple.com/DTDs/PropertyList-1.0.dtd\">\n<plist version=\"1.0\"><dict><key>CFBundleExecutable</key><string>Test</string></dict></plist>").unwrap();
    
    zip.start_file("Payload/Test.app/Test", options).unwrap();
    zip.write_all(b"binary").unwrap();
    zip.finish().unwrap();
    
    let extract_dir = dir.path().join("extracted");
    std::fs::create_dir(&extract_dir).unwrap();
    let archive = zip::ZipArchive::new(File::open(&zip_path).unwrap()).unwrap();
    archive.extract(&extract_dir).unwrap();
    
    let app_dir = extract_dir.join("Payload/Test.app");
    assert!(app_dir.exists());
    let info = app_dir.join("Info.plist");
    assert!(info.exists());
    println!("  -> IPA structure tests passed.");
}

#[cfg(not(target_os = "ios"))]
fn test_dylib() {
    println!("[Test] Mach-O Dylib Parsing");
    use std::process::Command;
    let dir = tempfile::tempdir().unwrap();
    let c_file = dir.path().join("test.c");
    std::fs::write(&c_file, "int x=0;").unwrap();
    let dylib_path = dir.path().join("libtest.dylib");
    
    let status = Command::new("cc")
        .arg("-dynamiclib")
        .arg(&c_file)
        .arg("-o")
        .arg(&dylib_path)
        .status();
        
    if let Ok(s) = status {
        if s.success() {
            let libs = crate::core::dylib::list_dylibs(&dylib_path).unwrap();
            println!("  -> Parsed dylib, found {} dependencies.", libs.len());
        } else {
            println!("  -> Skipped dylib test: cc compiler failed.");
        }
    }
    println!("  -> Dylib tests passed.");
}

#[cfg(not(target_os = "ios"))]
fn test_cert() {
    println!("[Test] Certificate Import");
    let dir = tempfile::tempdir().unwrap();
    let pem = dir.path().join("test.pem");
    std::fs::write(&pem, "-----BEGIN CERTIFICATE-----\nMIIB\n-----END CERTIFICATE-----\n").unwrap();
    let _ = crate::core::cert::import_pem(&pem).unwrap();
    
    let p12 = dir.path().join("test.p12");
    std::fs::write(&p12, "fake_data_for_p12_test").unwrap();
    let res = crate::core::cert::import_p12(&p12, "pwd");
    assert!(res.is_err());
    println!("  -> Cert tests passed.");
}
