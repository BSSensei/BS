mod error;
mod core;
mod ui;

fn main() {
    if let Err(e) = ui::setup_ui() {
        eprintln!("Failed to initialize UI: {}", e);
    }
}
