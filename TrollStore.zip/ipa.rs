use crate::error::{AppError, Result};
use rust_embed::RustEmbed;
use std::fs;
use std::path::{Path, PathBuf};
use std::process::Command;
use tempfile::tempdir;
use zip::ZipArchive;

#[derive(RustEmbed)]
#[folder = "resources/"]
struct Assets;

pub enum SignMode {
    Real,
    Fake,
    Template(String),
}

pub fn install_ipa(ipa_path: &Path, bundle_id: &str, mode: SignMode) -> Result<()> {
    let file = fs::File::open(ipa_path)?;
    let mut archive = ZipArchive::new(file)?;
    let dir = tempdir()?;
    archive.extract(dir.path())?;

    let app_dir = find_app_bundle(dir.path())?;
    let binary_path = find_main_binary(&app_dir)?;
    let root_helper_bin = extract_binary("RootHelper")?;

    match mode {
        SignMode::Fake => {
            let fastpath_bin = extract_binary("fastPathSign")?;
            let status = Command::new(&fastpath_bin)
                .arg(&binary_path)
                .status()?;
            if !status.success() {
                return Err(AppError::LdidFailed);
            }
        }
        SignMode::Real => {
            let ldid_bin = extract_binary("ldid")?;
            let status = Command::new(&ldid_bin)
                .arg("-S")
                .arg("-Cadhoc")
                .arg(&binary_path)
                .status()?;
            if !status.success() {
                return Err(AppError::LdidFailed);
            }
        }
        SignMode::Template(tmpl) => {
            let ldid_bin = extract_binary("ldid")?;
            let status = Command::new(&ldid_bin)
                .arg("-S")
                .arg(&tmpl)
                .arg(&binary_path)
                .status()?;
            if !status.success() {
                return Err(AppError::LdidFailed);
            }
        }
    }

    let status = Command::new(&root_helper_bin)
        .arg("install")
        .arg(&app_dir)
        .arg(bundle_id)
        .status()?;
    if !status.success() {
        return Err(AppError::HelperFailed);
    }

    Ok(())
}

pub fn uninstall_app(bundle_id: &str) -> Result<()> {
    let root_helper_bin = extract_binary("RootHelper")?;
    let status = Command::new(&root_helper_bin)
        .arg("uninstall")
        .arg(bundle_id)
        .status()?;
    if !status.success() {
        return Err(AppError::HelperFailed);
    }
    Ok(())
}

fn find_app_bundle(base: &Path) -> Result<PathBuf> {
    for entry in fs::read_dir(base)? {
        let entry = entry?;
        let path = entry.path();
        if path.extension().and_then(|s| s.to_str()) == Some("app") {
            return Ok(path);
        }
    }
    Err(AppError::Io(std::io::Error::new(
        std::io::ErrorKind::NotFound,
        "No .app bundle found",
    )))
}

fn find_main_binary(app_dir: &Path) -> Result<PathBuf> {
    let plist_path = app_dir.join("Info.plist");
    let value = plist::Value::from_file(&plist_path)?;
    let exec_name = value
        .as_dictionary()
        .and_then(|d| d.get("CFBundleExecutable"))
        .and_then(|v| v.as_string())
        .ok_or_else(|| {
            AppError::Io(std::io::Error::new(
                std::io::ErrorKind::InvalidData,
                "Missing CFBundleExecutable",
            ))
        })?;
    Ok(app_dir.join(exec_name))
}

fn extract_binary(name: &str) -> Result<PathBuf> {
    let asset = Assets::get(name).ok_or_else(|| {
        AppError::Io(std::io::Error::new(
            std::io::ErrorKind::NotFound,
            "Asset not found",
        ))
    })?;
    let tmp_dir = tempdir()?;
    let bin_path = tmp_dir.path().join(name);
    fs::write(&bin_path, asset.data)?;

    #[cfg(unix)]
    {
        use std::os::unix::fs::PermissionsExt;
        let mut perms = fs::metadata(&bin_path)?.permissions();
        perms.set_mode(0o755);
        fs::set_permissions(&bin_path, perms)?;
    }

    std::mem::forget(tmp_dir);
    Ok(bin_path)
}
