#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <objc/message.h>
#include <objc/runtime.h>
#include <mach-o/dyld.h>
#include <substrate.h>

typedef void (*BossSetupMethod)(void *, const void *);
typedef void (*HeroUpdateMethod)(void *, const void *);
typedef void (*GameObjectSetActiveMethod)(void *, bool, const void *);

static BossSetupMethod orig_BossSceneControllerSetup;
static HeroUpdateMethod orig_HeroControllerUpdate;

static uintptr_t unity_base;
static GameObjectSetActiveMethod set_active;

static void *scaled_bosses[256];
static uint32_t scaled_count;
static pthread_mutex_t scaled_lock = PTHREAD_MUTEX_INITIALIZER;
static void *disabled_shadow_prefab;

static inline uintptr_t addr(uintptr_t rva) {
    return unity_base + rva;
}

static uintptr_t find_unity_image(void) {
    uint32_t count = _dyld_image_count();
    for (uint32_t i = 0; i < count; i++) {
        const char *name = _dyld_get_image_name(i);
        if (name && strstr(name, "UnityFramework")) {
            return (uintptr_t)_dyld_get_image_vmaddr_slide(i);
        }
    }
    for (uint32_t i = 0; i < count; i++) {
        const char *name = _dyld_get_image_name(i);
        if (name && strstr(name, "Hollow Knight")) {
            return (uintptr_t)_dyld_get_image_vmaddr_slide(i);
        }
    }
    return 0;
}

static bool is_scaled(void *boss) {
    bool found = false;
    pthread_mutex_lock(&scaled_lock);
    for (uint32_t i = 0; i < scaled_count; i++) {
        if (scaled_bosses[i] == boss) {
            found = true;
            break;
        }
    }
    pthread_mutex_unlock(&scaled_lock);
    return found;
}

static void mark_scaled(void *boss) {
    pthread_mutex_lock(&scaled_lock);
    if (scaled_count < 256) {
        scaled_bosses[scaled_count++] = boss;
    }
    pthread_mutex_unlock(&scaled_lock);
}

static void scale_bosses(void *controller) {
    if (!controller) return;

    void *array = *(void **)((uint8_t *)controller + 0x48);
    if (!array) return;

    uint64_t length = *(uint64_t *)((uint8_t *)array + 0x18);
    if (length > 256) length = 256;

    void **items = (void **)((uint8_t *)array + 0x20);

    for (uint64_t i = 0; i < length; i++) {
        void *boss = items[i];
        if (!boss || is_scaled(boss)) continue;

        int32_t *hp = (int32_t *)((uint8_t *)boss + 0xE8);
        int32_t base = *hp;
        if (base <= 0) continue;

        int64_t doubled = (int64_t)base * 2;
        if (doubled > INT32_MAX) doubled = INT32_MAX;

        *hp = (int32_t)doubled;
        mark_scaled(boss);

    }
}

static void hook_BossSceneControllerSetup(void *self, const void *method) {
    orig_BossSceneControllerSetup(self, method);
    scale_bosses(self);
}

static void hook_HeroControllerUpdate(void *self, const void *method) {
    orig_HeroControllerUpdate(self, method);
    if (!self) return;

    *(float *)((uint8_t *)self + 0x20C) = 0.0f;
    *(float *)((uint8_t *)self + 0x250) = 0.0f;
    *(float *)((uint8_t *)self + 0x98) = 0.0f;

    if (set_active && !disabled_shadow_prefab) {
        void *shadowRechargePrefab = *(void **)((uint8_t *)self + 0x398);
        if (shadowRechargePrefab) {
            disabled_shadow_prefab = shadowRechargePrefab;
            set_active(shadowRechargePrefab, false, NULL);
        }
    }
}

static void *install_thread(void *unused) {
    (void)unused;

    for (int i = 0; i < 300; i++) {
        unity_base = find_unity_image();
        if (unity_base) break;
        sleep(1);
    }

    if (!unity_base) return NULL;

    set_active = (GameObjectSetActiveMethod)addr(0x1C935C8);

    MSHookFunction((void *)addr(0x1169DD8), (void *)hook_BossSceneControllerSetup, (void **)&orig_BossSceneControllerSetup);
    MSHookFunction((void *)addr(0x10281F4), (void *)hook_HeroControllerUpdate, (void **)&orig_HeroControllerUpdate);

    return NULL;
}

__attribute__((constructor))
static void hkmod_init(void) {
    pthread_t thread;
    if (pthread_create(&thread, NULL, install_thread, NULL) == 0) {
        pthread_detach(thread);
    }
}
