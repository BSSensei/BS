#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <pthread.h>
#include <unistd.h>
#include <string.h>
#include <limits.h>
#include <mach-o/dyld.h>
#include <dispatch/dispatch.h>

#ifndef SUBSTRATE_H
#define SUBSTRATE_H
#ifdef __cplusplus
extern "C" {
#endif
void MSHookFunction(void *symbol, void *replace, void **result);
#ifdef __cplusplus
}
#endif
#endif

typedef struct MethodInfo MethodInfo;

typedef struct HealthManager_o HealthManager_o;
typedef struct BossSceneController_o BossSceneController_o;
typedef struct HeroController_o HeroController_o;

typedef struct Il2CppArrayBounds {
    uintptr_t length;
    uintptr_t lower_bound;
} Il2CppArrayBounds;

typedef struct Il2CppArray {
    void *klass;
    void *monitor;
    Il2CppArrayBounds *bounds;
    uintptr_t max_length;
} Il2CppArray;

typedef void (*BossSceneControllerSetup_t)(
    BossSceneController_o *self,
    const MethodInfo *method
);

typedef void (*HeroControllerUpdate_t)(
    HeroController_o *self,
    const MethodInfo *method
);

static BossSceneControllerSetup_t original_BossSceneControllerSetup = NULL;
static HeroControllerUpdate_t original_HeroControllerUpdate = NULL;

static volatile int hooks_installed = 0;

static uintptr_t unityframework_slide(void)
{
    uint32_t count = _dyld_image_count();

    for (uint32_t i = 0; i < count; i++) {
        const char *name = _dyld_get_image_name(i);

        if (!name) {
            continue;
        }

        if (strstr(name, "/UnityFramework.framework/UnityFramework") ||
            strstr(name, "/UnityFramework")) {
            return (uintptr_t)_dyld_get_image_vmaddr_slide(i);
        }
    }

    return 0;
}

static void *unityframework_rva(uintptr_t rva)
{
    uintptr_t slide = unityframework_slide();

    if (!slide) {
        return NULL;
    }

    return (void *)(slide + rva);
}

static bool valid_object_pointer(const void *ptr)
{
    uintptr_t p = (uintptr_t)ptr;

    if (!p) {
        return false;
    }

    if (p < 0x100000000ULL) {
        return false;
    }

    if ((p & 7ULL) != 0) {
        return false;
    }

    return true;
}

static void scale_boss_health(BossSceneController_o *self)
{
    if (!valid_object_pointer(self)) {
        return;
    }

    Il2CppArray *bosses =
        *(Il2CppArray **)((uintptr_t)self + 0x48);

    if (!valid_object_pointer(bosses)) {
        return;
    }

    uintptr_t length = bosses->max_length;

    if (length == 0 || length > 64) {
        return;
    }

    HealthManager_o **items =
        (HealthManager_o **)((uintptr_t)bosses + 0x20);

    for (uintptr_t i = 0; i < length; i++) {
        HealthManager_o *boss = items[i];

        if (!valid_object_pointer(boss)) {
            continue;
        }

        int32_t *hp =
            (int32_t *)((uintptr_t)boss + 0xE8);

        int32_t value = *hp;

        if (value <= 0) {
            continue;
        }

        if (value > INT32_MAX / 2) {
            *hp = INT32_MAX;
        } else {
            *hp = value * 2;
        }
    }
}

static void hooked_BossSceneControllerSetup(
    BossSceneController_o *self,
    const MethodInfo *method)
{
    original_BossSceneControllerSetup(self, method);

    scale_boss_health(self);
}

static void disable_shadow_dash_cooldown(
    HeroController_o *self)
{
    if (!valid_object_pointer(self)) {
        return;
    }

    uintptr_t base = (uintptr_t)self;

    *(float *)(base + 0x98) = 0.0f;
    *(float *)(base + 0x20C) = 0.0f;
    *(float *)(base + 0x250) = 0.0f;
}

static void hooked_HeroControllerUpdate(
    HeroController_o *self,
    const MethodInfo *method)
{
    original_HeroControllerUpdate(self, method);

    disable_shadow_dash_cooldown(self);
}

static bool install_hooks(void)
{
    if (!__sync_bool_compare_and_swap(
            &hooks_installed,
            0,
            1)) {
        return true;
    }

    void *setup_target =
        unityframework_rva(0x1169DD8);

    void *update_target =
        unityframework_rva(0x10281F4);

    if (!setup_target || !update_target) {
        hooks_installed = 0;
        return false;
    }

    MSHookFunction(
        setup_target,
        (void *)hooked_BossSceneControllerSetup,
        (void **)&original_BossSceneControllerSetup
    );

    if (!original_BossSceneControllerSetup) {
        hooks_installed = 0;
        return false;
    }

    MSHookFunction(
        update_target,
        (void *)hooked_HeroControllerUpdate,
        (void **)&original_HeroControllerUpdate
    );

    if (!original_HeroControllerUpdate) {
        hooks_installed = 0;
        return false;
    }

    return true;
}

static void *install_thread(void *arg)
{
    (void)arg;

    for (;;) {
        if (unityframework_slide()) {
            if (install_hooks()) {
                return NULL;
            }
        }

        usleep(100000);
    }

    return NULL;
}

__attribute__((constructor))
static void mod_init(void)
{
    pthread_t thread;

    if (pthread_create(
            &thread,
            NULL,
            install_thread,
            NULL) == 0) {
        pthread_detach(thread);
    }
}