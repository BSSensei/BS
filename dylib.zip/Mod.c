#include <stdint.h>
#include <stddef.h>
#include <pthread.h>
#include <unistd.h>
#include <dispatch/dispatch.h>
#include <dlfcn.h>

#include <substrate.h>

typedef struct BossSceneController_o BossSceneController_o;
typedef struct HealthManager_o HealthManager_o;
typedef struct MethodInfo MethodInfo;

typedef void (*BossSceneControllerSetup_t)(
    BossSceneController_o *self,
    const MethodInfo *method
);

typedef struct {
    void *klass;
    void *monitor;
    void *fields;
} Il2CppObjectLayout;

typedef struct {
    void *klass;
    void *monitor;
    void *bounds;
    uintptr_t max_length;
} Il2CppArrayLayout;

typedef struct {
    void *klass;
    void *monitor;
    void *fields;
} HealthManagerLayout;

typedef struct {
    void *heroSpawn;
    void *transitionPrefab;
    void *endTransitionEvent;
    uint8_t doTransitionIn;
    uint8_t _pad31[3];
    float transitionInHoldTime;
    uint8_t doTransitionOut;
    uint8_t _pad39[3];
    float transitionOutHoldTime;
    uint8_t isTransitioningOut;
    uint8_t canTransition;
    uint8_t _pad42[6];
    void *bosses;
} BossSceneControllerFields;

typedef struct {
    void *klass;
    void *monitor;
    BossSceneControllerFields fields;
} BossSceneControllerLayout;

static BossSceneControllerSetup_t original_setup = NULL;
static pthread_once_t install_once = PTHREAD_ONCE_INIT;

static uintptr_t module_base(void)
{
    Dl_info info;
    if (dladdr((void *)module_base, &info) == 0)
        return 0;

    return (uintptr_t)info.dli_fbase;
}

static uintptr_t resolve_rva(uintptr_t rva)
{
    uintptr_t base = module_base();
    if (base == 0)
        return 0;

    return base + rva;
}

static int valid_pointer(const void *p)
{
    uintptr_t value = (uintptr_t)p;

    if (value < 0x100000000ULL)
        return 0;

    if ((value & 0x7ULL) != 0)
        return 0;

    return 1;
}

static int doubled_hp(int32_t hp)
{
    if (hp <= 0)
        return hp;

    if (hp > INT32_MAX / 2)
        return INT32_MAX;

    return hp * 2;
}

static void scale_bosses(BossSceneController_o *self)
{
    if (!valid_pointer(self))
        return;

    BossSceneControllerLayout *controller =
        (BossSceneControllerLayout *)self;

    void *array =
        controller->fields.bosses;

    if (!valid_pointer(array))
        return;

    Il2CppArrayLayout *boss_array =
        (Il2CppArrayLayout *)array;

    uintptr_t length = boss_array->max_length;

    if (length == 0 || length > 64)
        return;

    void **items =
        (void **)((uint8_t *)array + 0x20);

    for (uintptr_t i = 0; i < length; i++) {
        HealthManager_o *boss =
            (HealthManager_o *)items[i];

        if (!valid_pointer(boss))
            continue;

        HealthManagerLayout *health =
            (HealthManagerLayout *)boss;

        int32_t *hp =
            (int32_t *)((uint8_t *)health->fields + 0xD0);

        int32_t current = *hp;

        if (current <= 0)
            continue;

        *hp = doubled_hp(current);
    }
}

static void scale_bosses_async(BossSceneController_o *self)
{
    if (!valid_pointer(self))
        return;

    dispatch_async(dispatch_get_main_queue(), ^{
        scale_bosses(self);
    });
}

static void hooked_setup(
    BossSceneController_o *self,
    const MethodInfo *method
)
{
    if (original_setup != NULL)
        original_setup(self, method);

    scale_bosses_async(self);
}

static void install_hooks(void)
{
    uintptr_t target =
        resolve_rva(0x1169DD8);

    if (target == 0)
        return;

    MSHookFunction(
        (void *)target,
        (void *)hooked_setup,
        (void **)&original_setup
    );
}

static void *install_thread(void *unused)
{
    (void)unused;

    for (;;) {
        void *handle =
            dlopen(
                "/System/Library/Frameworks/UnityFramework.framework/UnityFramework",
                RTLD_NOLOAD | RTLD_NOW
            );

        if (handle != NULL) {
            dlclose(handle);
            break;
        }

        handle =
            dlopen(
                "UnityFramework",
                RTLD_NOLOAD | RTLD_NOW
            );

        if (handle != NULL) {
            dlclose(handle);
            break;
        }

        usleep(250000);
    }

    pthread_once(&install_once, install_hooks);

    return NULL;
}

__attribute__((constructor))
static void mod_init(void)
{
    pthread_t thread;

    if (pthread_create(
            &thread,
            NULL,
            install_thread,
            NULL
        ) == 0) {
        pthread_detach(thread);
    }
}