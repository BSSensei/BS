#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <objc/message.h>
#include <objc/runtime.h>
#include <dispatch/dispatch.h>
#include <mach-o/dyld.h>
#include <substrate.h>

typedef void (*LoadSettingsMethod)(void *, const void *);
typedef void (*SetIntMethod)(int32_t, const void *);
typedef void (*PassGroupMethod)(void *, int32_t, const void *);
typedef void (*NoiseRenderMethod)(void *, void *, void *, const void *);
typedef void (*SceneUpdateMethod)(void *, const void *);
typedef void (*FastNoiseRenderMethod)(void *, void *, void *, const void *);
typedef void (*BloomRenderMethod)(void *, void *, void *, const void *);
typedef void (*MotionBlurRenderMethod)(void *, void *, void *, const void *);
typedef float (*GetFloatMethod)(const void *);
typedef void (*SetQualityIntMethod)(int32_t, const void *);
static GetFloatMethod get_smoothDeltaTime;
static SetQualityIntMethod set_pixelLightCount;
static int32_t base_pixel_light_count = 2;
static float frame_time_ema;
static int adaptive_pressure;
static int frame_sample_counter;
static int last_applied_pressure = -1;
static int last_applied_particle_target = -1;

static LoadSettingsMethod orig_LoadVideoSettings;
static LoadSettingsMethod orig_SaveVideoSettings;
static PassGroupMethod orig_LightBlurSetPassGroupCount;
static PassGroupMethod orig_LightBlurredBackgroundSetPassGroupCount;
static PassGroupMethod orig_LightBlurredBackgroundSetRenderTextureHeight;
static NoiseRenderMethod orig_NoiseAndGrainOnRenderImage;
static SceneUpdateMethod orig_SceneManagerUpdate;
static FastNoiseRenderMethod orig_FastNoiseOnRenderImage;
static BloomRenderMethod orig_BloomOptimizedOnRenderImage;
static MotionBlurRenderMethod orig_MotionBlurOnRenderImage;

static uintptr_t unity_base;
static int device_fps;
static uint64_t device_ram;
static int current_zone = -1;
static int applied_zone = -2;
static int device_blur_budget;
static int scene_blur_budget;
static int scene_noise_multiple;
static int scene_bloom_iterations;
static bool scene_disable_extra_motion_blur;
static float scene_motion_blur_amount;
static volatile bool installed;

static inline uintptr_t addr(uintptr_t rva) {
    return unity_base + rva;
}

static uintptr_t find_unity_image(void) {
    uint32_t count = _dyld_image_count();
    for (uint32_t i = 0; i < count; i++) {
        const char *name = _dyld_get_image_name(i);
        if (name && strstr(name, "UnityFramework")) {
            return (uintptr_t)_dyld_get_image_header(i);
        }
    }
    for (uint32_t i = 0; i < count; i++) {
        const char *name = _dyld_get_image_name(i);
        if (name && strstr(name, "Hollow Knight")) {
            return (uintptr_t)_dyld_get_image_header(i);
        }
    }
    return 0;
}

static id msg_id(id obj, const char *selector) {
    if (!obj) return (id)0;
    return ((id (*)(id, SEL))(void *)objc_msgSend)(obj, sel_registerName(selector));
}

static uint64_t msg_u64(id obj, const char *selector) {
    if (!obj) return 0;
    return ((uint64_t (*)(id, SEL))(void *)objc_msgSend)(obj, sel_registerName(selector));
}

static int64_t msg_integer(id obj, const char *selector) {
    if (!obj) return 0;
    return ((int64_t (*)(id, SEL))(void *)objc_msgSend)(obj, sel_registerName(selector));
}

static void refresh_device_profile(void) {
    id processInfoClass = (id)objc_getClass("NSProcessInfo");
    id processInfo = msg_id(processInfoClass, "processInfo");
    device_ram = msg_u64(processInfo, "physicalMemory");

    id screenClass = (id)objc_getClass("UIScreen");
    id screen = msg_id(screenClass, "mainScreen");
    device_fps = (int)msg_integer(screen, "maximumFramesPerSecond");
    if (device_fps <= 0) device_fps = 60;

    if (device_ram <= 0xC0000000ULL) {
        device_blur_budget = 1;
    } else {
        device_blur_budget = 2;
    }
}

static bool is_heavy_zone(int zone) {
    return zone == 6 || zone == 7 || zone == 8 || zone == 10 ||
           zone == 11 || zone == 19 || zone == 23 || zone == 32 ||
           zone == 38;
}

static bool is_arena_zone(int zone) {
    return zone == 18 || zone == 30;
}

static void apply_scene_profile(int zone) {
    current_zone = zone;

    scene_blur_budget = device_blur_budget;
    scene_noise_multiple = 1;
    scene_bloom_iterations = device_ram <= 0xC0000000ULL ? 1 : 2;
    scene_disable_extra_motion_blur = false;
    scene_motion_blur_amount = 0.8f;

    if (is_heavy_zone(zone)) {
        scene_blur_budget = 1;
        scene_noise_multiple = 2;
        scene_bloom_iterations = 1;
        scene_disable_extra_motion_blur = true;
        scene_motion_blur_amount = 0.65f;
    } else if (is_arena_zone(zone)) {
        scene_blur_budget = 1;
        scene_noise_multiple = 2;
        scene_bloom_iterations = 1;
        scene_disable_extra_motion_blur = true;
        scene_motion_blur_amount = 0.70f;
    }

    if (scene_blur_budget < 1) scene_blur_budget = 1;
    if (scene_blur_budget > 2) scene_blur_budget = 2;
    if (scene_noise_multiple < 1) scene_noise_multiple = 1;
    if (scene_noise_multiple > 2) scene_noise_multiple = 2;
    if (scene_bloom_iterations < 1) scene_bloom_iterations = 1;
    if (scene_bloom_iterations > 2) scene_bloom_iterations = 2;
}

static void apply_frame_policy(void) {
    if (!unity_base) return;

    SetIntMethod setTargetFrameRate = (SetIntMethod)addr(0x1C89E48);
    SetIntMethod setVSyncCount = (SetIntMethod)addr(0x1CA8A20);

    int fps = device_fps > 0 ? device_fps : 60;
    if (fps > 120) fps = 120;
    if (fps < 30) fps = 30;

    setTargetFrameRate(fps, NULL);
    setVSyncCount(0, NULL);
}

static void apply_particle_profile(void) {
    if (!set_pixelLightCount) return;

    int32_t target = base_pixel_light_count;
    if (target < 1) target = 1;
    if (target > 4) target = 4;

    if (is_heavy_zone(current_zone) || is_arena_zone(current_zone)) {
        target = target > 1 ? 1 : target;
    }

    if (adaptive_pressure >= 2 && target > 1) {
        target--;
    }

    if (target == last_applied_particle_target) return;

    last_applied_particle_target = target;
    set_pixelLightCount(target, NULL);
}

static void hook_LoadVideoSettings(void *self, const void *method) {
    orig_LoadVideoSettings(self, method);
    if (self) {
        *(int32_t *)((uint8_t *)self + 0x48) = 0;
        *(int32_t *)((uint8_t *)self + 0x60) = device_fps;
        *(uint8_t *)((uint8_t *)self + 0x64) = 1;
    }
    apply_frame_policy();
}

static void hook_SaveVideoSettings(void *self, const void *method) {
    orig_SaveVideoSettings(self, method);
    if (self) {
        *(int32_t *)((uint8_t *)self + 0x48) = 0;
        *(int32_t *)((uint8_t *)self + 0x60) = device_fps;
        *(uint8_t *)((uint8_t *)self + 0x64) = 1;
    }
    apply_frame_policy();
}

static void hook_SceneManagerUpdate(void *self, const void *method) {
    orig_SceneManagerUpdate(self, method);
    if (!self) return;

    int32_t zone = *(int32_t *)((uint8_t *)self + 0x1C);
    if (zone < 0 || zone > 100) zone = -1;

    if (zone != applied_zone) {
        applied_zone = zone;
        adaptive_pressure = 0;
        last_applied_pressure = -1;
        frame_time_ema = 0.0f;
        frame_sample_counter = 0;
        apply_scene_profile(zone);
        apply_particle_profile();
        apply_frame_policy();
    }

    if (!get_smoothDeltaTime) return;

    if ((frame_sample_counter & 3) != 0) {
        frame_sample_counter++;
        return;
    }

    float dt = get_smoothDeltaTime(NULL);
    if (dt <= 0.0f || dt >= 0.25f) return;

    if (frame_time_ema <= 0.0f) frame_time_ema = dt;
    else frame_time_ema = frame_time_ema * 0.92f + dt * 0.08f;

    frame_sample_counter++;
    if (frame_sample_counter < 30) return;
    frame_sample_counter = 0;

    float target_dt = device_fps > 0 ? 1.0f / (float)device_fps : 0.0166667f;

    if (frame_time_ema > target_dt * 1.22f) {
        if (adaptive_pressure < 2) adaptive_pressure++;
    } else if (frame_time_ema < target_dt * 1.05f) {
        if (adaptive_pressure > 0) adaptive_pressure--;
    }

    if (adaptive_pressure != last_applied_pressure) {
        last_applied_pressure = adaptive_pressure;

        if (adaptive_pressure > 0) {
            scene_blur_budget = 1;
            scene_noise_multiple = 2;
            scene_bloom_iterations = 1;
        } else {
            apply_scene_profile(current_zone);
        }

        apply_particle_profile();
    }
}

static void hook_LightBlurSetPassGroupCount(void *self, int32_t value, const void *method) {
    if (value < 0) value = 0;
    if (value > scene_blur_budget) value = scene_blur_budget;
    orig_LightBlurSetPassGroupCount(self, value, method);
}

static void hook_LightBlurredBackgroundSetPassGroupCount(void *self, int32_t value, const void *method) {
    if (value < 0) value = 0;
    if (value > scene_blur_budget) value = scene_blur_budget;
    orig_LightBlurredBackgroundSetPassGroupCount(self, value, method);
}
static void hook_LightBlurredBackgroundSetRenderTextureHeight(void *self, int32_t value, const void *method) {
    int32_t limit = (is_heavy_zone(current_zone) || is_arena_zone(current_zone)) ? 256 : (device_ram <= 0xC0000000ULL ? 384 : 512);
    if (value > limit) value = limit;
    if (value < 64) value = 64;
    orig_LightBlurredBackgroundSetRenderTextureHeight(self, value, method);
}

static void hook_NoiseAndGrainOnRenderImage(void *self, void *source, void *destination, const void *method) {
    if (self) {
        float *softness = (float *)((uint8_t *)self + 0x34);
        float original = *softness;
        if (original >= 0.0f && original < 0.70f) {
            *softness = 0.80f;
            orig_NoiseAndGrainOnRenderImage(self, source, destination, method);
            *softness = original;
            return;
        }
    }
    orig_NoiseAndGrainOnRenderImage(self, source, destination, method);
}

static void hook_FastNoiseOnRenderImage(void *self, void *source, void *destination, const void *method) {
    if (self) {
        uint8_t *field = (uint8_t *)self + 0x1C;
        int32_t original = *(int32_t *)field;
        int32_t value = scene_noise_multiple;
        if (value < 1) value = 1;
        if (value > 2) value = 2;
        *(int32_t *)field = value;
        orig_FastNoiseOnRenderImage(self, source, destination, method);
        *(int32_t *)field = original;
        return;
    }
    orig_FastNoiseOnRenderImage(self, source, destination, method);
}

static void hook_BloomOptimizedOnRenderImage(void *self, void *source, void *destination, const void *method) {
    if (self) {
        uint8_t *iterations_field = (uint8_t *)self + 0x2C;
        int32_t original = *(int32_t *)iterations_field;
        int32_t value = scene_bloom_iterations;
        if (value < 1) value = 1;
        if (value > original && original >= 1) value = original;
        *(int32_t *)iterations_field = value;
        orig_BloomOptimizedOnRenderImage(self, source, destination, method);
        *(int32_t *)iterations_field = original;
        return;
    }
    orig_BloomOptimizedOnRenderImage(self, source, destination, method);
}

static void hook_MotionBlurOnRenderImage(void *self, void *source, void *destination, const void *method) {
    if (self) {
        uint8_t *amount_field = (uint8_t *)self + 0x28;
        uint8_t *extra_field = (uint8_t *)self + 0x2C;
        float original_amount = *(float *)amount_field;
        uint8_t original_extra = *extra_field;

        if (is_heavy_zone(current_zone) || is_arena_zone(current_zone)) {
            *(float *)amount_field = scene_motion_blur_amount;
            *extra_field = 0;
        }

        orig_MotionBlurOnRenderImage(self, source, destination, method);

        *(float *)amount_field = original_amount;
        *extra_field = original_extra;
        return;
    }

    orig_MotionBlurOnRenderImage(self, source, destination, method);
}

static void frame_policy_callback(void *unused) {
    (void)unused;
    apply_frame_policy();
    apply_particle_profile();
}

static void *install_thread(void *unused) {
    (void)unused;

    for (int i = 0; i < 300; i++) {
        unity_base = find_unity_image();
        if (unity_base) break;
        sleep(1);
    }

    if (!unity_base) return NULL;

    refresh_device_profile();
    get_smoothDeltaTime = (GetFloatMethod)addr(0x1CB9720);
    set_pixelLightCount = (SetQualityIntMethod)addr(0x1CA89E0);
    apply_scene_profile(-1);
    MSHookFunction((void *)addr(0xFE8A08), (void *)hook_LoadVideoSettings, (void **)&orig_LoadVideoSettings);
    MSHookFunction((void *)addr(0xFE8D88), (void *)hook_SaveVideoSettings, (void **)&orig_SaveVideoSettings);
    MSHookFunction((void *)addr(0x1183998), (void *)hook_SceneManagerUpdate, (void **)&orig_SceneManagerUpdate);
    MSHookFunction((void *)addr(0x106C42C), (void *)hook_LightBlurSetPassGroupCount, (void **)&orig_LightBlurSetPassGroupCount);
    MSHookFunction((void *)addr(0x106CAB0), (void *)hook_LightBlurredBackgroundSetPassGroupCount, (void **)&orig_LightBlurredBackgroundSetPassGroupCount);
    MSHookFunction((void *)addr(0x106CAA0), (void *)hook_LightBlurredBackgroundSetRenderTextureHeight, (void **)&orig_LightBlurredBackgroundSetRenderTextureHeight);
    MSHookFunction((void *)addr(0x10FB7AC), (void *)hook_NoiseAndGrainOnRenderImage, (void **)&orig_NoiseAndGrainOnRenderImage);
    MSHookFunction((void *)addr(0xFBFC48), (void *)hook_FastNoiseOnRenderImage, (void **)&orig_FastNoiseOnRenderImage);
    MSHookFunction((void *)addr(0x107C808), (void *)hook_BloomOptimizedOnRenderImage, (void **)&orig_BloomOptimizedOnRenderImage);
    MSHookFunction((void *)addr(0x10B635C), (void *)hook_MotionBlurOnRenderImage, (void **)&orig_MotionBlurOnRenderImage);

    installed = true;

    dispatch_async_f(dispatch_get_main_queue(), NULL, frame_policy_callback);

    return NULL;
}

__attribute__((constructor))
static void hkperf_init(void) {
    pthread_t thread;
    if (pthread_create(&thread, NULL, install_thread, NULL) == 0) {
        pthread_detach(thread);
    }
}
